//
//  GXUC_MapCustomAnnotationView.h
//  GXUCMaps
//
//  Created by Marcos Crispino on 12/07/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import MapKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/SDMapPinImageThemeClass.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXMapCustomAnnotationViewLoadingDelegate <NSObject>

- (void)didSet:(UIImage *)image forAnnotation:(id<MKAnnotation>)annotation;

@end

@interface GXUC_MapCustomAnnotationView : MKAnnotationView

@property(nonatomic, weak, readwrite) id<GXMapCustomAnnotationViewLoadingDelegate> loadingDelegate;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue
								themeClass:(nullable SDMapPinImageThemeClass *)themeClass;

@end

NS_ASSUME_NONNULL_END
