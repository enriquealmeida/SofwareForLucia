//
//  GXCallerDelegate.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 01/03/11.
//  Copyright 2011 Artech. All rights reserved.
//
@import GXObjectsModel;
#import <GXCoreUI/GXControllerProtocol.h>
#import <GXCoreUI/GXEntityControllerProtocol.h>
#if !TARGET_OS_WATCH
@class GXViewController;
@class GXEntityViewController;
#endif // !TARGET_OS_WATCH

NS_ASSUME_NONNULL_BEGIN

@protocol GXCallerDelegate <GXOptionalConditionalInheritedConnectivitySupportResolver>

/*!
 Notifies delegate that controller has been dismissed
 
 @param controller The controller dismissed
 @discussion This method is called from controller's dealloc and it's unsafe to make UI changes (presenting or dismissing another controller), consider delaying one event loop. Also note this method may be called in any thread.
 */
- (void)calledGXControllerDismissed:(id<GXControllerProtocol>)controller;

@optional
- (BOOL)dismissCalledGXController:(id<GXControllerProtocol>)controller animated:(BOOL)animated completion:(void(^ _Nullable)(void))completion;
- (BOOL)calledGXController:(id<GXControllerProtocol>)controller willExecuteAction:(id <GXActionHandler>)actionHandler;
- (void)calledGXController:(id<GXControllerProtocol>)controller willBeReplacedWithController:(id<GXControllerProtocol>)newController;
- (id <GXActionHandler>)calledGXControllerCallerActionHandler:(id<GXControllerProtocol>)controller;

#if TARGET_OS_IOS
- (void)calledViewControllerDismissed:(GXViewController *)controller __attribute__((deprecated("Use calledGXControllerDismissed: instead")));
- (BOOL)dismissCalledViewController:(GXViewController *)controller animated:(BOOL)animated __attribute__((deprecated("Use dismissCalledGXController:animated:completion: instead")));
- (BOOL)dismissCalledViewController:(GXViewController *)controller animated:(BOOL)animated completion:(void(^)(void))completion __attribute__((deprecated("Use dismissCalledGXController:animated:completion: instead")));
- (BOOL)calledViewController:(GXViewController *)controller willExecuteAction:(id <GXActionHandler>)actionHandler __attribute__((deprecated("Use calledGXController:willExecuteAction: instead")));
- (void)calledViewController:(GXViewController *)controller willBeReplacedWithViewController:(GXViewController *)newController __attribute__((deprecated("Use calledGXController:willBeReplacedWithController: instead")));
- (id <GXActionHandler>)calledViewControllerCallerActionHandler:(GXViewController *)controller __attribute__((deprecated("Use calledGXControllerCallerActionHandler: instead")));
#endif // TARGET_OS_IOS

@end


@protocol GXEntityCallerDelegate <GXCallerDelegate>

@optional
- (void)entityGXController:(id<GXEntityControllerProtocol>)controller
	   didInsertEntityData:(id <GXEntityData>)insertedEntityData;
- (void)entityGXControllerDidCancelInsert:(id<GXEntityControllerProtocol>)controller;

- (void)entityGXController:(id<GXEntityControllerProtocol>)controller
	   didUpdateEntityData:(id <GXEntityData>)updatedEntityData;
- (void)entityGXControllerDidCancelUpdate:(id<GXEntityControllerProtocol>)controller;

- (void)entityGXControllerDidDeleteEntityData:(id<GXEntityControllerProtocol>)controller;
- (void)entityGXControllerDidCancelDelete:(id<GXEntityControllerProtocol>)controller;

- (BOOL)entityGXController:(id<GXEntityControllerProtocol>)controller
		 didPickEntityData:(id <GXEntityData>)pickedEntityData;

#if TARGET_OS_IOS
- (void)entityViewController:(GXEntityViewController *)controller
		 didInsertEntityData:(id <GXEntityData>)insertedEntityData __attribute__((deprecated("Use entityGXController:didInsertEntityData: instead")));
- (void)entityViewControllerDidCancelInsert:(GXEntityViewController *)controller __attribute__((deprecated("Use entityGXControllerDidCancelInsert: instead")));

- (void)entityViewController:(GXEntityViewController *)controller
		 didUpdateEntityData:(id <GXEntityData>)updatedEntityData __attribute__((deprecated("Use entityGXController:didUpdateEntityData: instead")));
- (void)entityViewControllerDidCancelUpdate:(GXEntityViewController *)controller __attribute__((deprecated("Use entityGXControllerDidCancelUpdate: instead")));

- (void)entityViewControllerDidDeleteEntityData:(GXEntityViewController *)controller __attribute__((deprecated("Use entityGXControllerDidDeleteEntityData: instead")));
- (void)entityViewControllerDidCancelDelete:(GXEntityViewController *)controller __attribute__((deprecated("Use entityGXControllerDidCancelDelete: instead")));

- (BOOL)entityViewController:(GXEntityViewController *)controller
		   didPickEntityData:(id <GXEntityData>)pickedEntityData __attribute__((deprecated("Use entityGXController:didPickEntityData: instead")));
#endif // TARGET_OS_IOS

@end

extern NSString *const GXUserInterfaceControllerDismissedNotification; /// This notification is posted after calledGXControllerDismissed: is called, the same considerations applies
extern NSString *const GXUserInterfaceControllerWillPresentNotification;
#if TARGET_OS_IOS
extern NSString *const GXViewControllerDismissedNotification __attribute__((deprecated("Use GXUserInterfaceControllerDismissedNotification instead")));
extern NSString *const GXViewControllerWillPresentNotification __attribute__((deprecated("Use GXUserInterfaceControllerWillPresentNotification instead")));;
extern NSString *const GXPopoverControllerDismissedNotification __attribute__((deprecated("Use GXUserInterfaceControllerDismissedNotification instead")));
#endif // TARGET_OS_IOS

NS_ASSUME_NONNULL_END
