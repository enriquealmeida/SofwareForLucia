//
//  UITabBar+GXImageWebCache.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 20/10/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/UITabBar+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITabBar (GXImageWebCache)

- (void)gxSetBackgroundImageNamed:(nullable NSString *)imageName;
- (void)gxSetSelectionIndicatorImageNamed:(nullable NSString *)imageName;

@end

NS_ASSUME_NONNULL_END
