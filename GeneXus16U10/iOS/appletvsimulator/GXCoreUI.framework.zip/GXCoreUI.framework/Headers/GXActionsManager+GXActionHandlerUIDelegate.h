//
//  GXActionsManager+GXActionHandlerUIDelegate.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 29/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXObjectsModel;
@import GXCoreBL;

@interface GXActionsManager (GXActionHandlerUIDelegate) <GXActionHandlerUIDelegate>
@end
