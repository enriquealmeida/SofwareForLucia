//
//  GXDataLayerLocal.h
//  GXDataLayerLocal
//
//  Created by Fabian Inthamoussu on 21/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
//! Project version number for GXDataLayerLocal.
FOUNDATION_EXPORT double GXDataLayerLocalVersionNumber;

//! Project version string for GXDataLayerLocal.
FOUNDATION_EXPORT const unsigned char GXDataLayerLocalVersionString[];

#import <GXDataLayerLocal/GXOfflineDatabase.h>
#import <GXDataLayerLocal/GXOfflineDatabaseHelper.h>
#import <GXDataLayerLocal/GXSynchronizationJSONReader.h>
