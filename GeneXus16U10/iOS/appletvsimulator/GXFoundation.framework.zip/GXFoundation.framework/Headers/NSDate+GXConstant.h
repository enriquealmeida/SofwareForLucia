//
//  NSDate+GXConstant.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 8/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSDate (GXConstant)

#pragma mark - GXStd

+ (NSDate *)gxEmptyDate;
+ (NSDate *)gxEmptyDateTime;

- (BOOL)isGxEmptyDate;

@end

NS_ASSUME_NONNULL_END