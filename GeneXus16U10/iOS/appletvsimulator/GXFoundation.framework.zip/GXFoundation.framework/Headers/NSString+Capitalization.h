//
//  NSString+Capitalization.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 04/12/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;

@interface NSString (Capitalization)

- (NSString *)gxStringWithOnlyFirstLetterCapitalized;

@end
