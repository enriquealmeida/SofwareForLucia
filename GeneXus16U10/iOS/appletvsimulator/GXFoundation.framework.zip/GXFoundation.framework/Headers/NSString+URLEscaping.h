//
//  NSString+URLEscaping.h
//  GXFlexibleClient
//
//  Created by willy on 12/5/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;

@interface NSString (URLEscaping)

- (NSString *)urlSimpleEscapeString;
- (NSString *)urlSimpleUnescapeString;

@end