//
//  NSNumber+Helpers.h
//  GXFoundation
//
//  Created by Marcos Crispino on 23/11/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSNumber (Helpers)

- (BOOL)gxIsInteger;

- (NSDecimalNumber *)gxNumberRoundedToDecimals:(NSNumber *)dec;
- (NSDecimalNumber *)gxNumberRoundedToEvenDecimals:(NSNumber *)dec;
- (NSDecimalNumber *)gxNumberTruncatedToDecimals:(NSNumber *)dec;

@end
