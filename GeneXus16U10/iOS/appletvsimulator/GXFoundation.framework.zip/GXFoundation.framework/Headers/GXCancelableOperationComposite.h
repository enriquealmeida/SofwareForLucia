//
//  GXCancelableOperationComposite.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 04/01/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXFoundation/GXCancelableOperationBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCancelableOperationComposite : GXCancelableOperationBase

- (instancetype)initWithChildOperations:(NSArray<id<GXCancelableOperation>> *)childOperations NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
