//
//  GXHTTPWarningHeader.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 19/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXHTTPWarningHeader : NSObject

@property(assign, readonly) NSInteger code;
@property(nonatomic, strong, readonly) NSString *agent;
@property(nonatomic, strong, readonly) NSString *text;

- (instancetype)initWithCode:(NSInteger)code
					   agent:(NSString *)agent
						text:(NSString *)text NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;


/*!
 Checks if is a User warning
 
 @result YES if text has User: (or Encoded:User:) prefix, NO otherwise
 */
- (BOOL)isUserWarning;

/*!
 Checks if is a System warning
 
 @result YES if text has System: (or Encoded:System:) prefix, NO otherwise
 */
- (BOOL)isSystemWarning;

/*!
 Checks if is a warning is encoded
 
 @result YES if text has Encoded: prefix, NO otherwise
 */
- (BOOL)isWarningEncoded;

/// Removes text prefixes (Encode:, User: or System:) and unencodes if needed
- (NSString *)warningText;

@end

NS_ASSUME_NONNULL_END
