//
//  NSDate+TimeZoneConvertion.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 08/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;

@interface NSDate (TimeZoneConvertion)

- (NSTimeInterval)localTimeZoneSecondsFromGMT;
- (NSDate *)localTimeZoneDateFromGTM;
- (NSDate *)gtmTimeZoneDateFromLocal;

- (NSTimeInterval)currentTimeZoneSecondsFromGMT;
- (NSDate *)currentTimeZoneDateFromGTM;
- (NSDate *)gtmTimeZoneDateFromCurrent;

- (NSDate *)currentTimeZoneDateFromLocal;
- (NSDate *)localTimeZoneDateFromCurrent;

@end