//
//  NSString+Trim.h
//  GXFlexibleClient
//
//  Created by willy on 1/26/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

@import Foundation;

@interface NSString (Trim)
 
-(NSString *) ltrim;
-(NSString *) rtrim;
-(NSString *) trim;

@end
