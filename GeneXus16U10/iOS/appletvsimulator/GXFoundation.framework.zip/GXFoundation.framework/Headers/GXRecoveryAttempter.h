//
//  GXRecoveryAttempter.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXRecoveryAttempter : NSObject

@property(nullable, nonatomic, copy) BOOL(^attemptRecoverBlock)(NSError *error, NSUInteger recoveryOptionIndex);
@property(nullable, nonatomic, copy) BOOL(^asyncAttemptRecoverBlock)(NSError *error, NSUInteger recoveryOptionIndex, id __nullable delegate, SEL __nullable didRecoverSelector, void * __nullable contextInfo);

@end

NS_ASSUME_NONNULL_END