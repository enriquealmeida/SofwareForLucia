//
//  NSNotificationCenter+Helpers.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 29/08/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSNotificationCenter (Helpers)

/// Adds observer for the given notification name, object, queue & block, but also removes observer after first call.
- (id <NSObject>)gxAddOnceObserverForName:(nullable NSNotificationName)name
								   object:(nullable id)obj
									queue:(nullable NSOperationQueue *)queue
							   usingBlock:(void (^)(NSNotification *note))block;

@end

NS_ASSUME_NONNULL_END
