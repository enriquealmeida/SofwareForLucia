//
//  GXCryptoCertificate.h
//  GXStandardClasses
//
//  Created by Marcos Crispino on 14/3/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXStandardClasses/GXCryptoBaseType.h>
#import <GXStandardClasses/GXStringCollection.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCryptoCertificate : GXCryptoBaseType

@property (nonatomic, retain, readonly) NSString *issuer;
@property (nonatomic, retain, readonly) NSString *subject;
@property (nonatomic, retain, readonly) NSString *serialNumber;
@property (nonatomic, retain, readonly) NSString *thumbprint;
@property (nonatomic, retain, readonly) NSDate *notAfter;
@property (nonatomic, retain, readonly) NSDate *notBefore;
@property (nonatomic, retain, readonly) NSString *version;

/**
 Allows initialization of a certificate from route and password if necessary.
 */
- (NSInteger)load:(NSString *)path password:(nullable NSString *)pass NS_SWIFT_NAME(load(_:_:));

/**
 Initializes certificate from its representation in base64.
 */
- (void)fromBase64:(NSString *)strData NS_SWIFT_NAME(fromBase64(_:));

/**
 Obtains a representation of the certificate in base64.
 */
- (NSString *)toBase64;

/**
 Allows us to specify the information from the certificate that must be added to the signature when an XML signature is generated.
 */
- (GXStringCollection *)keyInfo;

/**
 Returns true if certificate has an associated private key. The private key is necessary to de-encrypt texts.
 */
- (BOOL)hasPrivateKey;

/**
 Indicates if the certificate is reliable.
 */
- (BOOL)verify;

@end

NS_ASSUME_NONNULL_END

