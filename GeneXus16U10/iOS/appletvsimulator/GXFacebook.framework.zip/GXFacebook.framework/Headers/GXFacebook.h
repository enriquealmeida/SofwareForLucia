//
//  GXFacebook.h
//  GXFacebook
//
//  Created by Fabian Inthamoussu on 18/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXFacebook.
FOUNDATION_EXPORT double GXFacebookVersionNumber;

//! Project version string for GXFacebook.
FOUNDATION_EXPORT const unsigned char GXFacebookVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXFacebook/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
