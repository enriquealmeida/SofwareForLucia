//
//  GXTheme.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/04/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import UIKit;
#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXThemeClass.h>
#import <GXObjectsModel/GXThemeClassAnimation.h>
#import <GXObjectsModel/GXThemeClassApplication.h>
#import <GXObjectsModel/GXThemeClassApplicationBars.h>
#import <GXObjectsModel/GXThemeClassAttribute.h>
#import <GXObjectsModel/GXThemeClassAttributeTitle.h>
#import <GXObjectsModel/GXThemeClassAttributeSubtitle.h>
#import <GXObjectsModel/GXThemeClassAttributeReadOnly.h>
#import <GXObjectsModel/GXThemeClassButton.h>
#import <GXObjectsModel/GXThemeClassDashboard.h>
#import <GXObjectsModel/GXThemeClassDashboardOption.h>
#import <GXObjectsModel/GXThemeClassForm.h>
#import <GXObjectsModel/GXThemeClassGroup.h>
#import <GXObjectsModel/GXThemeClassGroupSeparator.h>
#import <GXObjectsModel/GXThemeClassHorizontalSeparator.h>
#import <GXObjectsModel/GXThemeClassImage.h>
#import <GXObjectsModel/GXThemeClassLabel.h>
#import <GXObjectsModel/GXThemeClassLabelTitle.h>
#import <GXObjectsModel/GXThemeClassLabelSubtitle.h>
#import <GXObjectsModel/GXThemeClassList.h>
#import <GXObjectsModel/GXThemeClassListListWorkWith.h>
#import <GXObjectsModel/GXThemeClassListListLevel.h>
#import <GXObjectsModel/GXThemeClassListItemOddItem.h>
#import <GXObjectsModel/GXThemeClassListItemEvenItem.h>
#import <GXObjectsModel/GXThemeClassProgress.h>
#import <GXObjectsModel/GXThemeClassTab.h>
#import <GXObjectsModel/GXThemeClassTabPage.h>
#import <GXObjectsModel/GXThemeClassTabPageSelected.h>
#import <GXObjectsModel/GXThemeClassTabPageUnselected.h>
#import <GXObjectsModel/GXThemeClassTable.h>
#import <GXObjectsModel/GXTransformation.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const GXThemeClassFormFullName;

extern NSString *const GXThemeClassAttributeFullName;
extern NSString *const GXThemeClassAttribute_TitleFullName;
extern NSString *const GXThemeClassAttribute_SubtitleFullName;
extern NSString *const GXThemeClassAttribute_ReadOnlyFullName;

extern NSString *const GXThemeClassLabelFullName;
extern NSString *const GXThemeClassLabel_TitleFullName;
extern NSString *const GXThemeClassLabel_SubtitleFullName;

extern NSString *const GXThemeClassListFullName;
extern NSString *const GXThemeClassList_ListWorkWithFullName;
extern NSString *const GXThemeClassList_ListLevelFullName;

extern NSString *const GXThemeClassListItemFullName;
extern NSString *const GXThemeClassListItem_EvenItemFullName;
extern NSString *const GXThemeClassListItem_OddItemFullName;

extern NSString *const GXThemeClassImageFullName;

extern NSString *const GXThemeClassButtonFullName;

extern NSString *const GXThemeClassGroupFullName;

extern NSString *const GXThemeClassGroupSeparatorFullName;

extern NSString *const GXThemeClassHorizontalSeparatorFullName;

extern NSString *const GXThemeClassTabFullName;
extern NSString *const GXThemeClassTabPageFullName;
extern NSString *const GXThemeClassTabPage_SelectedFullName;
extern NSString *const GXThemeClassTabPage_UnselectedFullName;

extern NSString *const GXThemeClassTableFullName;

extern NSString *const GXThemeClassDashboardFullName;
extern NSString *const GXThemeClassDashboardOptionFullName;

extern NSString *const GXThemeClassApplicationFullName;
extern NSString *const GXThemeClassApplicationBarsFullName;

extern NSString *const GXThemeClassAnimationFullName;

extern NSString *const GXThemeClassProgressFullName;

@interface GXTheme : GXNamedElement

@property(nullable, nonatomic, strong, readonly) UIColor *keyColor;
@property(nullable, nonatomic, strong, readonly) NSString *darkThemeName;
@property(nullable, nonatomic, strong, readonly) NSDictionary<NSString *, NSString *> *fontMapping;

@property(nonatomic, strong, readonly) NSDictionary<NSString *, __kindof GXThemeClass *> *themeClassesByFullName; // Keys are lowercase

@property(nullable, nonatomic, strong, readonly) GXThemeClassForm *themeClassForm;
@property(nullable, nonatomic, strong, readonly) GXThemeClassApplication *themeClassApplication;
@property(nullable, nonatomic, strong, readonly) GXThemeClassApplicationBars *themeClassApplicationBars;

@property(nullable, nonatomic, strong, readonly) GXThemeClassAttribute *themeClassAttribute;
@property(nullable, nonatomic, strong, readonly) GXThemeClassAttributeTitle *themeClassAttributeTitle;
@property(nullable, nonatomic, strong, readonly) GXThemeClassAttributeSubtitle *themeClassAttributeSubtitle;
@property(nullable, nonatomic, strong, readonly) GXThemeClassAttributeReadOnly *themeClassAttributeReadOnly;

@property(nullable, nonatomic, strong, readonly) GXThemeClassList *themeClassList;
@property(nullable, nonatomic, strong, readonly) GXThemeClassListListWorkWith *themeClassListListWorkWith;
@property(nullable, nonatomic, strong, readonly) GXThemeClassListListLevel *themeClassListListLevel;

@property(nullable, nonatomic, strong, readonly) GXThemeClassListItemOddItem *themeClassListItemOddItem;
@property(nullable, nonatomic, strong, readonly) GXThemeClassListItemEvenItem *themeClassListItemEvenItem;

@property(nullable, nonatomic, strong, readonly) GXThemeClassLabel *themeClassLabel;
@property(nullable, nonatomic, strong, readonly) GXThemeClassLabelTitle *themeClassLabelTitle;
@property(nullable, nonatomic, strong, readonly) GXThemeClassLabelSubtitle *themeClassLabelSubTitle;

@property(nullable, nonatomic, strong, readonly) GXThemeClassImage *themeClassImage;

@property(nullable, nonatomic, strong, readonly) GXThemeClassTab *themeClassTab;
@property(nullable, nonatomic, strong, readonly) GXThemeClassTabPage *themeClassTabPage;
@property(nullable, nonatomic, strong, readonly) GXThemeClassTabPageSelected *themeClassTabPageSelected;
@property(nullable, nonatomic, strong, readonly) GXThemeClassTabPageUnselected *themeClassTabPageUnselected;

@property(nullable, nonatomic, strong, readonly) GXThemeClassGroup *themeClassGroup;

@property(nullable, nonatomic, strong, readonly) GXThemeClassGroupSeparator *themeClassGroupSeparator;

@property(nullable, nonatomic, strong, readonly) GXThemeClassHorizontalSeparator *themeClassHorizontalSeparator;

@property(nullable, nonatomic, strong, readonly) GXThemeClassDashboard *themeClassDashboard;
@property(nullable, nonatomic, strong, readonly) GXThemeClassDashboardOption *themeClassDashboardOption;

@property(nullable, nonatomic, strong, readonly) GXThemeClassAnimation *themeClassAnimation;

@property(nullable, nonatomic, strong, readonly) GXThemeClassAnimation *themeClassProgress;


- (nullable __kindof GXThemeClass *)themeClassForFullName:(NSString *)fullName;
- (nullable GXTransformation *)transformationForName:(NSString *)name;

// Default Theme Classes

@property(nonatomic, strong, readonly) NSDictionary<NSString *, __kindof GXThemeClass *> *defaultThemeClassesByFullName; // Keys are lowercase

@property(nonatomic, strong, readonly) GXThemeClassForm *defaultThemeClassForm;
@property(nonatomic, strong, readonly) GXThemeClassApplication *defaultThemeClassApplication;
@property(nonatomic, strong, readonly) GXThemeClassApplicationBars *defaultThemeClassApplicationBars;

@property(nonatomic, strong, readonly) GXThemeClassAttribute *defaultThemeClassAttribute;
@property(nonatomic, strong, readonly) GXThemeClassAttributeTitle *defaultThemeClassAttributeTitle;
@property(nonatomic, strong, readonly) GXThemeClassAttributeSubtitle *defaultThemeClassAttributeSubtitle;
@property(nonatomic, strong, readonly) GXThemeClassAttributeReadOnly *defaultThemeClassAttributeReadOnly;

@property(nonatomic, strong, readonly) GXThemeClassList *defaultThemeClassList;
@property(nonatomic, strong, readonly) GXThemeClassListListWorkWith *defaultThemeClassListListWorkWith;
@property(nonatomic, strong, readonly) GXThemeClassListListLevel *defaultThemeClassListListLevel;

@property(nonatomic, strong, readonly) GXThemeClassListItemOddItem *defaultThemeClassListItemOddItem;
@property(nonatomic, strong, readonly) GXThemeClassListItemEvenItem *defaultThemeClassListItemEvenItem;

@property(nonatomic, strong, readonly) GXThemeClassLabel *defaultThemeClassLabel;
@property(nonatomic, strong, readonly) GXThemeClassLabelTitle *defaultThemeClassLabelTitle;
@property(nonatomic, strong, readonly) GXThemeClassLabelSubtitle *defaultThemeClassLabelSubTitle;

@property(nonatomic, strong, readonly) GXThemeClassImage *defaultThemeClassImage;

@property(nonatomic, strong, readonly) GXThemeClassTab *defaultThemeClassTab;
@property(nonatomic, strong, readonly) GXThemeClassTabPage *defaultThemeClassTabPage;
@property(nonatomic, strong, readonly) GXThemeClassTabPageSelected *defaultThemeClassTabPageSelected;
@property(nonatomic, strong, readonly) GXThemeClassTabPageUnselected *defaultThemeClassTabPageUnselected;

@property(nonatomic, strong, readonly) GXThemeClassGroup *defaultThemeClassGroup;

@property(nonatomic, strong, readonly) GXThemeClassGroupSeparator *defaultThemeClassGroupSeparator;

@property(nonatomic, strong, readonly) GXThemeClassHorizontalSeparator *defaultThemeClassHorizontalSeparator;

@property(nonatomic, strong, readonly) GXThemeClassDashboard *defaultThemeClassDashboard;
@property(nonatomic, strong, readonly) GXThemeClassDashboardOption *defaultThemeClassDashboardOption;

@property(nonatomic, strong, readonly) GXThemeClassAnimation *defaultThemeClassAnimation;

@property(nonatomic, strong, readonly) GXThemeClassAnimation *defaultThemeClassProgress;


+ (GXTheme *)defaultTheme;

- (nullable __kindof GXThemeClass *)defaultThemeClassForFullName:(NSString *)fullName;

@end


@interface GXTheme (GXModel)

+ (nullable GXTheme *)currentTheme;

@end

NS_ASSUME_NONNULL_END
