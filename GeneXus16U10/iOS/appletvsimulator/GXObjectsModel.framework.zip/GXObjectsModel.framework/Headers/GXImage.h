//
//  GXImage.h
//  GXFlexibleClient
//
//  Created by Guillermo Pasquero on 10/28/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXNamedElement.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXImageType) {
	GXImageTypeInternal,
	GXImageTypeExternal
};
#define GXImageType_UNDEFINED ((GXImageType)UINT_LEAST8_MAX)

typedef NS_ENUM(uint_least8_t, GXImageRenderingMode) {
	GXImageRenderingModeAutomatic,
	GXImageRenderingModeOriginal,
	GXImageRenderingModeTemplate
};
#define GXImageRenderingMode_UNDEFINED ((GXImageRenderingMode)UINT_LEAST8_MAX)

@interface GXImage : GXNamedElement <NSCoding>

@property(nonnull, nonatomic, strong, readonly) NSString *name;
@property(nonatomic, strong, readonly) NSString *location;
@property(nonatomic, assign, readonly) GXImageType type;
@property(nonatomic, strong, readonly) NSString *internalName;
@property(nonatomic, strong, readonly) NSString *internalNameRetina;
@property(nonatomic, strong, readonly) NSString *internalNameRetinaHD;
@property(nullable, nonatomic, strong, readonly) NSString *guid;
@property(nonatomic, assign, readonly) GXImageRenderingMode renderingMode;
@property(nullable, nonatomic, strong, readonly) NSValue *scalableEdgeInsets;
@property(nonatomic, assign, readonly) BOOL flipsForRTL;

+ (nullable instancetype)imageWithMetadata:(id)metadata error:(out NSError * _Nullable __autoreleasing * _Nullable)error;
- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
