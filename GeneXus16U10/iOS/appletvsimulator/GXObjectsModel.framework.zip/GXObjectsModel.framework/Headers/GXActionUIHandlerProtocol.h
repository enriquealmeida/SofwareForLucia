//
//  GXActionUIHandlerProtocol.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 2/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import UIKit;
#if TARGET_OS_WATCH
@import WatchKit;
#endif // !TARGET_OS_WATCH
#import <GXObjectsModel/GXActionHandlerProtocol.h>
#if TARGET_OS_IOS
#import <GXObjectsModel/GXViewControllerPresentationHandler.h>
#endif // TARGET_OS_IOS
#import <GXObjectsModel/GXUserInterfaceContext.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXActionHandler;
@protocol GXActionHandlerDelegate;
@protocol GXActionSender;
@protocol GXControllerPresentationHandlerProtocol;
#if !TARGET_OS_WATCH
@protocol GXActionHandlerViewController;
@protocol GXViewControllerPresentationHandler;
#endif // !TARGET_OS_WATCH
@class GXUserInterfaceContext;

#if TARGET_OS_IOS
@protocol GXActionHandlerUserInterfaceControllerProtocol <GXControllerPresentationHandlerProtocol, GXActionHandlerViewController>
#else
@protocol GXActionHandlerUserInterfaceControllerProtocol <GXControllerPresentationHandlerProtocol>
#endif // TARGET_OS_WATCH

#if TARGET_OS_WATCH
@property(nullable, nonatomic, strong, readonly) WKInterfaceController *actionHandlerUserInterfaceController;
#else
@property(nullable, nonatomic, strong, readonly) UIViewController *actionHandlerUserInterfaceController;
#endif // TARGET_OS_WATCH

@end

#if TARGET_OS_IOS
@protocol GXActionHandlerViewController <GXViewControllerPresentationHandler>

@optional
@property(nullable, nonatomic, strong, readonly) UIViewController *actionHandlerViewController  __attribute__((deprecated("Use actionHandlerUserInterfaceController instead")));

@end
#endif // TARGET_OS_IOS


@protocol GXActionHandlerUIDelegate <GXActionHandlerDelegate>

@optional
- (nullable id <GXControllerPresentationHandlerProtocol>)actionHandlerControllerPresentationHandler:(id <GXActionHandler>)actionHandler;
- (nullable id <GXActionHandlerUserInterfaceControllerProtocol>)actionHandlerUserInterfaceController:(id <GXActionHandler>)actionHandler;
#if TARGET_OS_IOS
- (nullable id <GXViewControllerPresentationHandler>)actionHandlerViewControlerPresentationHandler:(id <GXActionHandler>)actionHandler __attribute__((deprecated("Use actionHandlerUserInterfaceController: instead")));
- (nullable id <GXActionHandlerViewController>)actionHandlerViewControler:(id <GXActionHandler>)actionHandler __attribute__((deprecated("Use actionHandlerUserInterfaceController: instead")));
#endif // TARGET_OS_IOS

@end


@protocol GXActionUISender <GXActionSender>

@property(nonatomic, strong, readonly) GXUserInterfaceContext *actionSenderUserInterfaceContext;

@end


@protocol GXActionHandlerUIContext <GXActionHandlerContext>

@property(nullable, nonatomic, strong, readonly) id <GXActionUISender> actionHandlerUIContextSender;

@end


@protocol GXActionUIHandler <GXActionHandler>

@property(nullable, nonatomic, weak, readonly) id <GXActionHandlerUIDelegate> uiDelegate;
@property(nullable, nonatomic, strong, readonly) id <GXActionHandlerUIContext> actionHandlerUIContext;

@end

NS_ASSUME_NONNULL_END
