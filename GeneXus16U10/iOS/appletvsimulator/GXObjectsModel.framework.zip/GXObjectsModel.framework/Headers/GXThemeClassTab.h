//
//  GXThemeClassTab.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 12/08/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassContainerBase.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXThemeClassTabPosition) {
	GXThemeClassTabPositionTop,
	GXThemeClassTabPositionBottom
};

@interface GXThemeClassTab : GXThemeClassContainerBase

@property(nullable, nonatomic, strong, readonly) GXThemeClass *selectedTabPageClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *unselectedTabPageClass;
@property(nonatomic, assign, readonly) GXThemeClassTabPosition tabsPosition;
@property(nonatomic, strong, readonly) UIColor *tabStripSeparatorColor;
@property(nullable, nonatomic, strong, readonly) UIColor *tabStripIndicatorColor;
@property(nullable, nonatomic, strong, readonly) UIColor *tabStripBackgroundColor;
@property(nonatomic, assign, readonly) CGFloat tabStripHeight; // Unspecified = 0

- (nullable UIColor *)tabStripSeparatorColorResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable UIColor *)tabStripIndicatorColorResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable UIColor *)tabStripBackgroundColorResolvingToDefaultValue:(BOOL)resolveToDefault;

@end

NS_ASSUME_NONNULL_END
