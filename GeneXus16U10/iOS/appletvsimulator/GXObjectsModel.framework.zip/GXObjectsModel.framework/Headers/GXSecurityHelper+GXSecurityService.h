//
//  GXSecurityHelper+GXSecurityService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXSecurityHelper.h>
#import <GXObjectsModel/GXSecurityService.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXSecurityHelper (GXSecurityService)

+ (BOOL)requestAuthorizationRequiredForApplicationEntryPoint:(GXModel *)model;

+ (nullable id <NSObject>)requestAuthorizationForApplicationEntryPoint:(GXModel *)model
															 uiContext:(nullable GXUserInterfaceContext *)uiContext
															completion:(nullable GXSecurityServiceAuthorizationCompletionBlock)completion;

/*!
 Helper method that uses [GXObjectsModelServices securityService]
 
 @param response See GXSecurityService protocol.
 @param data See GXSecurityService protocol.
 @param error Always non nil error if response.statusCode >= 400, even if [GXObjectsModelServices securityService] == nil
 @param recoverOptions Non nil only if [GXObjectsModelServices securityService] is non nil too.
 @discussion Even if [GXObjectsModelServices securityService] == nil, always returns non nil error if response.statusCode >= 400. See GXSecurityService protocol.
 */
+ (BOOL)handleSecurityErrorFromResponse:(NSHTTPURLResponse *)response
								   data:(nullable NSData *)data
								  error:(out NSError * __autoreleasing _Nullable * _Nullable)error
	 recoverAuthorizationRequestOptions:(out GXSecurityServiceAuthorizationRequestOptions * __autoreleasing _Nullable * _Nonnull)recoverOptions;

+ (BOOL)canLogoutEntryPoint:(nullable id <GXApplicationEntryPoint>)appEntryPoint;

+ (BOOL)showChangePasswordObject:(void(^ __nullable)(BOOL success))completionBlock;
+ (BOOL)showNotAuthorizedObject;

@end

NS_ASSUME_NONNULL_END
