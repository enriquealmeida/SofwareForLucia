//
//  GXResources.h
//  GXFlexibleClient
//
//  Created by Guillermo Pasquero on 11/1/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXLanguage.h>
#import <GXObjectsModel/GXImagesLocalization.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXResourcesTranslationType) {
	GXResourcesTranslationNone,
	GXResourcesTranslationStatic,
	GXResourcesTranslationRuntime,
};

@interface GXResources : NSObject <NSCoding>

- (instancetype)initWithLanguages:(nullable NSArray<GXLanguage *> *)languages
			   imagesLocalization:(nullable NSArray<GXImagesLocalization *> *)imagesLocalization
			  defaultLanguageName:(NSString *)defaultLanguageName
				  translationType:(GXResourcesTranslationType)translationType NS_DESIGNATED_INITIALIZER;

- (void)clearCurrentLanguage;

/*!
 Returns the image, url and gxImage for the given name
 
 @param name Name of the image
 @param image Image to be returned if found embedded
 @param url Image url to be returned if image == NULL or not found embedded (*image == nil)
 @param gxImage GXImage to be returned if found
 @discussion If gxImage != NULL, the returned image (if not nil) hasn't gxImage's properties applied (like renderingMode and scalableEdgeInsets), however, if gxImage == NULL, the returned image has gxImage's properties applied.
 */
+ (void)imageOrURLForName:(NSString *)name
					image:(out UIImage * __nullable __autoreleasing * __nullable)image
					  url:(out NSURL * __nullable __autoreleasing * __nullable)url
				  gxImage:(out GXImage * __nullable __autoreleasing * __nullable)gxImage;
+ (nullable UIImage *)imageForName:(NSString *)name;
+ (nullable NSURL *)urlForImageName:(NSString *)name;
+ (nullable NSURL *)urlForImageGuid:(NSString *)guid;

+ (NSString *)translationFor:(NSString *)message;
+ (NSString *)translationWithFormat:(NSString *)format, ... NS_REQUIRES_NIL_TERMINATION;
+ (nullable NSString *)currentLanguageName;
+ (nullable GXLanguage *)currentLanguage;
+ (nullable NSLocale *)currentLanguageLocale;

@end

NS_ASSUME_NONNULL_END
