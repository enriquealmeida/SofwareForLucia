//
//  GXTypedObjectInfo+GXSubclasses.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 14/02/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXTypedObjectInfo.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXTypedObjectInfo (GXSubclasses)

/**
 * Loads properties from metadata
 * Override point for subclasses, called from initWithMetadata:
 */
+ (void)loadPropertiesFromMetadata:(NSDictionary<NSString *, id> *)metadata
							  name:(NSString *)name
						gxDataType:(GXDataType)gxdataType
					intoProperties:(NSMutableDictionary<NSString *, id> *)properties;

/**
 * Loads dataType from metadata
 * Override point for subclasses, called from initWithMetadata:
 */
+ (GXDataType)dataTypeFromMetadata:(NSDictionary<NSString *, id> *)metadata;

+ (BOOL)shouldLoadLengthFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadDecimalsFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadRegularExpressionFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadSuggestFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadPasswordFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadInputPictureFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadBasedOnFromMetadataForDataType:(GXDataType)gxdataType;
+ (BOOL)shouldLoadImageUploadResolutionFromMetadataForDataType:(GXDataType)gxdataType;

@end

NS_ASSUME_NONNULL_END
