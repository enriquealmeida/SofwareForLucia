//
//  GXThemeClassButton.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 15/07/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>
#import <GXObjectsModel/GXThemeClassWithPadding.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassButton : GXThemeClassBase <GXThemeClassWithPadding>

@end

NS_ASSUME_NONNULL_END
