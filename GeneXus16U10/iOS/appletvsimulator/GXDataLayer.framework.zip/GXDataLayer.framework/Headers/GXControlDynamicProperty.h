//
//  GXControlDynamicProperty.h
//  GXDataLayer
//
//  Created by Fabian Inthamoussu on 18/9/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXControlDynamicPropertyType) {
	GXControlDynamicPropertyTypeProperty = 1,
	GXControlDynamicPropertyTypeMethod = 2
};

@interface GXControlDynamicPropertyBase: NSObject

@property(nonatomic, assign, readonly) GXControlDynamicPropertyType type;
@property(nonatomic, strong, readonly) NSString *controlLowercaseName;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithControlName:(NSString *)controlName NS_DESIGNATED_INITIALIZER;

- (BOOL)isSameDynamicPropertyBase:(GXControlDynamicPropertyBase *)other;

@end

@interface GXControlDynamicProperty : GXControlDynamicPropertyBase

@property(nonatomic, strong, readonly) NSString *propertyLowercaseName;
@property(nonatomic, strong, readonly) id propertyValue;

- (instancetype)initWithControlName:(NSString *)controlName NS_UNAVAILABLE;
- (instancetype)initWithControlName:(NSString *)controlName
					   propertyName:(NSString *)propertyName
					  propertyValue:(id)propertyValue;

@end

@interface GXControlDynamicMethod : GXControlDynamicPropertyBase

@property(nonatomic, strong, readonly) NSString *methodLowercaseName;
@property(nonatomic, strong, readonly) NSArray *parameters;

- (instancetype)initWithControlName:(NSString *)controlName NS_UNAVAILABLE;
- (instancetype)initWithControlName:(NSString *)controlName
						 methodName:(NSString *)methodName
						 parameters:(nullable NSArray *)parameters;

@end

NS_ASSUME_NONNULL_END

