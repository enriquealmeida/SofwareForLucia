//
//  GXWeChatLogger.h
//  GXEOWeChatInvoke-iOS
//
//  Created by José Echagüe on 1/23/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXWeChatHelper : NSObject

@property(class, nonatomic, readonly) BOOL isWeChatInstalled;
@property(class, nonatomic, readonly) BOOL isRegistered;
@property(class, nonatomic, readonly) NSString* weChatAppId;

+ (void)registerAppIfNeeded;

@end

NS_ASSUME_NONNULL_END
