//
//  GXEOAlipayInvokeOpenURLHandler.h
//  GXEOAlipayInvoke
//
//  Created by Marcos Crispino on 31/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <GXCoreBL/GXCoreBL.h>

@interface GXEOAlipayInvokeOpenURLHandler : NSObject <GXApplicationOpenURLHandler>

+ (instancetype)sharedOpenURLHandler;

+ (NSString *)customURLScheme;

@end
