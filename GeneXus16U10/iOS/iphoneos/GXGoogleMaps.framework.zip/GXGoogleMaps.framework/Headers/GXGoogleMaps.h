//
//  GXGoogleMaps.h
//  GXGoogleMaps
//
//  Created by José Echagüe on 2/19/18.
//  Copyright © 2018 genexus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXGoogleMaps.
FOUNDATION_EXPORT double GXGoogleMapsVersionNumber;

//! Project version string for GXGoogleMaps.
FOUNDATION_EXPORT const unsigned charGXGoogleMapsVersionString[];

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#if TARGET_OS_IOS
#import <GXGoogleMaps/GXGoogleMapsList.h>
#endif
