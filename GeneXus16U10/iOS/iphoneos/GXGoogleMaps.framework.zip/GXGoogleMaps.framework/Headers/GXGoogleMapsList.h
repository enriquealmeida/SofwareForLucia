//
//  GXGoogleMapsList.h
//  GXGoogleMaps-iOS
//
//  Created by José Echagüe on 2/21/18.
//  Copyright © 2018 genexus. All rights reserved.
//

@import GXCoreUI;
@import GXUCMaps;
@import GoogleMaps;

@interface GXGoogleMapsList : GXUC_MapList <GMSMapViewDelegate>

@end

