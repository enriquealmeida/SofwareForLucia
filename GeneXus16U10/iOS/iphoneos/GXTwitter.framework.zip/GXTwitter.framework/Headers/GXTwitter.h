//
//  GXTwitter.h
//  GXTwitter
//
//  Created by Fabian Inthamoussu on 25/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXTwitter.
FOUNDATION_EXPORT double GXTwitterVersionNumber;

//! Project version string for GXTwitter.
FOUNDATION_EXPORT const unsigned char GXTwitterVersionString[];

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#if TARGET_OS_IOS
#import <GXTwitter/GXEOTwitterAPI.h>
#endif // TARGET_OS_IOS
