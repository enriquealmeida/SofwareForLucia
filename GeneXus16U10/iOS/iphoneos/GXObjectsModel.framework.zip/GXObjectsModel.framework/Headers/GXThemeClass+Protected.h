//
//  GXThemeClass+Protected.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 18/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClass ()

- (instancetype)initWithName:(NSString *)name
	  propertiesValuesByName:(nullable NSDictionary<NSString *, id> *)propertiesValuesByName
				  subClasses:(nullable NSArray<__kindof GXThemeClass *> *)subClasses NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXThemeClass (Protected)

+ (NSMutableDictionary<NSString *, id> *)loadPropertiesValuesByName:(NSMutableDictionary<NSString *, id> *)propertyValuesByName
													   fromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (Class)themeSubClassClassForFullName:(NSString *)subClassFullName;
+ (NSString *)defautlThemeClassName;

- (void)replaceDefinitionWithMetadata:(nullable NSDictionary<NSString *, id> *)metadata;

- (nullable NSArray<Class> *)newRequiredSubClassesClassesArray;
- (nullable id)themePropertyValueForName:(NSString *)propertyName; // recursive = YES
- (nullable id)themePropertyValueForName:(NSString *)propertyName recursive:(BOOL)recursive;
- (BOOL)hasAllPropertiesDefault:(BOOL)recursive;

@end

NS_ASSUME_NONNULL_END
