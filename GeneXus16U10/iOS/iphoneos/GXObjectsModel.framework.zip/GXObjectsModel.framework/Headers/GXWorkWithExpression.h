//
//  GXWorkWithExpression.h
//  GXFlexibleClient
//
//  Created by willy on 2/4/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

//#define LOG

@import Foundation;
#import <GXObjectsModel/GXExpressionProtocol.h>
#import <GXObjectsModel/GXEntityDataFieldDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithExpression : NSObject <GXExpression, NSCoding>

- (instancetype)init NS_UNAVAILABLE;
- (nullable instancetype)initWithMetadata:(nullable NSDictionary<NSString *, id> *)metadata
					   dataElementsByName:(nullable NSDictionary<NSString *, id<GXEntityDataFieldDescriptor>> *)dataElementsByName
									error:(out NSError * _Nullable __autoreleasing * _Nullable)error NS_DESIGNATED_INITIALIZER;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
