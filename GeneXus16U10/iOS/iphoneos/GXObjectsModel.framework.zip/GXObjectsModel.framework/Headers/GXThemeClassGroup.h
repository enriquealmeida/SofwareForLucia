//
//  GXThemeClassGroup.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 01/09/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassContainerBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassGroup : GXThemeClassContainerBase

@property(nullable, nonatomic, strong, readonly) GXThemeClass *groupCaptionThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *groupSeparatorThemeClass;

@end

NS_ASSUME_NONNULL_END
