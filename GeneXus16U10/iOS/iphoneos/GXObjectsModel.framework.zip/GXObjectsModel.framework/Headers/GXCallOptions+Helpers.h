//
//  GXCallOptions+Helpers.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 24/2/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXCallOptions.h>

@interface GXCallOptions (Helpers)

- (BOOL)isTargetBlank;

@end
