//
//  GXViewControllerPresentationHandler.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 30/1/15.
//  Copyright (c) 2015 Artech. All rights reserved.
//

@import Foundation;
@import UIKit;
#import <GXObjectsModel/GXPresentationContext.h>

NS_ASSUME_NONNULL_BEGIN

@class GXPresentationContext;
@protocol GXControllerPresentationHandlerProtocol;

@protocol GXViewControllerPresentationHandler <GXControllerPresentationHandlerProtocol, NSObject>

@optional
- (BOOL)gxPresentViewController:(UIViewController *)viewController
						context:(nullable GXPresentationContext *)context
					 completion:(nullable void (^)(void))completion __attribute__((deprecated("Use GXControllerPresentationHandlerProtocol instead")));

- (BOOL)gxDismissViewController:(UIViewController *)viewController
					   animated:(BOOL)animated
					 completion:(nullable void (^)(void))completion __attribute__((deprecated("Use GXControllerPresentationHandlerProtocol instead")));

@end

NS_ASSUME_NONNULL_END
