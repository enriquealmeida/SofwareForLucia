//
//  GXDomainInfo.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 17/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXDomainEnumValues.h>
#import <GXObjectsModel/GXEntityDataFieldInfoProtocol.h>
#import <GXObjectsModel/GXTypedObjectInfo.h>

NS_ASSUME_NONNULL_BEGIN

@class GXDomainEnumValues;

#define kDomainInfoSpecialDomainKey @"sd"
#define kDomainInfoEnumValuesKey @"ev"

@interface GXDomainInfo : GXTypedObjectInfo

@property(nonatomic, assign, readonly) GXSpecialDomainType specialDomain;
@property(nullable, nonatomic, strong, readonly) GXDomainEnumValues *enumValues;

+ (nullable GXDomainInfo *)domainInfoForName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
