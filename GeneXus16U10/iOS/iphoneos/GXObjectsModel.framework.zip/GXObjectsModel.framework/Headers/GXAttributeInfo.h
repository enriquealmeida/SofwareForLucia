//
//  GXAttributeInfo.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXTypedObjectInfo.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXAttributeInfo : GXTypedObjectInfo

@property(nullable, nonatomic, strong, readonly) NSString *superType;
@property(nonatomic, assign, readonly) BOOL autonumber;
@property(nonatomic, assign, readonly) GXAttributeControlType controlType;
@property(nullable, nonatomic, strong, readonly) NSString *controlValues;
@property(nonatomic, assign, readonly) BOOL downloadContentOffline;

- (void)loadSuperType:(NSString *)superType; // Temporally until SuperType is included in Atts.json

+ (nullable GXAttributeInfo *)attributeInfoForName:(NSString *)name;

@end

NS_ASSUME_NONNULL_END
