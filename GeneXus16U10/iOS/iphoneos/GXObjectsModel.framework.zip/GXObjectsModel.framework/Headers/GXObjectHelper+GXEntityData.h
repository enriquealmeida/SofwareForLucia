//
//  GXObjectHelper+GXEntityData.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/10/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXEntityDataFieldDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXObjectHelper (GXEntityData)

+ (BOOL)parseAttributeOrVariableName:(out NSString * __autoreleasing __nullable * __nullable)name
								type:(out GXEntityDataFieldType * __nullable)type
								from:(nullable id)data;

@end

NS_ASSUME_NONNULL_END
