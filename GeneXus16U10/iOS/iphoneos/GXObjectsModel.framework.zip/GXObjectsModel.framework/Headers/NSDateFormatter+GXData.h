//
//  NSDateFormatter+GXData.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 28/10/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXEntityDataFieldInfoProtocol.h>

@interface NSDateFormatter (GXData)

// Calls dateFormatterWithTimeZone_UTC_ForGXEntityDataFieldInfo:useCurrentCalendar: with useCurrentCalendar = NO
+ (NSDateFormatter *)dateFormatterWithTimeZone_UTC_ForGXEntityDataFieldInfo:(id<GXEntityDataFieldInfo>)fieldInfo __attribute__((deprecated("Use dateFormatterWithTimeZone_UTC_ForGXEntityDataFieldInfo:useCurrentCalendar: instead.")));

+ (NSDateFormatter *)dateFormatterWithTimeZone_UTC_ForGXEntityDataFieldInfo:(id<GXEntityDataFieldInfo>)fieldInfo
														 useCurrentCalendar:(BOOL)useCurrentCalendar;

@end
