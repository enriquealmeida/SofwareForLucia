//
//  GXWorkWithLayoutActionBarItem.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 18/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXLayoutProtocol.h>
#import <GXObjectsModel/GXWorkWithLayoutActionBar.h>

@class GXWorkWithLayoutActionBar;

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithLayoutActionBarItem : NSObject <NSCoding, GXLayoutActionBarItem>

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXWorkWithLayoutActionBarItemWithBaseUIAction : GXWorkWithLayoutActionBarItem <GXActionUIBaseDescriptor>

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXWorkWithLayoutActionBarItemWithUIAction : GXWorkWithLayoutActionBarItemWithBaseUIAction <GXActionUIDescriptor>

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
							caption:(nullable NSString *)caption
						  imageName:(nullable NSString *)imageName
				  disabledImageName:(nullable NSString *)disabledImageName
					  imagePosition:(GXActionUIImagePosition)imagePosition
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXWorkWithLayoutActionBarActionItem : GXWorkWithLayoutActionBarItemWithUIAction <GXLayoutActionBarActionItem>

- (instancetype)initWithEventDescriptor:(id <GXEventDescriptor>)eventDesc
							controlName:(NSString *)controlName
							   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
								caption:(nullable NSString *)caption
							  imageName:(nullable NSString *)imageName
					  disabledImageName:(nullable NSString *)disabledImageName
						  imagePosition:(GXActionUIImagePosition)imagePosition
						 themeClassName:(nullable NSString *)themeClassName
								visible:(BOOL)visible
								enabled:(BOOL)enabled NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
							caption:(nullable NSString *)caption
						  imageName:(nullable NSString *)imageName
				  disabledImageName:(nullable NSString *)disabledImageName
					  imagePosition:(GXActionUIImagePosition)imagePosition
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXWorkWithLayoutActionBarDataItem : GXWorkWithLayoutActionBarItemWithBaseUIAction <GXLayoutActionBarDataItem>

- (instancetype)initWithDataElement:(id <GXLayoutElementData>)dataElement
						controlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position NS_UNAVAILABLE;
- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

@interface GXWorkWithLayoutActionBarGroupItem : GXWorkWithLayoutActionBarItemWithUIAction <GXLayoutActionBarGroupItem>

- (instancetype)initWithActionBarGroup:(GXWorkWithLayoutActionBar *)actionBarGroup
						   controlName:(NSString *)controlName
							  position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
							   caption:(nullable NSString *)caption
							 imageName:(nullable NSString *)imageName
					 disabledImageName:(nullable NSString *)disabledImageName
						 imagePosition:(GXActionUIImagePosition)imagePosition
						themeClassName:(nullable NSString *)themeClassName
							   visible:(BOOL)visible
							   enabled:(BOOL)enabled NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithControlName:(NSString *)controlName
						   position:(id<GXActionBarUIPositionDescriptor, NSCoding>)position
							caption:(nullable NSString *)caption
						  imageName:(nullable NSString *)imageName
				  disabledImageName:(nullable NSString *)disabledImageName
					  imagePosition:(GXActionUIImagePosition)imagePosition
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end



#pragma mark - GXDeprecated


#if TARGET_OS_IOS
@interface GXWorkWithLayoutActionBarItem (GXDeprecated)

- (instancetype)initWithControlName:(NSString *)controlName
					   positionType:(GXActionBarUIPositionType)positionType
						   priority:(GXActionBarUIPriorityType)priority
							 hAlign:(GXHorizontalAlignType)hAlign
							 vAlign:(GXVerticalAlignType)vAlign __attribute__((deprecated("Use initWithControlName:position: instead")));

@end

@interface GXWorkWithLayoutActionBarItemWithBaseUIAction (GXDeprecated)

- (instancetype)initWithControlName:(NSString *)controlName
					   positionType:(GXActionBarUIPositionType)positionType
						   priority:(GXActionBarUIPriorityType)priority
							 hAlign:(GXHorizontalAlignType)hAlign
							 vAlign:(GXVerticalAlignType)vAlign
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled __attribute__((deprecated("Use initWithControlName:position:themeClassName:visible:enabled: instead")));

@end

@interface GXWorkWithLayoutActionBarItemWithUIAction (GXDeprecated)

- (instancetype)initWithControlName:(NSString *)controlName
					   positionType:(GXActionBarUIPositionType)positionType
						   priority:(GXActionBarUIPriorityType)priority
							 hAlign:(GXHorizontalAlignType)hAlign
							 vAlign:(GXVerticalAlignType)vAlign
							caption:(nullable NSString *)caption
						  imageName:(nullable NSString *)imageName
				  disabledImageName:(nullable NSString *)disabledImageName
					  imagePosition:(GXActionUIImagePosition)imagePosition
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled __attribute__((deprecated("Use initWithControlName:position:caption:imageName:disabledImageName:imagePosition:themeClassName:visible:enabled: instead")));

@end

@interface GXWorkWithLayoutActionBarActionItem (GXDeprecated)

- (instancetype)initWithEventDescriptor:(id <GXEventDescriptor>)eventDesc
							controlName:(NSString *)controlName
						   positionType:(GXActionBarUIPositionType)positionType
							   priority:(GXActionBarUIPriorityType)priority
								 hAlign:(GXHorizontalAlignType)hAlign
								 vAlign:(GXVerticalAlignType)vAlign
								caption:(nullable NSString *)caption
							  imageName:(nullable NSString *)imageName
					  disabledImageName:(nullable NSString *)disabledImageName
						  imagePosition:(GXActionUIImagePosition)imagePosition
						 themeClassName:(nullable NSString *)themeClassName
								visible:(BOOL)visible
								enabled:(BOOL)enabled __attribute__((deprecated("Use initWithEventDescriptor:controlName:position:caption:imageName:disabledImageName:imagePosition:themeClassName:visible:enabled: instead")));

@end

@interface GXWorkWithLayoutActionBarDataItem (GXDeprecated)

- (instancetype)initWithDataElement:(id <GXLayoutElementData>)dataElement
						controlName:(NSString *)controlName
					   positionType:(GXActionBarUIPositionType)positionType
						   priority:(GXActionBarUIPriorityType)priority
							 hAlign:(GXHorizontalAlignType)hAlign
							 vAlign:(GXVerticalAlignType)vAlign
					 themeClassName:(nullable NSString *)themeClassName
							visible:(BOOL)visible
							enabled:(BOOL)enabled __attribute__((deprecated("Use initWithDataElement:controlName:position:themeClassName:visible:enabled: instead")));

@end

@interface GXWorkWithLayoutActionBarGroupItem (GXDeprecated)

- (instancetype)initWithActionBarGroup:(GXWorkWithLayoutActionBar *)actionBarGroup
						   controlName:(NSString *)controlName
						  positionType:(GXActionBarUIPositionType)positionType
							  priority:(GXActionBarUIPriorityType)priority
								hAlign:(GXHorizontalAlignType)hAlign
								vAlign:(GXVerticalAlignType)vAlign
							   caption:(nullable NSString *)caption
							 imageName:(nullable NSString *)imageName
					 disabledImageName:(nullable NSString *)disabledImageName
						 imagePosition:(GXActionUIImagePosition)imagePosition
						themeClassName:(nullable NSString *)themeClassName
							   visible:(BOOL)visible
							   enabled:(BOOL)enabled __attribute__((deprecated("Use initWithActionBarGroup:controlName:position:caption:imageName:disabledImageName:imagePosition:themeClassName:visible:enabled: instead")));

@end
#endif // TARGET_OS_IOS

NS_ASSUME_NONNULL_END
