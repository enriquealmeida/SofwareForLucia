//
//  GXProcedureModel.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 08/03/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXProcedureParameter.h>

typedef NS_ENUM(uint_least8_t, GXProcedureModelType) {
	GXProcedureModelTypeProcedure,
	GXProcedureModelTypeDataprovider
};

@interface GXProcedureModel : GXNamedElement {
    NSArray<GXProcedureParameter *> *_parameters;
}

@property(nonatomic, strong, readonly) NSArray<GXProcedureParameter *> *parameters;
@property (nonatomic, assign, readonly) GXProcedureModelType procType;
@property (nonatomic, assign, readonly) GXConnectivitySupportType connectivitySupport;

+ (id)procedureModelFromMetadata:(NSDictionary<NSString *, id> *)metadata error:(NSError * __autoreleasing *)error;

- (id)initWithName:(NSString *)name
			  type:(GXProcedureModelType)type
		parameters:(NSArray<GXProcedureParameter *> *)params
connectivitySupport:(GXConnectivitySupportType)connSupport;

@end
