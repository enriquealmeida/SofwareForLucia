//
//  GXApplicationImageUploadSettings.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 16/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
@import CoreGraphics;

typedef NS_ENUM(uint_least8_t, GXImageUploadSizeType) {
	GXImageUploadSizeInKBs,
	GXImageUploadSizeInDimensions
};

typedef NS_ENUM(uint_least8_t, GXImageUploadResolutionType) {
	GXImageUploadResolutionActualSize,
	GXImageUploadResolutionLarge,
	GXImageUploadResolutionMedium,
	GXImageUploadResolutionSmall,
};

GXImageUploadResolutionType GXImageUploadResolutionTypeSmallestResolution(GXImageUploadResolutionType first, GXImageUploadResolutionType second);

#define kGXImageDefaultUploadResolution GXImageUploadResolutionLarge

@interface GXApplicationImageUploadSettings : NSObject <NSCoding>

+ (__kindof GXApplicationImageUploadSettings *)imageUploadSettingsFromMetadata:(NSDictionary<NSString *, id> *)metadata;

+ (GXImageUploadResolutionType)imageUploadReslutionFromMetadataValue:(NSString *)metadataValue;

- (instancetype)initWithDefaultResolutionType:(GXImageUploadResolutionType)defaulResolutionType;

@property(nonatomic, assign, readonly) GXImageUploadSizeType imageUploadSizeType;
@property(nonatomic, assign, readonly) GXImageUploadResolutionType imageUploadDefaultResolution;

@end

// imageUploadSizeType == GXImageUploadSizeInKBs
@interface GXApplicationImageUploadInKBsSettings : GXApplicationImageUploadSettings

- (instancetype)initWithDefaultResolutionType:(GXImageUploadResolutionType)defaulResolutionType
						  largeImageSizeInKBs:(float)largeImageSizeInKBs
						 mediumImageSizeInKBs:(float)mediumImageSizeInKBs
						  smallImageSizeInKBs:(float)smallImageSizeInKBs;

@property(nonatomic, assign, readonly) float largeImageSizeInKBs;
@property(nonatomic, assign, readonly) float mediumImageSizeInKBs;
@property(nonatomic, assign, readonly) float smallImageSizeInKBs;

@end

// imageUploadSizeType == GXImageUploadSizeInDimensions
@interface GXApplicationImageUploadInDimensionsSettings : GXApplicationImageUploadSettings

- (instancetype)initWithDefaultResolutionType:(GXImageUploadResolutionType)defaulResolutionType
				   largeImageSizeInDimensions:(CGSize)largeImageSizeInDimensions
				  mediumImageSizeInDimensions:(CGSize)mediumImageSizeInDimensions
				   smallImageSizeInDimensions:(CGSize)smallImageSizeInDimensions;

@property (nonatomic, assign, readonly) CGSize largeImageSizeInDimensions;
@property (nonatomic, assign, readonly) CGSize mediumImageSizeInDimensions;
@property (nonatomic, assign, readonly) CGSize smallImageSizeInDimensions;

@end
