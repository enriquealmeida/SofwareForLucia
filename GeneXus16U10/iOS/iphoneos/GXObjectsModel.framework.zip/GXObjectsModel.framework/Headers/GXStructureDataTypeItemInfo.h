//
//  GXStructureDataTypeItemInfo.h
//  GXFlexibleClient
//
//  Created by willy on 8/9/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXEntityDataFieldDescriptorProtocol.h>
#import <GXObjectsModel/GXTypedObjectInfo.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXStructureDataTypeItemInfo : GXTypedObjectInfo <GXEntityDataFieldVariableDescriptor>
@property(nullable, strong, nonatomic, readonly) NSString *jsonName;
@property(assign, nonatomic, readonly) BOOL jsonSerializeWhenEmpty;
@property(assign, nonatomic, readonly) BOOL jsonCollectionSerializeAsSequence;
@end

NS_ASSUME_NONNULL_END
