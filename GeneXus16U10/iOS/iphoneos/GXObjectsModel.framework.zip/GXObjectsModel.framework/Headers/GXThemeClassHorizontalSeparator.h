//
//  GXThemeClassHorizontalSeparator.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 19/03/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>
#import <GXObjectsModel/GXThemeClassWithBackground.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassHorizontalSeparator : GXThemeClass <GXThemeClassWithBackground>

@property(nonatomic, assign, readonly) CGFloat height;

@end

NS_ASSUME_NONNULL_END
