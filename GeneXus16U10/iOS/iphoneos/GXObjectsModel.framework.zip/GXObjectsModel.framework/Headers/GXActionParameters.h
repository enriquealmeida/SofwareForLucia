//
//  GXActionParameters.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXActionDescriptorProtocol.h>
#import <GXObjectsModel/GXActionParameter.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXActionParameters : NSObject <NSCoding, GXActionParametersDescriptor>

- (instancetype)initWithParameters:(nullable NSArray<id<GXActionParameterDescriptor>> *)parameters NS_DESIGNATED_INITIALIZER;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

+ (nullable instancetype)actionParametersFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata
									 withDataElements:(nullable NSDictionary<NSString *, id<GXEntityDataFieldDescriptor>> *)dataElementsByName
												error:(NSError * __nullable * __nullable)error;

+ (nullable __kindof GXActionParameter *)actionParameterFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata
											   expressionElementName:(NSString *)exprElementName
													withDataElements:(nullable NSDictionary<NSString *, id<GXEntityDataFieldDescriptor>> *)dataElementsByName
															   error:(NSError * __nullable * __nullable)error;

@end

NS_ASSUME_NONNULL_END
