//
//  GXEntityHelper+GXUIImage.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 22/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
@import UIKit;
#import <GXObjectsModel/GXEntityHelper.h>
#import <GXObjectsModel/GXImage.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEntityHelper (GXUIImage)

+ (void)imageAndURLFromFieldValue:(nullable id)fieldValue
							image:(out UIImage * __autoreleasing __nullable * __nullable)image
							  url:(out NSURL * __autoreleasing __nullable * __nullable)url
						  gxImage:(out GXImage * __autoreleasing __nullable * __nullable)gxImage;

@end

NS_ASSUME_NONNULL_END
