//
//  UIBarButtonItem+GXImageWebCache.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 5/9/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/UIBarButtonItem+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIBarButtonItem (GXImageWebCache)

- (instancetype)initWithGXImageName:(NSString *)imageName
							  style:(UIBarButtonItemStyle)style
							 target:(nullable id)target
							 action:(nullable SEL)action;

- (instancetype)initWithGXImageName:(NSString *)imageName
							  style:(UIBarButtonItemStyle)style
				  targetActionBlock:(void (^)(void))block;


- (void)gxSetImageNamed:(nullable NSString *)imageName;
- (void)gxSetBackgroundImageNamed:(nullable NSString *)imageName;
#if TARGET_OS_IOS
- (void)gxSetBackButtonBackgroundImageNamed:(nullable NSString *)imageName;
#endif // TARGET_OS_IOS

+ (UIImage *)gxEmptyBackgroundImage;
- (void)gxLoadEmptyBackgroundImage;
#if TARGET_OS_IOS
- (void)gxLoadEmptyBackBackgroundImage;
#endif // TARGET_OS_IOS

@end

NS_ASSUME_NONNULL_END
