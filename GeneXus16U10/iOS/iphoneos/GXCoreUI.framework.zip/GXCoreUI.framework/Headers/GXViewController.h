//
//  GXViewController.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/02/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import GXObjectsModel;
@import GXObjectsModel.Swift;
#import <GXCoreUI/GXApplicationBarsAppearance.h>
#import <GXCoreUI/GXCallerDelegate.h>
#import <GXCoreUI/GXControllerProtocol.h>
#import <GXCoreUI/GXWindow.h>
#import <GXCoreUI/UIViewController+GXPropertiesObject.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXViewControllerReturnState) {
	GXViewControllerReturnStateSuccess __deprecated_enum_msg("Use GXControllerReturnStateSuccess instead.") = GXControllerReturnStateSuccess,
	GXViewControllerReturnStateUserCancelled __deprecated_enum_msg("Use GXControllerReturnStateUserCancelled instead.") = GXControllerReturnStateUserCancelled
};

typedef NS_OPTIONS(uint_least8_t, GXViewControllerBarType) {
	GXViewControllerBarTypeNavigationBar = 1 << 0,
	GXViewControllerBarTypeToolbar = 1 << 1
};

@interface GXViewController : UIViewController <GXControllerProtocol, GXControllerPresentationHandlerProtocol, GXActionHandlerUserInterfaceControllerProtocol, GXActionHandlerUIDelegate> {
@protected
	GXConnectivitySupportType _connSupport;
}

@property(nullable, nonatomic, weak) id <GXCallerDelegate> callerDelegate;
@property(assign, readonly) GXViewVisibleStateType viewVisibleState;
@property(assign, readonly) NSUInteger viewAppearedCount; // Number of times that viewDidAppear was triggered for this panel
@property(nullable, nonatomic, strong, readonly) UIView *contentView;
@property(nonatomic, assign ,readonly) UIEdgeInsets gxSafeAreaInsets;
@property(nonatomic, strong, readonly) id <GXMutablePropertiesObject> properties;
@property(nonatomic, assign, readonly) GXConnectivitySupportType connectivitySupport; // Resolved connectivity support (Online or Offline)
@property(nullable, nonatomic, strong, readonly) NSString *formClassFullNameForCurrentMode;
@property(nonatomic, assign, readonly) GXObjectType gxObjectType;
@property(nonatomic, strong, readonly) NSString *gxObjectName;
@property(nonatomic, strong, readonly) NSString *gxObjectFullName;
@property(nonatomic, assign) GXActionHandlerConcurrencyMode defaultActionConcurrencyMode;
@property(nonatomic, assign) BOOL startExecuted;

- (void)viewWillLayoutSubviews __attribute__((objc_requires_super));
- (void)viewDidLayoutSubviews __attribute__((objc_requires_super));

- (void)onApplicationDidBecomeActive __attribute__((objc_requires_super));

- (nullable id <GXEventDescriptor>)backEventDescriptor;
- (void)updateStateWithCurrentBackEventDescriptor;


- (BOOL)executeAction:(id<GXActionHandler>)actionHandler
withContextEntityData:(nullable id<GXEntityDataWithOverrideValues>)entityData
			   sender:(nullable id)sender
 userInterfaceContext:(nullable GXUserInterfaceContext *)uiContext;

- (BOOL)onActionHandler:(id<GXActionHandler>)actionHandler didFinishExecutingWithError:(nullable NSError *)error;

- (BOOL)isActionExecuting:(id <GXActionHandler>)actionHandler;

// Sets the navigationItem title or titleView with the given title. Retuns YES if title was updated, NO otherwise
- (BOOL)setNavigationTitle:(nullable NSString *)title;

/**
 * Delegates the task to current root controller
 */
- (void)clearViewControllerLeftNavigationItemAnimated:(BOOL)animated;
- (void)clearViewControllerRightNavigationItemAnimated:(BOOL)animated;

/**
 * If item is nil calls corresponding clearViewControllerLeftNavigationItemAnimated,
 * Otherwise sets self.navigationItem left/right item
 */
- (void)setLeftNavigationItem:(nullable UIBarButtonItem *)item animated:(BOOL)animated;
- (void)setRightNavigationItem:(nullable UIBarButtonItem *)item animated:(BOOL)animated;

/**
 * If items is empty (or nil) calls corresponding clearViewControllerLeftNavigationItemAnimated,
 * Otherwise sets self.navigationItem left/right items
 */
- (void)setLeftNavigationItems:(nullable NSArray<UIBarButtonItem *> *)items animated:(BOOL)animated;
- (void)setRightNavigationItems:(nullable NSArray<UIBarButtonItem *> *)items animated:(BOOL)animated;

#pragma mark Actions UI Items

#if TARGET_OS_IOS
- (void)refreshToolbarVisibility:(BOOL)animated; // If viewVisibleState is Appeared or Appearing, then sets the toolbar visible/hidden if there are toolbar items and self.showGxApplicationBars
#endif // TARGET_OS_IOS

- (BOOL)actionBarAnimationNeeded; // Returns YES if viewVisibleState is Appeared or Appearing & not canIgnoreActionBarAnimation, NO otherwise
- (BOOL)canIgnoreActionBarAnimation; // Returns YES if viewAppearedCount is 0 and is first and only controller in navigation controller, NO otherwise

- (void)updateActionBarActionsDefaultAppBarThemeClass;

#pragma mark Standard Actions UI Items

#if TARGET_OS_IOS
- (BOOL)hidesStandardBackButton;

- (UIBarButtonItem *)gxCloseBarButtonItem;
- (void)handleGXCloseEvent:(nullable id)sender;
#endif // TARGET_OS_IOS

@end

#if TARGET_OS_IOS
@interface GXViewController (Deprecated)

@property(nonatomic, assign) BOOL enableMultipleActionRunningInstances __attribute__((deprecated("Use defaultActionConcurrencyMode instead.")));
@property(nonatomic, assign, readonly) GXVerticalEdgeInsets gxLayoutGuide __attribute__((deprecated("Use gxSafeAreaInsets instead.")));
@property(nonatomic, assign, readonly) BOOL showAds __attribute__((deprecated("Always returns NO.")));
@property(nonatomic, assign, readonly) GXAdsPositionType adsPosition __attribute__((deprecated("Always returns GXAdsPositionNone.")));
@property(nonatomic, assign, readonly) CGFloat contentViewAdsInset __attribute__((deprecated("Always returns 0.")));

@end
#endif // TARGET_OS_IOS

NS_ASSUME_NONNULL_END
