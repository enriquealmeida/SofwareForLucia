//
//  SDMapPinImageThemeClass.h
//  GXUCMaps
//
//  Created by Marcos Crispino on 13/1/15.
//
//

@import GXObjectsModel;

NS_ASSUME_NONNULL_BEGIN

@interface SDMapPinImageThemeClass : GXThemeClass

@property (nonatomic, assign, readonly) NSInteger pinImageHeight;
@property (nonatomic, assign, readonly) NSInteger pinImageWidth;
@property (nonatomic, assign, readonly) GXImageScaleType pinImageScaleType;

@end

NS_ASSUME_NONNULL_END
