//
//  GXEntityListFilterAdvancedViewController.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 31/01/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import GXObjectsModel;
@import GXDataLayer;
#import <GXCoreUI/GXEntityDataFieldViewController.h>
#import <GXCoreUI/GXCallerDelegate.h>

@class GXEntityListFilterAdvancedViewController;

#pragma mark -

@protocol GXEntityListFilterAdvancedViewControllerDelegate <GXInheritedConnectivitySupportResolver>

@required

- (void)entityListFilterAdvancedViewController:(GXEntityListFilterAdvancedViewController *)controller
					   didResolveToFieldValues:(NSDictionary<NSString *, id<GXEntityListFilterAdvancedFieldValue>> *)values
									 withOrder:(id<GXEntityListOrder>)order;

@end

#pragma mark -

/**
 * Default GXApplicationBarsAppearance gxApplicationBarsClassName method implementation returns nil
 * This class implements setGxApplicationBarsClassName:, callers can use this method to change the class
 */
@interface GXEntityListFilterAdvancedViewController : UITableViewController <UITextFieldDelegate, GXEntityDataFieldEditorViewControllerDelegate, GXEntityListFilterAdvancedViewControllerDelegate, GXCallerDelegate, GXApplicationBarsAppearance>
{
	id <GXEntityListFilterAdvanced> _filter;
	NSMutableDictionary<NSString *, id<GXEntityListFilterAdvancedFieldValue>> *_filterValuesByName;
    NSMutableDictionary *_filterDescriptionsByName;
	NSMutableDictionary *_defaultFieldValuesByName;
	id <GXEntityListFilterAdvancedViewControllerDelegate> __weak _delegate;
	
	NSArray *_orders;
	
	NSIndexPath *_pickerIndex;
	
	id<GXEntityDataFieldInfo> _rangePickerFieldInfo;
	
	NSInteger _selectedOrderIndex;
	
	id _context;
	
	NSDictionary *_relationsByDataElementName;
	
	UITextField *_currentEditingTextField;
	UITapGestureRecognizer *_tapGestureRecognizer;
}

@property(nonatomic, strong, readonly) id <GXEntityListFilterAdvanced> entityListFilterAdvanced;
@property(nonatomic, strong, readonly) NSArray *entityListOrders;
@property(weak) id <GXEntityListFilterAdvancedViewControllerDelegate> delegate;
@property (nonatomic, strong) id context;
@property (nonatomic, strong) NSDictionary *relationsByDataElementName;

/**
 * When using the view controller as a "range picker", this is the field info to use to get/set the values
 */
@property(nonatomic, strong) id<GXEntityDataFieldInfo> rangePickerFieldInfo;

- (id)initWithFilter:(id<GXEntityListFilterAdvanced>)filter
		filterValues:(NSArray<id<GXEntityListFilterAdvancedFieldValue>> *)filterValues
			  orders:(NSArray *)orders
	   selectedOrder:(NSUInteger)selectedOrder
		   relations:(NSDictionary *)relationsByDataElementName;

@end
