//
//  GXThemeHelper+GXThemeClassWithBackground.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/2/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXCoreUI/GXBackgroundViewContainerProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeHelper (GXThemeClassWithBackground)

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
			  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
					 toView:(UIView *)view
		backgroundImageView:(inout UIImageView * __nullable __autoreleasing * __nullable)bgImageView
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds
	   applyBackgroundColor:(BOOL)applyBgColor;

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
			  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
					 toView:(UIView *)view
		backgroundImageView:(inout UIImageView * __nullable __autoreleasing * __nullable)bgImageView
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds;

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
			  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
					 toView:(UIView *)view
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds;

+ (void)applyThemeClassBackgroundImages:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
						  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
								 toView:(UIView *)parentView
					backgroundImageView:(inout UIImageView * __nullable __autoreleasing * _Nonnull)bgImageView;

+ (void)applyBackgroundImagesToView:(UIView *)parentView
				backgroundImageView:(inout UIImageView * __nullable __autoreleasing * _Nonnull)bgImageView
				backgroundImageName:(nullable NSString *)bgImageName
		 highlightedBackgroundImage:(nullable NSString *)hBgImageName
				backgroundImageMode:(GXBackgroundImageMode)backgroundImageMode;

+ (void)applyThemeClassBaseHighligthBackgroundColor:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
									  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
											 toView:(UIView *)view
										highlighted:(BOOL)highlighted
										   animated:(BOOL)animated;

+ (void)applyThemeClassBaseHighligthBackgroundColor:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
									  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
											 toView:(UIView *)view
										highlighted:(BOOL)highlighted
										   animated:(BOOL)animated
									 backgroundView:(nullable UIImageView *)bgView;

+ (void)applyThemeClassBaseHighligthBackgroundColor:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
									  withOverrides:(nullable id<GXThemeClassPropertiesOverrides>)themeClassOverrides
											 toView:(UIView *)view
								   highlightedBlock:(BOOL(^)(void))isHighlighted
										   animated:(BOOL)animated
									 backgroundView:(nullable UIImageView *)bgView;

+ (void)applyBackgroundColor:(nullable UIColor *)color
					  toView:(UIView *)view
					 oldView:(UIView *)oldView
					animated:(BOOL)animated;

+ (void)applyBackgroundColor:(nullable UIColor *)color
					  toView:(UIView *)view
					animated:(BOOL)animated;

+ (void)applyHighligth:(BOOL)highlighted
			  animated:(BOOL)animated
	  toBackgroundView:(UIImageView *)bgView;

+ (void)applyHighligthWithBlock:(BOOL(^)(void))isHighlighted
					   animated:(BOOL)animated
			   toBackgroundView:(UIImageView *)bgView;

/**
 * Applies the background color and background image from the Application theme class to the given view
 * Calls applyApplicationBackgroundFromCurrentThemeToView:view withDefaultBackgroundColor:nil
 */
+ (void)applyApplicationBackgroundFromCurrentThemeToView:(UIView *)view;

/**
 * Applies the background color and background image from the Application theme class to the given view
 * If the Application class doesn't have a background color, the default background color parameter is used if not nil
 */
+ (void)applyApplicationBackgroundFromCurrentThemeToView:(UIView *)view withDefaultBackgroundColor:(nullable UIColor *)defBgColor;

+ (void)applyBackgroundColor:(nullable UIColor *)bgColor toViewControllerIfNeeded:(UIViewController *)controller;

@end


@interface GXThemeHelper (GXThemeClassWithBackground_DEPRECATED)

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
					 toView:(UIView *)view
		backgroundImageView:(inout UIImageView * __nullable __autoreleasing * __nullable)bgImageView
		backgroundImageName:(nullable NSString *)fallbackBgImageName
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds
	   applyBackgroundColor:(BOOL)applyBgColor __attribute__((deprecated("Use applyThemeClassBase:withOverrides:toView:backgroundImageView:borderView:borderBounds:applyBackgroundColor: instead")));

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
					 toView:(UIView *)view
		backgourndImageView:(inout UIImageView * __nullable __autoreleasing * __nullable)bgImageView
		backgourndImageName:(nullable NSString *)fallbackBgImageName
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds __attribute__((deprecated("Use applyThemeClassBase:withOverrides:toView:backgroundImageView:borderView:borderBounds: instead")));

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
					 toView:(UIView *)view
		backgourndImageView:(inout UIImageView * __nullable __autoreleasing * __nullable)bgImageView
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds __attribute__((deprecated("Use applyThemeClassBase:withOverrides:toView:backgroundImageView:borderView:borderBounds: instead")));

+ (void)applyThemeClassBase:(nullable GXThemeClass<GXThemeClassWithBackground, GXThemeClassWithBorder> *)themeClass
					 toView:(UIView *)view
				 borderView:(inout UIView * __nullable __autoreleasing * __nullable)borderView
			   borderBounds:(CGRect)borderBounds __attribute__((deprecated("Use applyThemeClassBase:withOverrides:toView:borderView:borderBounds: instead")));

+ (void)applyThemeClassBackgroundImages:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
								 toView:(UIView *)parentView
					backgroundImageView:(inout UIImageView * __nullable __autoreleasing * _Nonnull)bgImageView
					backgroundImageName:(nullable NSString *)fallbackBgImageName __attribute__((deprecated("Use applyThemeClassBase:withOverrides:toView:backgroundImageView: instead")));

+ (void)applyThemeClassBackgroundImages:(nullable GXThemeClass<GXThemeClassWithBackground> *)themeClass
								 toView:(UIView *)parentView
					backgroundImageView:(inout UIImageView * __nullable __autoreleasing * _Nonnull)bgImageView __attribute__((deprecated("Use applyThemeClassBackgroundImages:withOverrides:toView:backgroundImageView: instead")));

@end

NS_ASSUME_NONNULL_END
