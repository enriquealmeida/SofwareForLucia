//
//  UIImageView+GXImageWebCache.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 30/8/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/UIImageView+HighlightedWebCache.h>
#import <GXCoreUI/UIImageView+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

typedef UIImage * _Nonnull (^GXImageWebCacheTransformImage)(UIImage *image, GXImage * _Nullable gxImage, BOOL isEmbededImage);
typedef UIImage * _Nullable (^GXImageWebCachePlaceholderImageProvider)(NSString * __autoreleasing _Nullable * _Nullable placeholderImageName,
																		NSURL * __autoreleasing _Nullable * _Nullable placeholderImageURL,
																		GXImage *  __autoreleasing _Nullable * _Nullable placeholderGxImage);

@interface UIImageView (GXImageWebCache)

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithBackgroundMode:(GXBackgroundImageMode)bgMode
																		  scaleType:(GXImageScaleType)scaleType
																	  renderingMode:(GXImageRenderingMode)renderingMode
																		flipsForRTL:(GXOptionalBoolean)flipsForRTL;

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithBackgroundMode:(GXBackgroundImageMode)bgMode
																		  scaleType:(GXImageScaleType)scaleType
																	  renderingMode:(GXImageRenderingMode)renderingMode __attribute__((deprecated("Use gxDefaultImageTransformWithBackgroundMode:scaleType:renderingMode:flipsForRTL: instead")));

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithBackgroundMode:(GXBackgroundImageMode)bgMode;
- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithScaleType:(GXImageScaleType)scaleType;
- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithRenderingMode:(GXImageRenderingMode)renderingMode;
- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithFlipsForRTL:(GXOptionalBoolean)flipsForRTL;

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithThemeClass:(nullable GXThemeClass *)themeClass;

+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithImage:(nullable UIImage *)image;
+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithImageName:(nullable NSString *)imageName;
+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithThemeClass:(nullable GXThemeClass *)themeClass;

#pragma mark - Image & Highlighted Image with name

- (void)gxSetImageNamed:(nullable NSString *)imageName highlightedImageNamed:(nullable NSString *)hImageName;

- (void)gxSetImageNamed:(nullable NSString *)imageName
  highlightedImageNamed:(nullable NSString *)hImageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider;

- (void)gxSetImageNamed:(nullable NSString *)imageName
  highlightedImageNamed:(nullable NSString *)hImageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
		 transformImage:(UIImage *(^ _Nullable)(UIImage *image, GXImage * _Nullable gxImage, BOOL isEmbededImage, BOOL isHighlightedImage))transformImage;

#pragma mark - Image with name

- (void)gxSetImageNamed:(nullable NSString *)imageName;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
		 transformImage:(nullable GXImageWebCacheTransformImage)transformImage;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
		 transformImage:(nullable GXImageWebCacheTransformImage)transformImage
				options:(GXWebImageOptions)options
			   progress:(nullable GXWebImageDownloaderProgressBlock)progressBlock
			  completed:(nullable GXWebImageCompletionBlock)completedBlock;

- (void)gxSetImageNamed:(nullable NSString *)imageName themeClass:(nullable GXThemeClass *)themeClass;

#pragma mark - Highlighted Image with name

- (void)gxSetHighlightedImageNamed:(nullable NSString *)imageName;

- (void)gxSetHighlightedImageNamed:(nullable NSString *)imageName
					transformImage:(nullable GXImageWebCacheTransformImage)transformImage;

- (void)gxSetHighlightedImageNamed:(nullable NSString *)imageName
					transformImage:(nullable GXImageWebCacheTransformImage)transformImage
						   options:(GXWebImageOptions)options
						  progress:(nullable GXWebImageDownloaderProgressBlock)progressBlock
						 completed:(nullable GXWebImageCompletionBlock)completedBlock;

#pragma mark - Placeholder

- (void)gxSetPlaceHolderImageAsFinalImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider;
- (void)gxSetPlaceHolderImageAsFinalImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
								completed:(nullable GXWebImageCompletionBlock)completedBlock;

@end




@interface UIImageView (GXEntityDataImageWebCache)

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue
						  placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
							transformImage:(nullable GXImageWebCacheTransformImage)transformImage;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue
						  placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
							transformImage:(nullable GXImageWebCacheTransformImage)transformImage
								   options:(GXWebImageOptions)options
								  progress:(nullable GXWebImageDownloaderProgressBlock)progressBlock
								 completed:(nullable GXWebImageCompletionBlock)completedBlock;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue themeClass:(nullable GXThemeClass *)themeClass;

@end

NS_ASSUME_NONNULL_END
