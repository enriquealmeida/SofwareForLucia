//
//  GXScrollView.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 28/12/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@interface GXScrollView : UIScrollView

@property(nullable, nonatomic, strong) UIView *backgroundView;
@property(nonatomic, assign) BOOL scaleBackgroundViewToContentSize;

@end

void GXScrollToMakeViewVisible(UIView * _Nonnull viewToMakeVisible, UIView * _Nullable upToView, BOOL animated); // Same as GXScrollToMakeViewRectVisible(viewToMakeVisible.frame, viewToMakeVisible.superview, upToView, animated) if viewToMakeVisible.superview != nil.
void GXScrollToMakeViewRectVisible(CGRect rectToMakeVisible, UIView * _Nonnull rectToMakeVisibleView, UIView * _Nullable upToView, BOOL animated);

NS_ASSUME_NONNULL_END
