//
//  GXEntityViewController+GXDeprecated.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 9/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXCoreUI/GXEntityViewController.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEntityViewController (GXDeprecated)

#pragma mark - Control Properties

- (nullable NSDictionary<NSString *, id> *)controlPropertiesForControlName:(NSString *)controlName __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (nullable id)controlPropertyValueForPropertyName:(NSString *)propName controlName:(NSString *)controlName __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (void)setControlPropertyValue:(nullable id)propValue forPropertyName:(NSString *)propName controlName:(NSString *)controlName __attribute__((deprecated("Use GXControlActionBarItem instead")));

#pragma mark - Actions Methods

// Returns a new collection of GXEntityActionBarItemActionReference for the specified mode
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)loadMoreItemsActionReferencesForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
/*
 Returns a the collection of GXEntityActionBarItemActionReference for the specified mode and
 calls loadMoreItemsActionReferencesForMode: if the collection needs to be loaded
 */
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)moreItemActionsReferencesForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)moreItemActionsReferencesForCurrentMode __attribute__((deprecated("Use GXControlActionBarItem instead")));

// Returns a new collection of GXEntityActionBarItemActionReference for the specified mode
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)loadNavigationBarActionReferencesForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
/*
 Returns a the collection of GXEntityActionBarItemActionReference for the specified mode and
 calls loadNavigationBarActionReferencesForMode: if the collection needs to be loaded
 */
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)navigationBarActionDescriptorsForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)navigationBarActionDescriptorsForCurrentMode __attribute__((deprecated("Use GXControlActionBarItem instead")));

// Returns a new collection of GXEntityActionBarItemActionReference for the specified mode
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)loadToolbarActionReferencesForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
/*
 Returns a the collection of GXEntityActionBarItemActionReference for the specified mode and
 calls loadToolbarActionReferencesForMode: if the collection needs to be loaded
 */
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)toolbarActionReferencesForMode:(GXModeType)mode __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)toolbarActionReferencesForCurrentMode __attribute__((deprecated("Use GXControlActionBarItem instead")));

/*
 The next methods clears caches of actions references
 */
- (void)setNeedsToReloadActionBarActionsForMode:(GXModeType)mode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadActionBarActionsForCurrentMode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadMoreItemActionsForMode:(GXModeType)mode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadMoreItemActionsForCurrentMode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadNavigationBarActionsForMode:(GXModeType)mode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadNavigationBarActionsForCurrentMode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadToolbarActionsForMode:(GXModeType)mode __attribute__((deprecated("Use invalidateLoadedActions instead")));
- (void)setNeedsToReloadToolbarActionsForCurrentMode __attribute__((deprecated("Use invalidateLoadedActions instead")));

#pragma mark Actions UI Items

- (nullable UIBarButtonItem *)buttonItemForEntityActionReference:(GXEntityActionBarItemReference *)actionRef
										   actionHandlerSelector:(SEL)actionHandler __attribute__((deprecated("Use GXControlActionBarItem instead")));

#pragma mark Actions Handlers

- (BOOL)handleActionReference:(GXEntityActionBarItemReference *)actionRef sender:(nullable id)sender __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (BOOL)handleActionReference:(NSArray<GXEntityActionBarItemReference *> *)actionReferences atIndex:(NSInteger)index sender:(nullable id)sender __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (BOOL)handleNavigationBarButtonAction:(UIBarButtonItem *)sender __attribute__((deprecated("Use GXControlActionBarItem instead")));
- (BOOL)handleToolbarButtonAction:(UIBarButtonItem *)sender __attribute__((deprecated("Use GXControlActionBarItem instead")));

- (void)showActionGroup:(id<GXLayoutActionBar>)actionGroup
		fromEntityModel:(id <GXEntityModel>)model
				context:(nullable GXUserInterfaceContext *)context
			 entityData:(nullable id<GXEntityData>)contextEntityData __attribute__((deprecated("Use GXControlActionBarItem instead")));

#pragma mark Actions Override entry points

/**
 * Returns an array of GXEntityActionBarItemActionReference containing the action descriptors
 */
- (nullable NSArray<GXEntityActionBarItemActionReference *> *)visibleActionBarActionReferencesForModel:(id <GXEntityModel>)model
																								  mode:(GXModeType)mode
																						  priorityMask:(GXActionBarUIPriorityType)priorityMask
																						   barTypeMask:(GXViewControllerBarType)barTypeMask  __attribute__((deprecated("Use GXControlActionBarItem instead")));

@end

NS_ASSUME_NONNULL_END
