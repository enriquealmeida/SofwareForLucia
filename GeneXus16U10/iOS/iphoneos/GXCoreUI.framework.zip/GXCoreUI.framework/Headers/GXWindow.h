//
//  GXWindow.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 2/2/15.
//  Copyright (c) 2015 Artech. All rights reserved.
//

@import UIKit;

@interface UIWindow (GXWindow)

@property(assign, readonly) BOOL gxPreventLowContrastTintColor;

- (BOOL)gxShouldPreventLowContrastTintColorForController:(UIViewController *)controller;
- (BOOL)gxPreventLowContrastTintColorIfNeededForController:(UIViewController *)controller;

@end

@interface GXWindow : UIWindow
@end

@protocol GXAllowLightTintColor <NSObject> // Use GXAllowLowContrastTintColor instead
@end

@protocol GXAllowLowContrastTintColor <GXAllowLightTintColor>
@end

@interface UIWindow (GXDeprecated)

@property(assign, readonly) BOOL gxPreventLightTintColor __attribute__((deprecated("Use gxPreventLowContrastTintColor instead")));

- (BOOL)gxShouldPreventLightTintColorForController:(UIViewController *)controller __attribute__((deprecated("Use gxShouldPreventLowContrastTintColorForController: instead")));
- (BOOL)gxPreventLightTintColorIfNeededForController:(UIViewController *)controller __attribute__((deprecated("Use gxPreventLowContrastTintColorIfNeededForController: instead")));

@end
