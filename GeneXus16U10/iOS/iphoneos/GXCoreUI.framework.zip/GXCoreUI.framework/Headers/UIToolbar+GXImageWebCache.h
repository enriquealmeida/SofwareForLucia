//
//  UIToolbar+GXImageWebCache.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 5/9/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/UIToolbar+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIToolbar (GXImageWebCache)

- (void)gxSetBackgroundImageNamed:(nullable NSString *)imageName;

@end

NS_ASSUME_NONNULL_END
