//
//  GXMenuRuntimeHelper+GXInternal.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 9/8/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXCoreUI/GXMenuControllerProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@class GXMenuItemRuntimeHelper;
@protocol GXMenuRuntimeHelperDelegate;

@interface GXMenuRuntimeHelper : NSObject <GXControlRuntimePropertiesProxy>

- (instancetype)initWithMenu:(id<GXMenu>)menu NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

@property(nonatomic, strong, readonly) id<GXMenu> menu;
@property(nonatomic, strong, readonly) NSArray<GXMenuItemRuntimeHelper *> *runtimeMenuItems;
@property(nonatomic, copy, readonly) NSArray<GXMenuItemRuntimeHelper *> *visibleRuntimeMenuItems;

// Runtime properties
@property(nonatomic, assign) NSUInteger activePage; // Base 1 index

@property(nullable, weak) id<GXMenuRuntimeHelperDelegate> delegate;

@end



@protocol GXMenuRuntimeHelperDelegate <NSObject>

@optional
- (void)menuRuntimeHelper:(GXMenuRuntimeHelper *)menu didChangePropertyValue:(SEL)property;
- (void)menuRuntimeHelper:(GXMenuRuntimeHelper *)menu item:(GXMenuItemRuntimeHelper *)item didChangePropertyValue:(SEL)property;
- (void)menuRuntimeHelper:(GXMenuRuntimeHelper *)menu itemDidChangeVisibility:(GXMenuItemRuntimeHelper *)item;
- (void)menuRuntimeHelper:(GXMenuRuntimeHelper *)menu visibleItem:(GXMenuItemRuntimeHelper *)item didChangePropertyValue:(SEL)property;

@end



@interface GXMenuItemRuntimeHelper : NSObject <GXNamedControlElement, GXControlBaseRuntimeProperties>

- (instancetype)init NS_UNAVAILABLE;

@property(nullable, weak, readonly) GXMenuRuntimeHelper *menu;
@property(nonatomic, strong, readonly) id<GXMenuItem> menuItem;

// Runtime properties
@property(nullable, nonatomic, strong) NSString *caption;
@property(nullable, nonatomic, strong) NSString *image;
@property(nullable, nonatomic, strong) NSString *themeClassFullName;
@property(nonatomic, assign) BOOL visible;

@end

NS_ASSUME_NONNULL_END
