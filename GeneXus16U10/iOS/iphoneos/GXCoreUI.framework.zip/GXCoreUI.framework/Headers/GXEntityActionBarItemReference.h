//
//  GXEntityActionBarItemActionReference.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 09/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import GXObjectsModel;
#import <GXCoreUI/GXEntityModelProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEntityActionBarItemReference : NSObject <GXNamedControlElement>

@property(nonatomic, strong, readonly) id<GXEntityModel> entityModel;
@property(nonatomic, strong, readonly) id<GXLayoutActionBarItem> layoutElement;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithLayoutActionBarItem:(id<GXLayoutActionBarItem>)layoutElement
								entityModel:(id<GXEntityModel>)entityModel NS_DESIGNATED_INITIALIZER;

@end

@interface GXEntityActionBarItemActionReference : GXEntityActionBarItemReference

@property(nullable, nonatomic, strong, readonly) id<GXActionDescriptor> actionDescriptor;
@property(nonatomic, strong, readonly) id<GXLayoutActionBarActionItem> layoutActionBarActionItem;

@end

@interface GXEntityActionBarItemGroupReference : GXEntityActionBarItemReference

@property(nonatomic, strong, readonly) id<GXLayoutActionBarGroupItem> layoutActionGroupActionItem;

@end

@interface GXEntityActionBarItemDataReference : GXEntityActionBarItemReference 

@end



@interface GXEntityActionBarItemReference (GXDeprecated)

// Checks for control property "visible" and returns its value if set, otherwise returns [self.layoutElement actionUIVisible]
- (BOOL)isControlVisibleForProperties:(nullable NSDictionary<NSString *, id> *)controlProperties __attribute__((deprecated("Use GXControlActionBarItem instead")));

// Checks for control property "caption" and returns its value if set, otherwise returns [self.layoutElement actionUICaption]
- (nullable NSString *)controlCaptionForProperties:(nullable NSDictionary<NSString *, id> *)controlProperties __attribute__((deprecated("Use GXControlActionBarItem instead")));

// Checks for control property "class" and returns its value if set, otherwise returns [self.layoutElement actionUIThemeClass]
- (nullable NSString *)controlClassForProperties:(nullable NSDictionary<NSString *, id> *)controlProperties __attribute__((deprecated("Use GXControlActionBarItem instead")));

@end

NS_ASSUME_NONNULL_END
