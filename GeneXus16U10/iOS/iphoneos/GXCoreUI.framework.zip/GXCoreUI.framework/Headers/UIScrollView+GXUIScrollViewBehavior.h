//
//  UIScrollView+GXUIScrollViewBehavior.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 3/7/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

#import <GXCoreUI/UIScrollView+GXHelpers.h>
#import <GXCoreUI/GXScrollableControlProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXUIScrollViewBehavior

@property(nonatomic, assign) CGPoint gxContentOffset;
@property(nonatomic, assign) CGSize gxContentSize;
@property(nonatomic, assign) UIEdgeInsets gxContentInset;
@property(nonatomic, readonly) UIEdgeInsets gxAdjustedContentInset;

- (void)gxSetContentOffset:(CGPoint)contentOffset animated:(BOOL)animated;
- (void)gxScrollRectToVisible:(CGRect)rect animated:(BOOL)animated;

@end


@interface UIScrollView (GXUIScrollViewBehavior) <GXUIScrollViewBehavior>

+ (BOOL)gxContentAllowsScrolling:(__kindof UIView<GXUIScrollViewBehavior> *)scrollView;
+ (BOOL)gxContentAllowsHorizontalScrolling:(__kindof UIView<GXUIScrollViewBehavior> *)scrollView;
+ (BOOL)gxContentAllowsVerticalScrolling:(__kindof UIView<GXUIScrollViewBehavior> *)scrollView;

+ (BOOL)gxContentAllowsScrollingWithBoundsSize:(CGSize)boundsSize
								   contentSize:(CGSize)contentSize
						  adjustedContentInset:(UIEdgeInsets)adjustedContentInset
									horizontal:(BOOL)horizontal
									  vertical:(BOOL)vertical;

+ (BOOL)gxScrollEnabledRequiredForScrollView:(__kindof UIView<GXUIScrollViewBehavior> *)scrollView;

@end

NS_ASSUME_NONNULL_END
