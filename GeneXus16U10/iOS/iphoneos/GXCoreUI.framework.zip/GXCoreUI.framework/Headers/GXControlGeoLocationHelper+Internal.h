//
//  GXControlGeoLocationHelper+Internal.h
//  GXCoreUI-iOS
//
//  Created by José Echagüe on 3/2/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import MapKit;
@import GXObjectsModel;
#import <GXCoreUI/GXControlGeoLocationHelper.h>
#import <GXCoreUI/GXMapAnnotation.h>
#import <GXCoreUI/GXMapView.h>

#define kGXRemovePinString @"GXM_RemovePin"
#define kGXCancelString @"GXM_cancel"

@interface GXControlGeoLocationHelper () {
	@protected UIView<GXMapView> *_mapView;
	@protected GXMapAnnotation *_annotation;
	@protected BOOL _animateDrop;
}

- (void)reloadEditorSubviews;

- (void)updateReadOnly:(BOOL)updateReadOnly
         updateEnabled:(BOOL)updateEnabled
            annotation:(GXMapAnnotation *)annotation
               mapView:(UIView<GXMapView> *)mapView
        annotationView:(MKPinAnnotationView *)annotationView;

- (void)internalUpdateAnnotationCoordinate:(CLLocationCoordinate2D)coordinate
                             animateChange:(BOOL)animateChange
                               animateDrop:(BOOL)animateDrop
                    showAnnotationOnChange:(BOOL)showAnnotationOnChange;

- (void)handleRemoveLoadedAnnotation;

- (void)reverseGeocodeLoadedAnnotation;

+ (id<MKAnnotation>)createEmptyAnnotation; //Abstract

@end
