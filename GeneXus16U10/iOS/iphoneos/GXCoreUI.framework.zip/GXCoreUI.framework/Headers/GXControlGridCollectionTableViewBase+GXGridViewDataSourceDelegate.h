//
//  GXControlGridCollectionTableViewBase+GXGridViewDataSourceDelegate.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 26/6/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXCoreUI/GXControlGridCollectionTableViewBase.h>
#import <GXCoreUI/GXControlGridBaseWithSelection+GXGridViewDataSourceDelegate.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXControlGridCollectionTableViewBase (GXGridViewDataSourceDelegate)

- (NSInteger)numberOfSectionsInSearchMode:(BOOL)searching;
- (NSInteger)numberOfSectionsInGridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView;

- (NSInteger)numberOfItemsInSection:(NSInteger)pSection searchMode:(BOOL)searching;
- (NSInteger)gridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView numberOfItemsInSection:(NSInteger)vSection;

- (__kindof UIView<GXControlGridCollectionTableViewCell> *)gridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView
											 cellForItemAtIndexPath:(NSIndexPath *)vIndexPath;

#if TARGET_OS_IOS
- (NSString *)cellIdentifierForEntityData:(inout id <GXEntityDataWithOverrideValues> __autoreleasing _Nullable * _Nonnull)entityData
				   atProviderIndexPathRow:(NSUInteger)pIndexPathRow
						 indexPathSection:(NSUInteger)pIndexPathSection
							   searchMode:(BOOL)searching
							   layoutName:(out NSString * __autoreleasing _Nullable * _Nullable)layoutName
								 selected:(out BOOL * _Nullable)isGridItemSelected
			  highlightStyleModifierFlags:(out GXControlGridItemHighlightStyleModifierFlags * _Nullable)hStyleMod __attribute__((deprecated("Use cellIdentifierForEntityData:atProviderIndexPathRow:indexPathSection:filtered:layoutName:selected:highlightStyleModifierFlags: instead")));

- (GXControlGridItemHighlightStyleModifierFlags)highlightStyleModifiersForEntityDataAtIndex:(NSUInteger)index section:(NSUInteger)section __attribute__((deprecated("Use highlightStyleModifiersForEntityDataAtIndex:section:filtered: instead")));
- (GXControlGridItemHighlightStyleModifierFlags)highlightStyleModifiersForFilteredEntityDataIndex:(NSUInteger)index __attribute__((deprecated("Use highlightStyleModifiersForEntityDataAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

- (nullable NSString *)gridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView titleForHeaderInSection:(NSInteger)section;

- (nullable NSArray<NSString *> *)indexTitlesForGridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView;
- (NSIndexPath *)gridView:(UIScrollView<GXControlGridCollectionTableView> *)gridView indexPathForIndexTitle:(NSString *)title atIndex:(NSInteger)index;

@end

NS_ASSUME_NONNULL_END
