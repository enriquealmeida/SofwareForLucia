//
//  GXEntityDataWithDictionary.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 07/02/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXObjectsModel;

@interface GXEntityDataWithDictionary : NSObject <GXEntityData>

+ (id <GXEntityData>)entityDataWithFieldValuesByName:(NSDictionary *)fieldValuesByName
										  descriptor:(id<GXEntityDataDescriptor>)descriptor
											allowNil:(BOOL)allowNil;

+ (id <GXEntityData>)entityDataWithFieldValuesByName:(NSDictionary *)fieldValuesByName
										  descriptor:(id<GXEntityDataDescriptor>)descriptor;

+ (id <GXEntityData>)entityDataWithFieldValuesByName:(NSDictionary *)fieldValuesByName;

@property(nonatomic, strong, readonly) id <GXEntityDataDescriptor> entityDataDescriptor;

@end
