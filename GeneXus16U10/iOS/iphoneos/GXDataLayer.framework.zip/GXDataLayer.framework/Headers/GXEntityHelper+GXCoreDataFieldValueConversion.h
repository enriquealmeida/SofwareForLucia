//
//  GXEntityHelper+GXCoreDataFieldValueConversion.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import GXObjectsModel;

typedef NS_ENUM(uint_least8_t, GXEntityHelperSDTType) {
	GXEntityHelperSDTTypeAny,
	GXEntityHelperSDTTypeString,
	GXEntityHelperSDTTypeSDTData
};

@interface GXEntityHelper (GXCoreDataFieldValueConversion)

+ (id)coreDataFieldValue:(id <GXEntityDataFieldDescriptor>)fieldDesc
			   fromValue:(id)value;

+ (id)coreDataFieldValueFroFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo
						   fromValue:(id)value;

+ (id)coreDataFieldValueFroFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo
						   fromValue:(id)value
							 sdtType:(GXEntityHelperSDTType)sdtType; // allowNull == YES

+ (id)coreDataFieldValueFroFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo
						   fromValue:(id)value
							 sdtType:(GXEntityHelperSDTType)sdtType
						   allowNull:(BOOL)allowNull;

+ (id)coreDataEmptyFieldValueForFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo
								  sdtType:(GXEntityHelperSDTType)sdtType;

@end


@interface GXEntityHelper (GXCoreDataFieldValueConversion_Deprecated)

+ (id)coreDataFieldValueForParameter:(id<GXActionParameterDescriptor>)actionParameter
					  fromEntityData:(id<GXEntityData>)contextEntityData __attribute__((deprecated));

+ (id)coreDataFieldValueForParameter:(id<GXActionParameterDescriptor>)actionParameter
					  fromEntityData:(id<GXEntityData>)contextEntityData
				actionHandlerContext:(id<GXActionHandlerContext>)context __attribute__((deprecated));

+ (void)coreDataFieldValueForParameter:(id<GXActionParameterDescriptor>)actionParameter
						fromEntityData:(id<GXEntityData>)contextEntityData
				  actionHandlerContext:(id<GXActionHandlerContext>)context
							completion:(void(^)(id result))completion __attribute__((deprecated));

@end
