//
//  GXEntityDataFieldDynamicComboData.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 01/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
@import GXObjectsModel;

@interface GXEntityDataFieldDynamicComboData : GXDomainEnumValues

- (instancetype)initWithValues:(NSArray *)values fieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo;

@property(nonatomic, assign, readonly) NSUInteger totalCount;

- (NSUInteger)indexForValue:(id)value;
- (id)valueAtIndex:(NSUInteger)index;
- (NSString *)descriptionAtIndex:(NSUInteger)index;

@end
