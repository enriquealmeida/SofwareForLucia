//
//  GXAudioUI.h
//  GXAudioUI
//
//  Created by Marcos Crispino on 3/1/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXAudioUI.
FOUNDATION_EXPORT double GXAudioUIVersionNumber;

//! Project version string for GXAudioUI.
FOUNDATION_EXPORT const unsigned char GXAudioUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXAudioUI/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
