//
//  GXCoreModule_Common_GeoLocation.h
//  GXCoreModule_Common_GeoLocation
//
//  Created by Fabian Inthamoussu on 24/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_Common_GeoLocation.
FOUNDATION_EXPORT double GXCoreModule_Common_GeoLocationVersionNumber;

//! Project version string for GXCoreModule_Common_GeoLocation.
FOUNDATION_EXPORT const unsigned char GXCoreModule_Common_GeoLocationVersionString[];

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#import <GXCoreModule_Common_GeoLocation/GXEOGeolocation.h>
#import <GXCoreModule_Common_GeoLocation/GXEOGeolocationHandlerHelper.h>
