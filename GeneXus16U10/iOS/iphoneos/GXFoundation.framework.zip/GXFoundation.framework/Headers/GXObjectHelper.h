//
//  GXObjectHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/10/10.
//  Copyright 2010 Artech. All rights reserved.
//

#import <GXFoundation/GXConstants.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXObjectHelper : NSObject

+ (BOOL)parseObjectType:(out NSString * __nullable * __nullable)objectType
			 objectName:(out NSString * __nullable * __nullable)objectName
				   from:(nullable id)data;
+ (BOOL)parseObjectTypeEnum:(out GXObjectType * __nullable)objectType
				 objectName:(out NSString * __nullable * __nullable)objectName
					   from:(nullable id)data;
+ (nullable NSString *)parseObjectNameOfType:(NSString *)objectType from:(nullable id)data;
+ (nullable NSString *)parseObjectNameOfTypeEnum:(GXObjectType)objectType from:(nullable id)data;

+ (nullable NSString *)objectTypeStingFromEnum:(GXObjectType)objectType;
+ (GXObjectType)objectTypeEnumFromSting:(nullable NSString *)objectType;

@end

NS_ASSUME_NONNULL_END
