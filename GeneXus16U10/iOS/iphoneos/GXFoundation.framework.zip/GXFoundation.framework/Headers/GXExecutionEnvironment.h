//
//  GXExecutionEnvironment.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 19/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXCommon.h>

typedef NSUInteger GXBackgroundTaskIdentifier;

NS_ASSUME_NONNULL_BEGIN

@protocol GXExecutionEnvironment <NSObject>

#pragma mark State

@property(nonatomic, assign, readonly) GXApplicationStateType applicationState;
@property(nonatomic, assign, readonly, getter = isTransitioningFromBackgroundToForeground) BOOL transitioningFromBackgroundToForeground;

@property(nonatomic, assign, readonly) BOOL activeStateNotificationsSupported;
@property(nullable, nonatomic, strong, readonly) NSString *didBecomeActiveNotification;
@property(nullable, nonatomic, strong, readonly) NSString *willResignActiveNotification;

@property(nullable, nonatomic, strong, readonly) NSString *didReceiveMemoryWarningNotification;
@property(nullable, nonatomic, strong, readonly) NSString *willTerminateNotification;

#pragma mark Multitasking

@property(nonatomic, assign, readonly, getter=isMultitaskingSupported) BOOL multitaskingSupported;
@property(nonatomic, assign, readonly) BOOL multitaskingNotificationsSupported;
@property(nullable, nonatomic, strong, readonly) NSString *didEnterBackgroundNotification;
@property(nullable, nonatomic, strong, readonly) NSString *willEnterForegroundNotification;

#pragma mark BackgroundTask

@optional
@property(nonatomic,readonly) NSTimeInterval backgroundTimeRemaining;

- (GXBackgroundTaskIdentifier)backgroundTaskInvalidIdentifier;
- (GXBackgroundTaskIdentifier)beginBackgroundTaskWithName:(nullable NSString *)taskName expirationHandler:(void(^ __nullable)(void))handler;
- (void)endBackgroundTask:(GXBackgroundTaskIdentifier)identifier;
@required

#pragma mark Applications Interop

@optional
- (void)openURL:(NSURL *)url options:(nullable NSDictionary<NSString *, id> *)options completionHandler:(void (^ __nullable)(BOOL success))completion;
@property(nullable, nonatomic, strong, readonly) NSString *openURLOptionUniversalLinksOnlyKey;

- (BOOL)canOpenURL:(NSURL *)url;
@required

#pragma mark User Interface

#if !TARGET_OS_WATCH
@property(nonatomic, readonly) UITraitCollection *currentTraitCollection;
@property(nullable, nonatomic, strong, readonly) UIWindow *keyWindow;
- (void)sendActionToFirstResponder:(SEL)action;
#else
@property(nullable, nonatomic, strong, readonly) WKInterfaceController *rootInterfaceController;
#endif // !TARGET_OS_WATCH

#if !TARGET_OS_WATCH
@property(nonatomic, assign, readonly) UIUserInterfaceLayoutDirection userInterfaceLayoutDirection;
#else
@property(nonatomic, assign, readonly) WKInterfaceLayoutDirection userInterfaceLayoutDirection;
#endif // !TARGET_OS_WATCH

#if TARGET_OS_IOS
@property(nonatomic, assign, readonly) CGRect statusBarFrame; // returns CGRectZero if the status bar is hidden
@property(nonatomic, assign, readonly) UIInterfaceOrientation interfaceOrientation;
@property(nonatomic, assign, readonly) UIInterfaceOrientationMask supportedInterfaceOrientationsForKeyWindow;
#endif // TARGET_OS_IOS

#if !TARGET_OS_WATCH
@property(nonatomic, strong, readonly) UIContentSizeCategory preferredContentSizeCategory;
@property(nonatomic, assign, readonly) BOOL preferredContentSizeCategoryIsAccessibilityCategory;
#endif // !TARGET_OS_WATCH

#pragma mark UIRemoteControlEvents

@optional
- (void)beginReceivingRemoteControlEvents;
- (void)endReceivingRemoteControlEvents;
@required

@end

NS_ASSUME_NONNULL_END
