//
//  NSNumberFormatter+Helpers.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 6/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSNumberFormatter (Helpers)

+ (nullable NSNumberFormatter *)numberFormatterForGXPicture:(nullable NSString *)picture localeId:(nullable NSString *)localeId numberHasDecimals:(BOOL)hasDecimals;
+ (NSNumberFormatter *)numberFormatterForNumberFormat:(NSString *)numberFormat localeId:(nullable NSString *)localeId;
+ (NSNumberFormatter *)numberFormatterForNumberFormat:(NSString *)numberFormat zeroSymbol:(nullable NSString *)zeroSymbol localeId:(nullable NSString *)localeId;
+ (NSNumberFormatter *)numberFormatterForMaximumFractionDigits:(NSUInteger)maxFractionDigits maximumIntegerDigits:(NSUInteger)maxIntegerDigits localeId:(nullable NSString *)localeId;

+ (NSNumberFormatter *)numberFormatterForLocale_en_US_POSIX;

+ (NSNumberFormatter *)decimalNumberFormatterForLocales_en_US_POSIX;

@end

NS_ASSUME_NONNULL_END
