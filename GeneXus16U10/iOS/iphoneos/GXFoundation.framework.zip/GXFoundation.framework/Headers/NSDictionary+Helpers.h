//
//  NSDictionary+Helpers.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 27/10/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;

@interface NSDictionary (Helpers)

- (NSDictionary *)dictionaryWithLowercaseKeys;

- (NSDictionary *)dictionaryWithKeyConvertionBlock:(id (^)(id key))block;

- (id)synchronizedObjectForKey:(id)key;

@end
