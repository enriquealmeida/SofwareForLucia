//
//  GXPropertiesObject.h
//  GXFlexibleClient
//
//  Created by willy on 6/2/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@protocol GXPropertiesObject <NSObject>

- (nullable id)getPropertyValue:(NSString *)propertyName;

#pragma mark - Helper value type getters

- (BOOL)getPropertyValueBool:(NSString *)propertyName;
- (BOOL)getPropertyValueBool:(NSString *)propertyName defaultValue:(BOOL)defaultValue;
- (NSInteger)getPropertyValueInteger:(NSString *)propertyName;
- (CGFloat)getPropertyValueFloat:(NSString *)propertyName;

#pragma mark - Helper objects getters

- (nullable NSString *)getPropertyValueString:(NSString *)propertyName;
- (nullable UIColor *)getPropertyValueColor:(NSString *)propertyName;

@end


@protocol GXCodingPropertiesObject <GXPropertiesObject, NSCoding>

- (nullable __kindof id<NSCoding>)getCodingPropertyValue:(NSString *)propertyName;

@end


@protocol GXMutablePropertiesObject <GXPropertiesObject>

- (void)setPropertyValue:(nullable id)value forPropertyName:(NSString *)propertyName;
- (void)removePropertyFoPropertyName:(NSString *)propertyName;

#pragma mark - Helper value type setters

- (void)setBoolProperty:(BOOL)value forPropertyName:(NSString *)propertyName;
- (void)setIntegerProperty:(NSInteger)value forPropertyName:(NSString *)propertyName;
- (void)setFloatProperty:(CGFloat)value forPropertyName:(NSString *)propertyName;

@end


@protocol GXMutableCodingPropertiesObject <GXMutablePropertiesObject, GXCodingPropertiesObject>

- (void)setCodingPropertyValue:(nullable id<NSCoding>)value forPropertyName:(NSString *)propertyName;

@end



#pragma mark - Implementations

@interface GXPropertiesObject : NSObject <GXPropertiesObject>

- (instancetype)initWithProperties:(nullable NSDictionary<NSString *, id> *)properties NS_DESIGNATED_INITIALIZER;

@end

@interface GXMutablePropertiesObject : GXPropertiesObject <GXMutablePropertiesObject>
@end

@interface GXCodingPropertiesObject : GXPropertiesObject <GXCodingPropertiesObject>
@end

@interface GXMutableCodingPropertiesObject : GXMutablePropertiesObject <GXMutableCodingPropertiesObject>
@end

NS_ASSUME_NONNULL_END
