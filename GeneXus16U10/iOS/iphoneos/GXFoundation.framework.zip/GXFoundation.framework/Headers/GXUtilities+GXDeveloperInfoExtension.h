//
//  GXUtilities+GXDeveloperInfoExtension.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 25/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <GXFoundation/GXUtilities.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXUtilitiesDeveloperInfoExtension <NSObject>

@property(nonatomic, assign, readonly, getter=isDeveloperInfoExtensionDynamic) BOOL developerInfoExtensionDynamic;

@property(nonatomic, assign, readonly) BOOL showDeveloperInfo;

@end

@interface GXUtilities (GXDeveloperInfoExtension)

+ (void)registerDeveloperInfoExtension:(id <GXUtilitiesDeveloperInfoExtension>)developerInfoExtension;

@end

NS_ASSUME_NONNULL_END
