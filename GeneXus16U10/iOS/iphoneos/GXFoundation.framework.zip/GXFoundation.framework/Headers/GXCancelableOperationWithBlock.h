//
//  GXCancelableOperationWithBlock.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 04/01/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXFoundation/GXCancelableOperationBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCancelableOperationWithBlock : GXCancelableOperationBase

- (instancetype)initWithCancelBlock:(void(^ _Nullable)(void))block NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
