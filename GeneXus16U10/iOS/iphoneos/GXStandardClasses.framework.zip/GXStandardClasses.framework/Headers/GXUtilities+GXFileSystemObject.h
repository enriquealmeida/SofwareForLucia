//
//  GXUtilities+GXFileSystemObject.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 6/7/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXFoundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXUtilities (GXFileSystemObject)

/*!
Creates a unique path in [GXDirectory temporaryfilespath]

@discussion Similar to createUniqueTemporaryFilePath but returned path is accessible by GXFileSystemObject
*/
+ (NSString *)createUniqueGXDataTemporaryFilePath;

@end

NS_ASSUME_NONNULL_END
