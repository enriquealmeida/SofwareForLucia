//
//  GXStringCollection.h
//  GXStd
//
//  Created by Marcos Crispino on 30/10/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXStandardClasses/GXObjectCollection.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXStringCollection : GXObjectCollection

+ (GXStringCollection *)stringCollectionFromString:(nullable NSString *)list;

- (NSString *)stringAtIndex:(NSInteger)index;

- (NSString *)getString;

@end

NS_ASSUME_NONNULL_END
