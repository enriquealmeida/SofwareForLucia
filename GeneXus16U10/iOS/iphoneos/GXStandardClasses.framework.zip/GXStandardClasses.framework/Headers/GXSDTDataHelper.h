//
//  GXSDTDataHelper.h
//  GXStd
//
//  Created by Marcos Crispino on 1/28/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXObjectsModel;
#import <GXStandardClasses/GXObjectCollection.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXSDTDataHelper : NSObject

+ (id<GXSDTData>)convertSDTData:(id<GXSDTData>)data toClass:(Class)toClass;

+ (GXObjectCollection *)convertSDTData:(id<GXSDTData>)data toObjectCollectionOfType:(NSString *)typeName;
+ (NSString *)typeNameFromSDTName:(NSString *)sdtName;

+ (id<GXSDTData>)sdtDataWithTypeName:(NSString *)typeName value:(id)value isCollection:(BOOL)isCollection;
+ (id<GXSDTData>)sdtDataWithTypeName:(NSString *)typeName value:(id)value;
+ (id<GXSDTDataCollection>)sdtDataCollectionWithTypeName:(NSString *)typeName value:(id)value;

+ (NSArray *)arrayFromSDTDataCollection:(id<GXSDTDataCollection>)collection;

@end

NS_ASSUME_NONNULL_END
