//
//  GXCryptoHash.h
//  GXStandardClasses
//
//  Created by Marcos Crispino on 13/3/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXStandardClasses/GXCryptoBaseType.h>

NS_ASSUME_NONNULL_BEGIN

#define kGXCryptoHashAlgorithm_MD5 @"MD5"
#define kGXCryptoHashAlgorithm_SHA1 @"SHA1"
#define kGXCryptoHashAlgorithm_SHA256 @"SHA256"
#define kGXCryptoHashAlgorithm_SHA384 @"SHA384"
#define kGXCryptoHashAlgorithm_SHA512 @"SHA512"

#define kGXCryptoHashAlgorithm_HMACMD5 @"HMACMD5"
#define kGXCryptoHashAlgorithm_HMACSHA1 @"HMACSHA1"
#define kGXCryptoHashAlgorithm_HMACSHA256 @"HMACSHA256"
#define kGXCryptoHashAlgorithm_HMACSHA384 @"HMACSHA384"
#define kGXCryptoHashAlgorithm_HMACSHA512 @"HMACSHA512"

@interface GXCryptoHash : GXCryptoBaseType

/**
 Specifies the hash algorithm that will be applied when the Compute(String,[key]) method is invoked. The SHA256 is used by default.
 
 Valid values are: kGXCryptoHashAlgorithm_MD5, kGXCryptoHashAlgorithm_SHA1, kGXCryptoHashAlgorithm_SHA256, kGXCryptoHashAlgorithm_SHA384, kGXCryptoHashAlgorithm_SHA512, kGXCryptoHashAlgorithm_HMACMD5, kGXCryptoHashAlgorithm_HMACSHA1, kGXCryptoHashAlgorithm_HMACSHA256, kGXCryptoHashAlgorithm_HMACSHA384, kGXCryptoHashAlgorithm_HMACSHA512
 */
@property (nonatomic, retain) NSString *algorithm;

/**
 Returns the text resulting from the application of the hash function on the text entered.
 As Keyed-Hash Message Authentication Code is supported, a key can be optionally passed to the method.
 */
- (NSString *)compute:(NSString *)text key:(NSString *)key NS_SWIFT_NAME(compute(_:_:));

@end

NS_ASSUME_NONNULL_END
