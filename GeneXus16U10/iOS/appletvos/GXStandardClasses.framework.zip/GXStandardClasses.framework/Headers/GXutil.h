//
//  GXutil.h
//  GXStd
//
//  Created by Marcos Crispino on 21/08/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
#import <GXStandardClasses/GXJSONArray.h>
#import <GXStandardClasses/GXStringCollection.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXutil : NSObject

+ (void)msg:(NSString *)msg;
+ (void)msgStatus:(NSString *)msg;

+ (GXJSONArray *)stringCollectionsToJSONArrayWithCodes:(GXStringCollection *)codes descriptions:(GXStringCollection *)descs;

+ (NSString *)stringCollectionsToJSONWithCodes:(GXStringCollection *)codes descriptions:(GXStringCollection *)descs;

+ (NSString *)format:(NSString *)str
			   parm1:(id)parm1
			   parm2:(id)parm2
			   parm3:(id)parm3
			   parm4:(id)parm4
			   parm5:(id)parm5
			   parm6:(id)parm6
			   parm7:(id)parm7
			   parm8:(id)parm8
			   parm9:(id)parm9;

/**
 * Returns a random number
 */
+ (NSDecimal)rand;

/**
 * Returns a random integer number
 */
+ (NSInteger)aleat;

/**
 * Returns the image path for a given image GUID and theme name
 */
+ (NSString *)getImagePath:(NSString *)imgNameOrGuid language:(NSString *)lang themeName:(NSString *)themeName;

/**
 * If the URL given by urlStr parameter is relative to the server's URL, saves the file locally and returns the file path
 * Otherwise, returns the absolute URL as a String.
 *
 * @param urlStr The resource's URL as a string
 * @return a NSString with the local file path or the URL of the resource as a string
 */
+ (NSString *)localPathOrURLStringFromURLString:(NSString *)urlStr __deprecated_msg("Use +localPathOrURLStringFromURLString:attribute: instead");

/**
 * Given the URL for a blob or multimedia attribute, it may
 * return the URL unchanged if the attribute is not specified or
 * if the property Download content in Offline applications is set to False in GeneXus;
 * or save the file locally and returns the file path
 * if the property Download content in Offline applications is set to True
 *
 * @param urlStr The resource's URL as a string
 * @param att The attribute's name, used to look up the property's value
 * @return a NSString with the local file path or the URL of the resource as a string
 */
+ (NSString *)localPathOrURLStringFromURLString:(NSString *)urlStr attribute:(nullable NSString *)att;

+ (NSString *)localPathOrURLStringFromURLString:(NSString *)urlStr gxi:(NSString *)urlGxi attribute:(nullable NSString *)att;

/**
 * Returns the blob's file path
 */
+ (NSString *)getRelativeBlobFile:(NSString *)gxi;

/**
 * Returns the current date & time
 */
+ (NSDate *)serverNow;

/**
 * Returns the current date
 */
+ (NSDate *)serverDate;

/**
 * Returns the current time
 */
+ (NSString *)serverTime;

/**
 * Returns the workstation name
 * Default is the name of the device as set by the user, unless modified by +setWorkstationName:
 */
+ (NSString *)workstationName;

/**
 * Sets the name of the workstation that can be retrieved by the +workstationName method
 */
+ (NSNumber *)setWorkstationName:(NSString *)name;

/**
 * iif() function
 */
+ (id)gxiif:(NSNumber *)boolean op1:(id)op1 op2:(id)op2;

/**
 * Returns the number of lines in the string, limiting to 'len' characters per line
 */
+ (NSInteger)gxMLines:(NSString *)str lineLength:(NSInteger)len;

/**
 * Returns the line at position 'num' (1-based), limiting to 'len' characters per line
 */
+ (NSString *)gxGetMLine:(NSString *)str lineNumber:(NSInteger)num lineLength:(NSInteger)len;

+ (NSString *)dateToCharREST:(NSDate *)date;
+ (NSString *)timeToCharREST:(NSDate *)dTime;
+ (NSDate *)charToDateREST:(NSString *)str;
+ (NSDate *)charToTimeREST:(NSString *)str;

+ (NSString *)dateToCharDB:(NSDate *)date;
+ (NSString *)timeToCharDB:(NSDate *)dTime;

+ (NSString *)boolToStr:(NSNumber *)val;
+ (BOOL)strToBool:(NSString *)str;

+ (NSString *)urlEncode:(NSString *)url;
+ (NSString *)urlParameterEncode:(NSString *)urlParameter;

// ToFormattedString
+ (NSString *)formatChar:(NSString *)str picture:(NSString *)picture;

/*!
 Gets the current language code
 */
+ (NSString *)getLanguage;

/*!
 Gets the value of the given property for the current language
 
 @param propName The name of the property
 @result Returns the value of the give property for the current language or the empty string if not found
 */
+ (NSString *)getLanguageProperty:(NSString *)propName;

// Getting date & time format
+ (NSInteger)dateFormatForCurrentLanguage;
+ (NSInteger)timeFormatForCurrentLanguage;
+ (NSInteger)dateTimeFormatForCurrentLanguage;

/**
 Creates a Blob from the given base-64 string, saves it to the file system and returns the file path
 */
+ (NSString *)blobFromBase64:(NSString *)base64String NS_SWIFT_NAME(blobFromBase64(_:));

/**
 Given the Blob's file path, reads the binary data from strings and converts it to a base 64 string
 */
+ (NSString *)blobToBase64:(NSString *)blobPath NS_SWIFT_NAME(blobToBase64(_:));

+ (NSString *)toValueListForDBMS:(NSString *)dbms collection:(GXObjectCollection *)col prefix:(NSString *)prefix tail:(NSString *)tail;

// Helper Date Functions for Expression Evaluation

+ (NSString *)gxDtoC:(NSDate *)date;
+ (NSString *)gxTtoC:(NSDate *)dateTime;
+ (NSString *)gxTtoC:(NSDate *)dateTime dayDigits:(NSNumber *)dayDigits;
+ (NSString *)gxTtoC:(NSDate *)dateTime dayDigits:(NSNumber *)dayDigits hourDigits:(NSNumber *)hourDigits;
+ (NSDate *)gxCtoD:(NSString *)string;
+ (NSDate *)gxCtoT:(NSString *)string;

+ (NSString *)formatLink:(NSString *)urlStr;
+ (NSString *)formatLink:(NSString *)urlStr parameters:(nullable NSArray *)params;

+ (NSNumber *)colorValueFromRed:(NSNumber *)red green:(NSNumber *)green blue:(NSNumber *)blue;

@end

@interface GXutil (CommonImplementations)

// This methods are used both from the Flexible Client for expression evaluation and from Swift generated code

/**
 * Returns a random number between 0.0 and 1.0
 */
+ (NSNumber *)impl_random;

/**
 * Sets the seed for the random number generators
 */
+ (NSNumber *)impl_rseed:(NSNumber *)seed;

/**
 * Sleep time in seconds
 */
+ (NSNumber *)impl_sleep:(NSNumber *)secs;

/**
 * int() function
 */
+ (NSNumber *)impl_gxInt:(NSNumber *)num;

/**
 * ToFormattedString()
 */
+ (NSString *)impl_formatNumber:(NSNumber *)num picture:(NSString *)picture numberHasDecimals:(BOOL)hasDecimals;

+ (NSNumber *)dynamicCompare:(id)left operator:(NSString *)op with:(id)right;

@end

NS_ASSUME_NONNULL_END
