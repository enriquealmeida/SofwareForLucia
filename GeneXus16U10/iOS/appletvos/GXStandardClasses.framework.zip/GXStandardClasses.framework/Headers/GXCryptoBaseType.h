//
//  GXCryptoBaseType.h
//  GXStandardClasses
//
//  Created by Marcos Crispino on 13/3/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXCryptoBaseType : NSObject

@property (nonatomic, assign) NSInteger errCode;
@property (nonatomic, retain) NSString *errDescription;

@end

NS_ASSUME_NONNULL_END
