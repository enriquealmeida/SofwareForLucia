//
//  GXCompositeEntityData.h
//  GXFlexibleClient
//
//  Created by willy on 2/3/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

@import GXObjectsModel;

@interface GXCompositeEntityData : NSObject <GXEntityData>

@property(nonatomic, strong, readonly) id <GXEntityData> parentEntityData;
@property(nonatomic, strong, readonly) id <GXEntityData> entityData;

+ (id <GXEntityData>)entityDataWithEntity:(id<GXEntityData>)entityData
							 parentEntity:(id<GXEntityData>)parent; // excludedComposeFieldNames = nil

@end

@interface GXCompositeEntityDataWithOverrideValues : GXCompositeEntityData <GXEntityDataWithOverrideValues>
@end

@interface GXCompositeMutableEntityData : GXCompositeEntityData <GXMutableEntityData>
@end

@interface GXCompositeMutableEntityDataWithOverrideValues : GXCompositeEntityDataWithOverrideValues <GXMutableEntityData>
@end

@interface GXCompositeBusinessComponentLevelEntityData : GXCompositeMutableEntityData <GXBusinessComponentLevelEntityData>
@end

@interface GXCompositeBusinessComponentLevelEntityDataWithOverrideValues : GXCompositeMutableEntityDataWithOverrideValues <GXBusinessComponentLevelEntityData>
@end



@interface GXCompositeEntityData (ExcludedComposeFieldNames)

@property(nonatomic, strong, readonly) NSSet<NSString *> *excludedComposeFieldNames; // Lowercase

+ (id <GXEntityData>)entityDataWithEntity:(id<GXEntityData>)entityData
							 parentEntity:(id<GXEntityData>)parent
				excludedComposeFieldNames:(NSSet<NSString *> *)excludedComposeLowercaseFieldNames;

@end
