//
//  GXEntityDataWithFieldResolver.h
//  GXFlexibleClient
//
//  Created by willy on 8/19/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import GXObjectsModel;

@interface GXEntityDataWithFieldResolver : NSObject <GXEntityData>

@property(nonatomic, strong, readonly) id <GXEntityData> innerEntityData;
@property(nonatomic, strong, readonly) id <GXEntityDataDescriptor> entityDataDescriptor;
@property(nonatomic, strong, readonly) NSArray *indexer;

+ (id <GXEntityData>)entityDataWithEntityData:(id<GXEntityData>)entityData
						 entityDataDescriptor:(id<GXEntityDataDescriptor>)entityDataDescriptor
								 indexerStack:(NSArray *)indexer;

@end



@interface GXEntityDataWithFieldResolverOverrideValues : GXEntityDataWithFieldResolver <GXEntityDataWithOverrideValues>
@end


@interface GXMutableEntityDataWithFieldResolver : GXEntityDataWithFieldResolver <GXMutableEntityData>
@end


@interface GXMutableEntityDataWithFieldResolverOverrideValues : GXEntityDataWithFieldResolverOverrideValues <GXMutableEntityData>
@end


@interface GXBusinessComponentLevelEntityDataWithFieldResolver : GXMutableEntityDataWithFieldResolver <GXBusinessComponentLevelEntityData>
@end


@interface GXBusinessComponentLevelEntityDataWithFieldResolverOverrideValues : GXMutableEntityDataWithFieldResolverOverrideValues <GXBusinessComponentLevelEntityData>
@end
