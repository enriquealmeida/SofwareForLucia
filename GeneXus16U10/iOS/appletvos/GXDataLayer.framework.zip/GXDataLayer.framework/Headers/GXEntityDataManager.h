//
//  GXEntityDataManager.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 23/11/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXDataLayer/GXEntityDataQueryInfoProtocol.h>
#import <GXDataLayer/GXEntityDataQueryResultProtocol.h>

extern NSString *const GXEntityDataManagerReleasedAllGXIDReferencesNotification;

extern NSString *const GXEntityDataManagerGXIDKey;

@protocol GXEntityDataManagerDelegate;

@protocol GXEntityDataManagerQueryInfoLoader <NSObject>

- (void)load:(id <GXEntityDataQueryInfo>)queryInfo delegate:(id <GXEntityDataManagerDelegate>)delegate;
- (void)cancelLoad:(id <GXEntityDataQueryInfo>)queryInfo delegate:(id <GXEntityDataManagerDelegate>)delegate;

- (void)cancelAllOperations;

@end

@interface GXEntityDataManager : NSObject <GXEntityDataManagerQueryInfoLoader>

/// Returns a new unique gxid. Reference count starts at 1 for the new gxid.
- (NSUInteger)obtainNewGXID;
/// Increments the reference count over the given existing gxid.
- (void)retainGXID:(NSUInteger)gxid;
/// Decrements the reference count over the given existing gxid. When count reaches 0, a GXEntityDataManagerRealeasedAllGXIDReferencesNotification is posted
- (void)releaseGXID:(NSUInteger)gxid;

@end


@protocol GXEntityDataManagerDelegate <NSObject>

- (void)entityDataManager:(GXEntityDataManager *)manager
	didFinishLoadingQuery:(id <GXEntityDataQueryInfo>)queryInfo
			   withResult:(id <GXEntityDataQueryResult>)result;

@end
