//
//  GXBaseGridEntityDataProvider.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/12/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXDataLayer/GXBaseEntityDataProvider.h>
#import <GXDataLayer/GXEntityDataListProviderProtocol.h>
#import <GXDataLayer/GXEntityDataListSearchProviderProtocol.h>
#import <GXDataLayer/GXEntityDataListOrderProviderProtocol.h>
#import <GXDataLayer/GXEntityDataListBreakByProviderProtocol.h>
#import <GXDataLayer/GXEntityDataListAdvancedFilterProviderProtocol.h>

typedef NS_ENUM(uint_least8_t, GXEntityDataListProviderState) {
	GXEntityDataListProviderStateIdle,
	GXEntityDataListProviderStateLoading
};

@interface GXBaseListEntityDataProvider : GXBaseEntityDataProvider <GXEntityDataListProvider, GXEntityDataListSearchProvider, GXEntityDataListOrderProvider, GXEntityDataListBreakByProvider, GXEntityDataListAdvancedFilterProvider>

// GXEntityDataListProvider
@property(nonatomic, strong, readonly) NSArray<NSArray<id<GXEntityDataWithOverrideValues>> *> *loadedEntities;
@property(nonatomic, assign, readonly) NSUInteger loadedEntitiesCount;
@property(nonatomic, assign) NSUInteger pageSize;

// GXEntityDataListSearchProvider
@property(nonatomic, strong, readonly) NSString *searchText;
@property(nonatomic, assign, readonly) NSUInteger searchFieldIndex;
@property(nonatomic, strong, readonly) NSArray<NSArray<id<GXEntityDataWithOverrideValues>> *> *filteredLoadedEntities;
@property(nonatomic, assign, readonly) NSUInteger filteredLoadedEntitiesCount;

// GXEntityDataListOrderProvider
@property(nonatomic, assign, readonly) NSUInteger orderIndex;
@property(nonatomic, strong, readonly) NSArray<NSString *> *loadedAlphaIndexTitles;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, NSValue *> *loadedAlphaIndexRangesByTitle; // NSValue has rangeValue (NSRange)

// GXEntityDataListAdvancedFilterProvider
@property(nonatomic, strong, readonly) NSArray<id<GXEntityListFilterAdvancedFieldValue>> *advancedFilterValues;

// Common
@property(nonatomic, assign, readonly) GXEntityDataListProviderState state;
@property(nonatomic, strong, readonly) id <GXEntityDataQueryCollectionInfo> currentQueryCollectionInfo;
@property(nonatomic, strong, readonly) id <GXEntityDataQueryCollectionInfo> lastQueryCollectionInfo;
@property(nonatomic, strong, readonly) id <GXEntityDataQueryCollectionResult> lastQueryCollectionResult;

#pragma mark - Override Points

/**
 * Returns the initial query type for the current state
 */
- (GXEntityDataQueryType)queryTypeForCurrentState;

/**
 * Called in onDidFinishLoadingQuerySuccesfully:withResult:context:
 * Default implementations returns queryInfo.type == GXEntityDataQueryTypeFirst || queryInfo.type == GXEntityDataQueryTypeRefresh && !queryInfo.allLoadedData
 */
- (BOOL)shouldAddLoadedInfoRefreshKeepOnDidFinishLoadingQuerySuccesfully:(id <GXEntityDataQueryCollectionInfo>)queryInfo
																  result:(id <GXEntityDataQueryCollectionResult>)result
																 context:(NSMutableDictionary *)context;

@end
