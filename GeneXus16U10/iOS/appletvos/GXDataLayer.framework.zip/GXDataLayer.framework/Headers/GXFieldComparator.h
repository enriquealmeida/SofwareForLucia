//
//  GXFieldComparator.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 25/08/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;

typedef BOOL (GXFieldComparatorFunction)(id value1, id value2);

@protocol GXEntityComparator <NSObject>

- (BOOL)compareEntity:(id)entity1 toEntity:(id)entity2;

@end

@interface GXFieldComparator : NSObject <GXEntityComparator> {
	NSString *_fieldKey;
	GXFieldComparatorFunction *_fieldComparatorFunction;
}

- (id)initWithFieldKey:(NSString *)fieldKey; // uses compareObjects FieldComparator

- (id)initWithFieldKey:(NSString *)fieldKey
	   fieldComparator:(GXFieldComparatorFunction)fieldComparatorFunction;

@end

@interface GXDictionaryFieldComparator : GXFieldComparator
@end

@interface GXCompoundFieldComparator : NSObject <GXEntityComparator> {
	NSArray *_fieldComparators;
}

- (id)initWithFieldComparators:(NSArray *)comparators;

@end

BOOL compareObjects(id object1, id object2);
BOOL compareDates(NSDate *date1, NSDate *date2);
BOOL compareHoursMinutes(NSDate *date1, NSDate *date2);
BOOL compareDatesAndHoursMinutes(NSDate *date1, NSDate *date2);
BOOL compareFirstLetter(NSString *string1, NSString *string2);

NSString *firstLetterTitle(NSString *aString);