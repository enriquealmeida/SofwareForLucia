//
//  GXEOStoreManager.h
//  GXCoreModule_SD_Store
//
//  Created by Fabian Inthamoussu on 5/2/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import GXStandardClasses;
@import StoreKit;

NS_ASSUME_NONNULL_BEGIN

extern NSInteger const GXCoreModule_SD_Store_PurchasePlatformEnumValue_iTunes;

@interface GXEOStoreManager : GXExternalObjectBase

@property(class, nonatomic, readonly) BOOL canMakePurchases;

+ (void)getProducts:(nullable NSSet<NSString *> *)productIdentifiers
	 withCompletion:(void(^)(id<GXSDTDataCollection> _Nullable products, NSError * _Nullable error))completion;

+ (void)purchaseProduct:(nonnull NSString *)prodId
			   quantity:(NSUInteger)quantity
			 completion:(nonnull void(^)(id<GXSDTData> _Nullable result, NSError * _Nullable error))completion;

+ (void)getPurchasesWithCompletion:(nonnull void(^)(id<GXSDTData> _Nonnull purchasesInformation, NSError * _Nullable error))completion;

+ (void)restorePurchasesWithCompletion:(void(^)(id<GXSDTData> _Nullable purchasesInformation, NSError * _Nullable error))completion;

+ (void)consumeProduct:(NSString *)productIdentifier completion:(void(^)(NSError * _Nullable error))completion;

@end


@interface GXEOStoreManager (Helpers)

+ (id<GXSDTData>)purchaseResultSDTWithTransaction:(SKPaymentTransaction *)transaction
								  transactionData:(nullable NSString *)transactionData;

+ (id<GXSDTData>)purchaseResultSDTWithSuccess:(BOOL)success
								   purchaseId:(nullable NSString *)purchaseId
									productId:(NSString *)productId
							  transactionData:(nullable NSString *)transactionData;

@end


@interface GXEOStoreManager (OfflineGenerator) // Synchronic methods, must not be called on main thread

@property(nonatomic, readonly) BOOL canMakePurchases;

- (id<GXSDTDataCollection>)getProducts:(NSArray *)params;

- (id<GXSDTData>)purchaseProduct:(NSArray *)params;

- (id<GXSDTData>)getPurchases;

- (id<GXSDTData>)restorePurchases;

- (BOOL)consumeProduct:(NSArray *)params;

@end

NS_ASSUME_NONNULL_END
