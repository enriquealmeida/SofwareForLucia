//
//  GXCoreModule_SD_Store.h
//  GXCoreModule_SD_Store
//
//  Created by Fabian Inthamoussu on 26/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_SD_Store.
FOUNDATION_EXPORT double GXCoreModule_SD_StoreVersionNumber;

//! Project version string for GXCoreModule_SD_Store.
FOUNDATION_EXPORT const unsigned char GXCoreModule_SD_StoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_SD_Store/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
#import <GXCoreModule_SD_Store/GXEOStoreManager.h>
