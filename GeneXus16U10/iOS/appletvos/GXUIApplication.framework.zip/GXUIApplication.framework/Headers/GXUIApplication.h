//
//  GXUIApplication.h
//  GXUIApplication
//
//  Created by Fabian Inthamoussu on 26/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
//! Project version number for GXUIApplication.
FOUNDATION_EXPORT double GXUIApplicationVersionNumber;

//! Project version string for GXUIApplication.
FOUNDATION_EXPORT const unsigned char GXUIApplicationVersionString[];

