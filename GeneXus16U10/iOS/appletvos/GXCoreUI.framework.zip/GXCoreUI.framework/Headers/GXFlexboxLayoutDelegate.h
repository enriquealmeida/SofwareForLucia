//
//  GXFlexboxLayoutDelegate.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 08/10/2018.
//  Copyright © 2018 GeneXus. All rights reserved.
//

#import <GXCoreUI/GXControl.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXFlexboxLayoutDelegate <GXControl>

- (CGSize)gxRequiredSizeGivenSize:(CGSize)size NS_SWIFT_NAME(gxRequiredSize(givenSize:));

@end

NS_ASSUME_NONNULL_END
