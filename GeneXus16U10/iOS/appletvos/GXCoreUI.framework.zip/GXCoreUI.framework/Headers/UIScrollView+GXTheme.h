//
//  UIScrollView+GXTheme.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 5/7/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;

NS_ASSUME_NONNULL_BEGIN

@interface UIScrollView (GXTheme)

- (void)applyGxThemeClassWithScroll:(nullable id<GXThemeClassWithScroll>)themeClassWithScroll;

- (void)applyGXScrollIndicatorsStyle:(GXScrollIndicatorsStyle)indicatorsStyle;
- (void)applyGXScrollIndicatorsVisibility:(GXScrollIndicatorsVisibility)indicatorsVisibility;
- (void)applyGXScrollBouncingStyle:(GXScrollBouncingStyle)bouncingStyle;

@end

NS_ASSUME_NONNULL_END
