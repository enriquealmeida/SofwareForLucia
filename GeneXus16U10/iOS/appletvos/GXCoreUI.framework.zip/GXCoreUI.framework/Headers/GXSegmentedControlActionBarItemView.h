//
//  GXSegmentedControlActionBarItemView.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 9/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXCoreUI/GXControlActionBarItem.h>
#import <GXCoreUI/GXSegmentedControlItem.h>

@interface GXSegmentedControlActionBarItemView : GXSegmentedControlItem <GXControlActionBarItemView>

@end
