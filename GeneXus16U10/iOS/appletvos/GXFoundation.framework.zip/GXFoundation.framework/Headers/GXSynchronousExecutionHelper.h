//
//  GXSynchronousExecutionHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 1/30/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

/**
 * This class allows the synchronous execution of asynchronous tasks
 */
@interface GXSynchronousExecutionHelper : NSObject

/*!
 Creates a lock and executes the block in the main queue
 
 @param block The block must perform all the operations that involve the setup and execution of the async task. It is executed after creating / obtaining the lock. It might be NULL.
 @param async Whether the given block is dispatched async or sync on the main queue.
 @discussion This method cannot be called from the main thread.
 */
- (void)startWithBlock:(void(^ _Nullable)(void))block async:(BOOL)async;

/// Calls [self startWithBlock:block async:YES]
- (void)startWithAsyncBlock:(void(^ _Nullable)(void))block;

/// Calls [self startWithBlock:block async:NO]
- (void)startWithSyncBlock:(void(^ _Nullable)(void))block;

/// Calls [self startWithBlock:NULL async:NO]
- (void)start;

/// Releases de lock and allows executing the first waiting block
- (void)signal;

/*!
 The  block passed to this method will be executed after the async task finishes.
 
 @param block The block to be executing after obtaining the lock. It might be NULL (for just waiting).
 @discussion This method cannot be called from the main thread.
 */
- (void)executeWaitingBlock:(void(^ _Nullable)(void))block;

/// Calls [self executeWaitingBlock:NULL]
- (void)wait;

/// Releases any lock and cancels execution of any pending block
- (void)cancel;

@end

NS_ASSUME_NONNULL_END
