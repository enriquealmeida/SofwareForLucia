//
//  NSString+Helpers.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 27/06/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSString (GXHelpers)

- (NSUInteger)gxNumberOfOccurrencesOfString:(NSString *)str;

/**
 * Returns the substring of the instance string, just before the occurrence of str.
 *
 * For example
 *   test = [@"some test/string" gxStringUpToFirstOccurrenceOfString:@"/"]; // test = @"some test"
 *
 * If str is not found in the original string, it is returned unmodified
 *
 */
- (NSString *)gxStringUpToFirstOccurrenceOfString:(NSString *)str;

- (NSArray<NSString *> *)gxSeparateStringWithSeparator:(NSString *)separatorStr
										  escapeString:(NSString *)escapeStr;

@end

NS_ASSUME_NONNULL_END
