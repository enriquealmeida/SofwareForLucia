//
//  GXLoggerService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 4/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXLog.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSUInteger, GXLoggerType) {
	GXLoggerTypeGeneral,
	GXLoggerTypeNetwork,			// TODO
	GXLoggerTypeSynchronization,	// TODO
	GXLoggerTypeDatabase,			// TODO
};

typedef NS_ENUM(NSUInteger, GXLoggerLevel) {
	GXLoggerLevelOff,
	GXLoggerLevelAlways,
	GXLoggerLevelFatal,
	GXLoggerLevelError,
	GXLoggerLevelWarning,
	GXLoggerLevelInfo,
	GXLoggerLevelDebug,
	
	// TODO: agregar Level Trace (o usar Debug) para registrar por donde pasa la aplicación.
	// Tendría que llamarlo desde cada ActionHandler y desde la clase GXProcedure cuando es offline.
	// Ver que cosas habría que registrar y si falta alguna cosa más.
};

@protocol GXLoggerService <NSObject>

- (void)startLogging;
- (void)endLogging;

@property(nonatomic, assign, readonly, getter=isLogEnabled) BOOL logEnabled;
- (GXLoggerLevel)logLevelForType:(GXLoggerType)type;

- (void)logMessage:(NSString *)message
		   forType:(GXLoggerType)type
		 withLevel:(GXLoggerLevel)level
	  logToConsole:(BOOL)logToConsole;

@end

@interface GXLog (GXLoggerService)

+ (id<GXLoggerService>)loggerService;

@end

NS_ASSUME_NONNULL_END
