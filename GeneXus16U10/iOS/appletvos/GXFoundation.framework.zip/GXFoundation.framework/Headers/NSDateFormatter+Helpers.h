//
//  NSDateFormatter+Helpers.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 6/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXCommon.h>

NS_ASSUME_NONNULL_BEGIN

@interface NSDateFormatter (Helpers)

// Calls dateFormatterWithTimeZone_UTC_ForDateFormatterDateStyle:timeStyle:hasMilliseconds:localeId:useCurrentCalendar: with useCurrentCalendar = NO.
+ (NSDateFormatter *)dateFormatterWithTimeZone_UTC_ForDateFormatterDateStyle:(NSDateFormatterStyle)dateStyle
																   timeStyle:(NSDateFormatterStyle)timeStyle
															 hasMilliseconds:(BOOL)milliseconds
																	localeId:(nullable NSString *)localeId;

+ (NSDateFormatter *)dateFormatterWithTimeZone_UTC_ForDateFormatterDateStyle:(NSDateFormatterStyle)dateStyle
																   timeStyle:(NSDateFormatterStyle)timeStyle
															 hasMilliseconds:(BOOL)milliseconds
																	localeId:(nullable NSString *)localeId
														  useCurrentCalendar:(BOOL)useCurrentCalendar;

+ (NSDateFormatter *)dateFormatterWithTimeZone_UTC_Locale_en_US_POSIX_forDateFormat:(NSString *)dateFormat;

+ (NSDateFormatterStyle)dateFormatterStyleFromGXDataDateFormat:(GXDataDateFormat)dateFormat;
+ (NSDateFormatterStyle)dateFormatterStyleFromGXDataTimeFormat:(GXDataTimeFormat)timeFormat;

+ (nullable NSString *)gxDateFormatForShortGXFormat:(NSString *)shortFormat;

@end

NS_ASSUME_NONNULL_END
