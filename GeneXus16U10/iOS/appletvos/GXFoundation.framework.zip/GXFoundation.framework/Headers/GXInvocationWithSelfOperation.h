//
//  GXInvocationWithSelfOperation.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/07/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXInvocationWithSelfOperation : NSOperation

- (instancetype)initWithTarget:(id)target selector:(SEL)sel NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

@property(assign) BOOL hasReturnValue;
@property(nullable, nonatomic, strong, readonly) id result;
@property(nullable, nonatomic, strong) id context;

@end

NS_ASSUME_NONNULL_END
