//
//  GXFoundationServices.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 9/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXAlertMessageService.h>
#import <GXFoundation/GXLoggerService.h>
#import <GXFoundation/GXNetworkActivityIndicatorService.h>
#import <GXFoundation/GXProgressActivityIndicatorService.h>

#if TARGET_OS_IOS || TARGET_OS_WATCH
@protocol GXWCSessionService;
#endif

NS_ASSUME_NONNULL_BEGIN

@interface GXFoundationServices : NSObject

+ (id <GXAlertMessageService>)alertMessageService;
+ (nullable id <GXLoggerService>)loggerService;
+ (nullable id <GXNetworkActivityIndicatorService>)networkActivityIndicatorService;
+ (nullable id <GXProgressActivityIndicatorService>)progressActivityIndicatorService;
#if TARGET_OS_IOS || TARGET_OS_WATCH
@property(class, nullable, nonatomic, strong, readonly) id<GXWCSessionService> watchConnectivityService;
#endif

@end

NS_ASSUME_NONNULL_END
