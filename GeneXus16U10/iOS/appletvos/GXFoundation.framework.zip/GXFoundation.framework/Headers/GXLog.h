//
//  GXLog.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 27/12/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@protocol GXLogListener <NSObject>

- (void)logListenerNotifyMessage:(NSString *)message;

@end

@interface GXLog : NSObject {
@private
	NSFileHandle *_logFile;
}

+ (BOOL)isLogEnabled;

+ (BOOL)isLogRequestsEnabled;
+ (BOOL)isLogResponsesEnabled;
+ (BOOL)isLogResponsesBodyEnabled;


+ (void)logMessage:(NSString *)message;
+ (void)logWithFormat:(NSString *)format arguments:(va_list)args;
+ (void)logWithFormat:(NSString *)format, ...;
+ (void)logJSONObject:(id)object withTitle:(NSString *)title;

+ (void)logURLRequestIfEnabled:(NSURLRequest *)request;
+ (void)logURLResponseIfEnabled:(NSURLResponse *)response request:(NSURLRequest *)request data:(nullable NSData *)data;
+ (void)logURLResponseIfEnabled:(NSURLResponse *)response request:(NSURLRequest *)request dataPath:(NSString *)dataPath;

+ (void)logJSONParserElementIfEnabled:(id)element;

+ (void)clearLog;
+ (nullable NSString *)logString;

+ (void)addListener:(id<GXLogListener>)listener;
+ (void)removeListener:(id<GXLogListener>)listener;

@end

NS_ASSUME_NONNULL_END
