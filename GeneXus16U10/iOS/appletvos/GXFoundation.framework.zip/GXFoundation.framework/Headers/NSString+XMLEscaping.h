//
//  NSString+XMLEscaping.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 03/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;

@interface NSString (XMLEscaping)

- (NSString *)xmlSimpleEscapeString;
- (NSString *)xmlSimpleUnescapeString;

@end

@interface NSMutableString (XMLEscaping)

- (void)xmlSimpleEscape;
- (void)xmlSimpleUnescape;

@end