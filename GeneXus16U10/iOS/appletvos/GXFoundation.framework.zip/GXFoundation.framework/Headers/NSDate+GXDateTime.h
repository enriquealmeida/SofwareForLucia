//
//  NSDate+GXDateTime.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 20/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;
@import YAJL;

@interface NSDate (GXDateTime) <YAJLCoding>

#pragma mark - Date & DateTime (GXStd)

/// Returns YES if date has values smaller than days, NO otherwise
- (BOOL)isGxDateTime;

/// Ensures date has no value smaller than seconds (yyyy-MM-dd HH:mm:ss)
- (NSDate *)gxDateTimeNSDate;
/// Ensures date has no value smaller than days (yyyy-MM-dd)
- (NSDate *)gxDateNSDate;
/// Ensures date has no value smaller than seconds and has no values (same as empty) greater than hours (HH:mm:ss)
- (NSDate *)gxTimeOnlyDateTimeNSDate;

#pragma mark - Accessing date & time components (GXStd)

- (NSInteger)gxDayInteger;
- (NSInteger)gxMonthInteger;
- (NSInteger)gxYearInteger;

@end
