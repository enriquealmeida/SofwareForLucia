//
//  GXUtilities.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 17/11/10.
//  Copyright 2010 Artech. All rights reserved.
//

#define CURRENT_DEVICE_IPAD [GXUtilities currentDeviceIPAD]
#define CURRENT_DEVICE_IPHONE [GXUtilities currentDeviceIPHONE]
#define CURRENT_DEVICE_IPHONE_4INCH [GXUtilities currentDeviceIPHONE_4INCH]
#define CURRENT_DEVICE_IPHONE_4_7INCH [GXUtilities currentDeviceIPHONE_4_7INCH]
#define CURRENT_DEVICE_IPHONE_5_5INCH [GXUtilities currentDeviceIPHONE_5_5INCH]
#define GXTHROW_ABSTRACT_METHOD_EXCEPTION() @throw [NSException exceptionWithName:NSInvalidArgumentException reason:[NSString stringWithFormat:@"%s must be overridden in a subclass.", __PRETTY_FUNCTION__] userInfo:nil]

#if __IPHONE_OS_VERSION_MIN_REQUIRED >= __IPHONE_6_0
#define gx_dispatch_release(object)
#else
#define gx_dispatch_release(object) dispatch_release(object)
#endif

#import <GXFoundation/GXCommon.h>
#import <GXFoundation/GXHTTPWarningHeader.h>
@import CoreLocation;
@import MapKit;

NS_ASSUME_NONNULL_BEGIN

@interface GXInsensitiveMetadata : NSObject

+ (nullable id)metadataObjectForKey:(NSString *)key fromMetadata:(NSDictionary<NSString *, id> *)metadata;

@end

#define GXDeviceSystemVersion11_0	110000
#define GXDeviceSystemVersion10_0	100000
#define GXDeviceSystemVersion9_0	90000
#define GXDeviceSystemVersion8_1	80100
#define GXDeviceSystemVersion8_0	80000
#define GXDeviceSystemVersion7_1	70100
#define GXDeviceSystemVersion7_0	70000
#define GXDeviceSystemVersion6_1_4	60104
#define GXDeviceSystemVersion6_1_3	60103
#define GXDeviceSystemVersion6_1_2	60102
#define GXDeviceSystemVersion6_1_1	60101
#define GXDeviceSystemVersion6_1	60100
#define GXDeviceSystemVersion6_0_2	60002
#define GXDeviceSystemVersion6_0_1	60001
#define GXDeviceSystemVersion6_0	60000
#define GXDeviceSystemVersion5_1_1	50101
#define GXDeviceSystemVersion5_1	50100
#define GXDeviceSystemVersion5_0_1	50001
#define GXDeviceSystemVersion5_0	50000
#define GXDeviceSystemVersion4_3_5	40305
#define GXDeviceSystemVersion4_3_4	40304
#define GXDeviceSystemVersion4_3_3	40303
#define GXDeviceSystemVersion4_3_2	40302
#define GXDeviceSystemVersion4_3_1	40301
#define GXDeviceSystemVersion4_3	40300


// https://developer.apple.com/library/ios/documentation/General/Reference/InfoPlistKeyReference/Articles/iPhoneOSKeys.html#//apple_ref/doc/uid/TP40009252-SW22
#define GXAppBackgroundMode_Audio @"audio"
#define GXAppBackgroundMode_Location @"location"
#define GXAppBackgroundMode_Voip @"voip"
#define GXAppBackgroundMode_NewsstandContent @"newsstand-content"
#define GXAppBackgroundMode_ExternalAccessory @"external-accessory"
#define GXAppBackgroundMode_BluetoothCentral @"bluetooth-central"
#define GXAppBackgroundMode_BluetoothPeripheral @"bluetooth-peripheral"
#define GXAppBackgroundMode_Fetch @"fetch"
#define GXAppBackgroundMode_SilentRemoteNotification @"remote-notification" // Silent Notifications

#define GXBoolFromValue(value, defaultValue) (value ? [value boolValue] : defaultValue)
#define GXIntFromValue(value, defaultValue) (value ? [value intValue] : defaultValue)

#define kNSURLAboutBlankAbsoluteString @"about:blank"

extern NSUInteger const GXFlexibleClientMajorVersionNumber;
extern NSUInteger const GXFlexibleClientMinorVersionNumber;
extern NSUInteger const GXFlexibleClientRevisionNumber;

int GXIntCeilFromFloat(float f);

void gx_dispatch_on_background(dispatch_block_t block, dispatch_block_t _Nullable callbackBlock);
void gx_dispatch_on_background_with_priority(dispatch_block_t block, dispatch_queue_priority_t priotity, dispatch_block_t _Nullable callbackBlock);
void gx_dispatch_on_global_queue_with_priority(dispatch_block_t block, dispatch_queue_priority_t priotity, dispatch_block_t _Nullable callbackBlock);
void gx_dispatch_sync_on_main_queue(dispatch_block_t block);
void gx_dispatch_on_main_queue(dispatch_block_t block);
void gx_dispatch_group_notify_on_main_or_global_default_priority_queue(dispatch_group_t group, dispatch_block_t block);

@interface GXUtilities : NSObject

/**
 * Flexible client version
 * Format: major.minor.revision (GXFlexibleClientMinorVersionNumber.GXFlexibleClientMinorVersionNumber.GXFlexibleClientRevisionNumber)
 */
@property(class, nonatomic, strong, readonly) NSString *flexibleClientVersion;

/**
 * System version in numeric format
 * Format: major.minor.maintenance (ie. 6.1.4) -> major x 10000 + minor x 100 + maintenance (ie. 60104)
 */
+ (NSUInteger)deviceSystemVersion;

/**
 * Version in numeric format
 * Format: major.minor.maintenance (ie. 6.1.4) -> major x 10000 + minor x 100 + maintenance (ie. 60104)
 * minor and maintenance must be smaller than 100
 */
+ (NSUInteger)numericRepresentationFromVersionString:(NSString *)version;

/**
 * Returns:
 *   - NSOrderedAscending  if the metadata version1 is smaller than version2
 *   - NSOrderedSame       if they are equal
 *   - NSOrderedDescending if the metadata version1 is grater than version2
 */
+ (NSComparisonResult)comparaVersionString:(NSString *)version1 toVersion:(NSString *)version2;

+ (NSString *)deviceName;

+ (BOOL)showDeveloperInfo;

/*!
 Checks if the applications plist declaration includes the given background mode
 
 @param backgroundMode the background mode to check
 @result Returns YES if the given background mode is contained, NO otherwise
 @discussion See https://developer.apple.com/library/ios/documentation/General/Reference/InfoPlistKeyReference/Articles/iPhoneOSKeys.html#//apple_ref/doc/uid/TP40009252-SW22
 */
+ (BOOL)applicationContainsBackgroundMode:(NSString *)backgroundMode;

#if !TARGET_OS_WATCH
+ (BOOL)contentSizeCategoryIsAccessibilityCategory:(UIContentSizeCategory)category __attribute__((const));

+ (UIBarButtonItem *)flexibleSpaceSeparator;
+ (UIBarButtonItem *)fixedSpaceSeparator;
+ (UIBarButtonItem *)fixedSpaceSeparatorWidth:(CGFloat)width;
+ (void)addFlexibleSpaceSeparatorBetweenItems:(NSMutableArray *)items;
+ (void)addFlexibleSpaceSeparatorBetweenItems:(NSMutableArray *)items addLeftSeparator:(NSUInteger)leftCount addRightSeparator:(NSUInteger)rightCount;
#endif

+ (NSArray * _Null_unspecified)arrayFromObject:(id _Null_unspecified)anObject;
+ (id _Null_unspecified)lastObjectIfArrayFromObject:(id _Null_unspecified)anObject;

+ (nullable NSString *)urlParametersStringFrom:(NSDictionary<NSString *, id> *)parameters;

+ (nullable NSURL *)urlFromMaybeEscapedURLString:(NSString *)urlString;

+ (nullable NSError *)errorFromResponseData:(NSData *)data;

+ (NSString *)stringFromInteger:(NSInteger)integer;

+ (NSString *)stringFromFloat:(float)floatValue;

+ (nullable NSString *)stringFromObject:(nullable id)anObject;

+ (nullable NSString *)nonEmptyStringFromObject:(nullable id)anObject;

+ (BOOL)isStringNullOrEmpty:(nullable NSString *)string;

+ (BOOL)boolFromValue:(nullable id)value defaultValue:(BOOL)defaultValue;
+ (BOOL)boolFromValue:(nullable id)value; // defaultValue = NO
+ (nullable NSNumber *)unsignedIntegerNumberFromValue:(nullable id)value;
+ (nullable NSNumber *)integerNumberFromValue:(nullable id)value;
+ (nullable NSNumber *)floatNumberFromValue:(nullable id)value;
+ (nullable NSNumber *)doubleNumberFromValue:(nullable id)value;
+ (nullable NSDecimalNumber *)decimalNumberFromValue:(nullable id)value;
+ (nullable NSNumber *)numberWithBoolIfTrueFromValue:(id)value;

+ (CLLocationCoordinate2D)coordinateFromGeoString:(NSString *)locationStr forType:(GXDataType )fieldType;
+ (CLLocationCoordinate2D)coordinateFromGeoLocationString:(NSString *)locationStr;

+ (NSString *)geoLocationStringFromCoordinate:(CLLocationCoordinate2D)coordinate;
+ (NSString *)geoLocationStringFromCoordinate:(CLLocationCoordinate2D)coordinate forType:(GXDataType )fieldType;

#if !TARGET_OS_WATCH
+ (nullable MKPolyline *)polylineFromGeoLine:(nullable NSString *)geolineStr;
#endif

+ (nullable NSArray<GXHTTPWarningHeader *> *)httpWarningsFromHeader:(nullable NSString *)warningHeader; // Collection of GXHTTPWarningHeader;

+ (BOOL)currentDeviceIPAD;

+ (BOOL)currentDeviceIPHONE;

+ (BOOL)currentDeviceIPHONE_4INCH;
+ (BOOL)currentDeviceIPHONE_4_7INCH;
+ (BOOL)currentDeviceIPHONE_5_5INCH;

+ (NSArray<NSString *> *)alphabetCharacters;
+ (NSArray<NSString *> *)alphabetCharacters:(BOOL)ascending;

+ (BOOL)splitString:(NSString *)string byFirstOcurrenceOfString:(NSString *)separator toLeft:(NSString * _Nullable * _Nullable)left andRigth:(NSString * _Nullable * _Nullable)rigth;
+ (BOOL)splitString:(NSString *)string byLastOcurrenceOfString:(NSString *)separator toLeft:(NSString * _Nullable * _Nullable)left andRigth:(NSString * _Nullable * _Nullable)rigth;
+ (BOOL)splitString:(NSString *)string
byOcurrenceOfString:(NSString *)separator
		withOptions:(NSStringCompareOptions)options
			 toLeft:(NSString * _Nullable * _Nullable)left
		   andRigth:(NSString * _Nullable * _Nullable)rigth;

+ (NSString *)stringByRemovingEnclosingQuotes:(NSString *)string;
+ (NSString *)stringByRemovingEnclosingQuotes:(NSString *)string hasQuotes:(BOOL * _Nullable)quotes isTranslatable:(BOOL * _Nullable)translatable;

+ (NSString *)stringWithGXFormat:(NSString *)format, ... NS_REQUIRES_NIL_TERMINATION;
+ (NSString *)stringWithGXFormat:(NSString *)format arguments:(va_list)argList;
+ (NSString *)stringWithGXFormat:(NSString *)format values:(NSArray *)values;

/**
 * Returns the given object if it's kind of the given class, otherwise if it conforms to YAJLCoding
 *	protocol, checks again with it's JSON object, and returns it if it's kind of the given class, and
 *	if not returns nil
 */
+ (nullable id)jsonObject:(nullable NSObject *)object ofClass:(Class)expectedClass;

/*!
 Creates a unique path in the temp directory of the application
 
 @discussion Cosider using createUniqueGXDataTemporaryFilePath instead if file needs to be accessible by GXFileSystemObject
 */
+ (NSString *)createUniqueTemporaryFilePath;

/// Excludes the given path from backup using NSURLIsExcludedFromBackupKey
+ (void)excludePathFromBackup:(NSString *)path;

+ (GXConnectivitySupportType)connectivitySupportFromValue:(nullable id)value;

+ (NSStringEncoding)stringEncodingFromCharsetString:(nullable NSString *)strEncoding;

#if TARGET_IPHONE_SIMULATOR
@property(class, nonatomic, assign, readonly) CGFloat simulatorAnimationDragCoefficient;
#endif // TARGET_IPHONE_SIMULATOR

@end

@interface GXUtilities (GXDeprecated)

+ (BOOL)splitString:(NSString *)string ByFirstOcurrenceOfString:(NSString *)separator toLeft:(NSString * _Nullable * _Nullable)left andRigth:(NSString * _Nullable * _Nullable)rigth __attribute__((deprecated("Use splitString:byFirstOcurrenceOfString:toLeft:andRigth: instead")));

@end

NS_ASSUME_NONNULL_END
