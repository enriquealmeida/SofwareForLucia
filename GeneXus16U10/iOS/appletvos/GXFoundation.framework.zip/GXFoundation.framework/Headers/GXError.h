//
//  GXError.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/03/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

extern NSString *const GXErrorDomain;
extern NSString *const GXModelErrorDomain;
extern NSString *const GXHTTPURLResponseErrorDomain;

@interface NSError (GXError)

+ (instancetype)userCancelledError;

+ (instancetype)userCancelledErrorWithUnderlyingError:(nullable NSError *)underlyingError;

+ (instancetype)loopExitError;



/**
 * Creates an error object with default domain, code and description
 */
+ (instancetype)defaultGXError;

/**
 * Creates an error object with default domain and code, and:
 *  - the given description if running on the KBN or in the iPhone Simulator
 *  - the default description if running in the compiled app on a device
 */
+ (instancetype)defaultGXErrorWithDeveloperDescription:(NSString *)description;

/**
 * Creates an error object with the given domain and code, and:
 *  - the given description if running on the KBN or in the iPhone Simulator
 *  - the default description if running in the compiled app on a device
 */
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code developerDescription:(NSString *)description;

+ (instancetype)defaultGXErrorWithLocalizedDescription:(nullable NSString *)description;
+ (instancetype)defaultGXErrorWithCode:(NSInteger)code localizedDescription:(nullable NSString *)description;
+ (instancetype)errorWithDomain:(NSString *)domain code:(NSInteger)code localizedDescription:(nullable NSString *)description;
+ (instancetype)errorForHTTPURLResponseStatusCode:(NSUInteger)statusCode;
+ (instancetype)loginCanceledError;
+ (instancetype)notAutorizedErrorWithDescription:(nullable NSString *)desc;

+ (instancetype)wrongNumberOfParametersDeveloperErrorForMethod:(NSString *)methodName;
+ (instancetype)wrongNumberOfParametersDeveloperErrorForMethod:(NSString *)methodName received:(NSUInteger)received expected:(NSUInteger)expected;

+ (instancetype)permissionDeniedErrorWithGoToSettingsRecoveryAttempter;

/*!
 Creates an error object with default domain with a recovery attempter
 
 @param settingsLocalizedRecoveryOption String used for the recovery option, default "Settings" is used if nil.
 @param localizedDescription String used for the error's localized description, default "Permission denied" is used if nil.
 @param localizedRecoverySuggestion String used for the recovery suggestion, default "Enable permission in Settings" is used if nil.
 */
+ (instancetype)permissionDeniedErrorWithGoToSettingsRecoveryAttempter:(nullable NSString *)settingsLocalizedRecoveryOption
												  localizedDescription:(nullable NSString *)localizedDescription
										   localizedRecoverySuggestion:(nullable NSString *)localizedRecoverySuggestion;

- (nullable NSString *)userInfoLocalizedDescription;
- (BOOL)hasUserInfoLocalizedDescription;

/*!
 Logs localized description if show developer info is enabled
 
 @result YES if show developer info is enabled, NO otherwise
 @discussion See [GXUtilities showDeveloperInfo]
 */
- (BOOL)logLocalizedDescriptionIfShowDeveloperInfoIsEnabled;

- (BOOL)isUserCancelledError;
- (BOOL)isLoopExitError;
- (BOOL)isNotConnectedToInternetError;
- (BOOL)isLoginCanceledError;
- (BOOL)isNotAuthorizedError;
/**
 * Returns YES if the error could be caused due to bad network conditions, NO otherwise, errors include:
 *	TimedOut: the timeout interval in request expires before a load can complete
 *	CannotFindHost: the host name for a URL cannot be resolved (DNS lookup failed)
 *	CannotConnectToHost: an attempt to connect to a host has failed; this can occur when a host name resolves, but the host is down or may not be accepting connections on a certain port
 *	NetworkConnectionLost: a client or server connection is severed in the middle of an in-progress load
 *	NotConnectedToInternet: an internet connection is not established and cannot be established automatically, either through a lack of connectivity, or by the user's choice not to make a network connection automatically
 *	InternationalRoamingOff: would require activating a data context while roaming, but international roaming is disabled
 *	CallIsActive: a phone call is active on a network that does not support simultaneous phone and data communication (EDGE or GPRS)
 *	DataNotAllowed: the cellular network disallows a connection
 */
- (BOOL)isNetworkPossibleError;

@end

NS_ASSUME_NONNULL_END
