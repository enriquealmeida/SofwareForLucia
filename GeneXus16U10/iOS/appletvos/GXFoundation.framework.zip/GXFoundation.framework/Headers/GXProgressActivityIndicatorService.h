//
//  GXProgressActivityIndicatorService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 29/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXProgressIndicatorData.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXProgressActivityIndicatorService <NSObject>

@property(nonatomic, strong) GXProgressIndicatorData *data;

- (void)showIndicator;
- (void)showIndicatorWithTitle:(nullable NSString *)title;
- (void)showIndicatorWithTitle:(nullable NSString *)title description:(nullable NSString *)description;
- (void)hideIndicator;
- (void)invalidate;

- (void)shouldHideOnNewViewController:(BOOL)hide;

- (BOOL)isShowing;

@end

NS_ASSUME_NONNULL_END
