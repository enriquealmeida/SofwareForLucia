//
//  GXTypedObjectInfo.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/12/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXDescriptionElement.h>
#import <GXObjectsModel/GXEntityDataFieldInfoProtocol.h>
#import <GXObjectsModel/GXApplicationImageUploadSettings.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXAttributeControlType) {
	GXAttributeControlTypeEdit,
	GXAttributeControlTypeComboBox,
	GXAttributeControlTypeRadioButton,
	GXAttributeControlTypeCheckBox,
	GXAttributeControlTypeDynamicComboBox,
	GXAttributeControlTypeListBox,
	GXAttributeControlTypeDynamicListBox
};

@interface GXTypedObjectInfo : GXDescriptionElement <GXEntityDataFieldInfo>

@property(nonnull, nonatomic, strong, readonly) NSString *name;
@property(assign, readonly) GXDataType dataType;
@property(nullable, nonatomic, strong, readonly) NSDictionary<NSString *, id> *properties;

@property(nonatomic, assign, readonly) BOOL isCollection;
@property(nullable, nonatomic, strong, readonly) id <GXEntityDataFieldInfo> collectionItemFieldInfo;

@property(nonatomic, assign, readonly) NSUInteger length;
@property(nonatomic, assign, readonly) NSUInteger decimals;
@property(nullable, nonatomic, strong, readonly) NSString *regularExpression;
@property(nonatomic, assign, readonly) BOOL suggest;
@property(nonatomic, assign, readonly) BOOL password;
@property(nullable, nonatomic, strong, readonly) NSString *inputPicture;
@property(nullable, nonatomic, strong, readonly) NSString *basedOnName;
@property(nonatomic, assign, readonly) GXSpecialDomainType specialDomain;
@property(nonatomic, assign, readonly) GXDataDateFormat dateFormat;
@property(nonatomic, assign, readonly) GXDataTimeFormat timeFormat;
@property(nonatomic, assign, readonly) GXBasedOnType basedOnType;
@property(nullable, nonatomic, strong, readonly) id<GXEntityDataFieldInfo> basedOnInfo;
@property(nonatomic, assign, readonly) GXImageUploadResolutionType imageUploadResolution;

- (nullable instancetype)initWithMetadata:(NSDictionary<NSString *, id> *)metadata NS_DESIGNATED_INITIALIZER;

+ (nullable instancetype)typedObjectInfoFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
- (nullable instancetype)initWithName:(NSString *)name basedOnName:(NSString *)basedOnName basedOnType:(GXBasedOnType)basedOnType;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name description:(nullable NSString *)desc NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end


@interface GXTypedObjectCollectionItemInfoWrapper : NSObject <GXEntityDataFieldInfo> {
	__weak id <GXEntityDataFieldInfo> _collectionFieldInfo;
}

/// Collection field info [collectionFieldInfo entityDataFieldInfoIsCollection] == YES
@property(nonatomic, strong, readonly) id<GXEntityDataFieldInfo> collectionFieldInfo;

- (instancetype)initWithCollectionFieldInfo:(id<GXEntityDataFieldInfo>)collectionFieldInfo NS_DESIGNATED_INITIALIZER; // collectionFieldInfo is not retained

- (instancetype)init NS_UNAVAILABLE;

@end


@interface GXTypedObjectCollectionItemInfoContainerWrapper : NSObject <GXEntityDataFieldInfo>

@property(nonatomic, strong, readonly) id<GXEntityDataFieldInfo> collectionItemFieldInfo;

- (instancetype)initWithCollectionFieldInfo:(id <GXEntityDataFieldInfo>)collectionItemFieldInfo NS_DESIGNATED_INITIALIZER; // collectionItemFieldInfo is retained

- (instancetype)init NS_UNAVAILABLE;

@end

NS_ASSUME_NONNULL_END
