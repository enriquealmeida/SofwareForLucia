//
//  GXThemeClassList.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/04/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassContainerBase.h>
#import <GXObjectsModel/GXThemeClassGroupSeparator.h>
#import <GXObjectsModel/GXThemeClassHorizontalSeparator.h>
#import <GXObjectsModel/GXThemeClassWithDragAndDrop.h>
#import <GXObjectsModel/GXThemeClassWithLoadingAnimation.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassList : GXThemeClassContainerBase <GXThemeClassWithDragAndDrop, GXThemeClassWithLoadingAnimation>

@property(nullable, nonatomic, strong, readonly) GXThemeClass *listItemOddItemThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *listItemEvenItemThemeClass;
@property(nonatomic, assign, readonly) BOOL showLineSeparator;
@property(nullable, nonatomic, strong, readonly) GXThemeClassGroupSeparator *groupSeparatorThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClassHorizontalSeparator *horizontalSeparatorThemeClass;

@end

NS_ASSUME_NONNULL_END
