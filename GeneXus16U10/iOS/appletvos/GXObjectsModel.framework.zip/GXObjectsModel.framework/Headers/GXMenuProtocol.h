//
//  GXMenuProtocol.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/08/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXActionDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXMenuControlType) {
	GXMenuControlTypeDefault,
    GXMenuControlTypeList,
    GXMenuControlTypeGrid,
    GXMenuControlTypeTab
};

@protocol GXMenuItem;

@protocol GXMenu <NSObject>

@property(nonatomic, strong, readonly) NSString *menuName;
@property(nullable, nonatomic, strong, readonly) NSString *menuTitle;
@property(nullable, nonatomic, strong, readonly) NSString *menuBackgroundImageName;
@property(nullable, nonatomic, strong, readonly) NSString *menuHeaderImageName;
@property(nullable, nonatomic, strong, readonly) NSString *menuSecurityLevel;
@property(nonatomic, strong, readonly) NSArray<id<GXMenuItem>> *menuItems;
@property(nonatomic, strong, readonly) NSArray<id <GXEventDescriptor>> *menuNotificationEvents;
@property(nonatomic, strong, readonly) NSArray<id <GXEventDescriptor>> *menuEvents;

@property(nonatomic, assign, readonly) BOOL menuShowApplicationBars;
@property(nullable, nonatomic, strong, readonly) NSString *menuApplicationBarsClassName;
@property(nonatomic, assign, readonly) BOOL menuShowLogoutButton;
@property(nullable, nonatomic, strong, readonly) NSString *menuThemeClassFullName;
@property(nonatomic, assign, readonly) GXConnectivitySupportType menuConnectivitySupport;

@property(nonatomic, assign, readonly) GXMenuControlType menuControlType;

#if TARGET_OS_IOS
@optional
@property(nonatomic, assign, readonly) GXAdsPositionType menuAdsPosition __attribute__((deprecated("Always returns GXAdsPositionNone.")));
@required
#endif // TARGET_OS_IOS

@end

#pragma mark -

@protocol GXMenuItem <NSObject>

@property(nonatomic, strong, readonly) NSString *menuItemName;
@property(nullable, nonatomic, strong, readonly) NSString *menuItemTitle;
@property(nullable, nonatomic, strong, readonly) NSString *menuItemImageName;
@property(nullable, nonatomic, strong, readonly) id <GXActionDescriptor> menuItemActionDescriptor;
@property(nullable, nonatomic, strong, readonly) NSString *menuItemThemeClassFullName;

@end

NS_ASSUME_NONNULL_END
