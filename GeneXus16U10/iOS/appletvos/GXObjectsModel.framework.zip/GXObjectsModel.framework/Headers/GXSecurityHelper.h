//
//  GXSecurityHelper.h
//  GXFlexibleClient
//
//  Created by willy on 3/11/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXSecurityHelper : NSObject
@end

NS_ASSUME_NONNULL_END
