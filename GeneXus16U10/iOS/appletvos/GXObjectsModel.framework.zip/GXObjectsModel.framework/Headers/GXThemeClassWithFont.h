//
//  GXThemeClassWithFont.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 05/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
@import UIKit;
@import GXFoundation;

NS_ASSUME_NONNULL_BEGIN

@protocol GXThemeClassWithFont <NSObject>

/*!
 Theme class font calculated with properties: fontSize, fontWeight, fontStyle, fontCategory & fontFamily
 
 @result The calculated font
 @discussion Same as calling fontResolvingToDefaultValue:YES
 */
@property(nullable, nonatomic, strong, readonly) UIFont *font;
@property(nullable, nonatomic, strong, readonly) UIColor *foreColor;
@property(nullable, nonatomic, strong, readonly) UIColor *highlightedForeColor;
@property(nullable, nonatomic, strong, readonly) UIColor *inviteMessageColor;

@property(nonatomic, assign, readonly) CGFloat fontSize;
@property(nonatomic, assign, readonly) GXFontWeightType fontWeight;
@property(nonatomic, assign, readonly) BOOL fontStrikeThrough;
@property(nonatomic, assign, readonly) GXFontStyleType fontStyle;
@property(nonatomic, assign, readonly) GXFontCategoryType fontCategory;
@property(nullable, nonatomic, strong, readonly) NSString *fontFamily;

/*!
 Theme class font calculated with properties: fontSize, fontWeight, fontStyle, fontCategory & fontFamily
 
 @param resolveToDefault NO if result font should be nil when all properties have default values
 @result The calculated font
 @discussion The result font is calculated with properties resolved to default (even if resolveToDefault = NO), but if resolveToDefault = YES and all properties are default, the result font is nil.
 */
- (nullable UIFont *)fontResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable UIColor *)foreColorResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable UIColor *)highlightedForeColorResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable UIColor *)inviteMessageColorResolvingToDefaultValue:(BOOL)resolveToDefault;

- (CGFloat)fontSizeResolvingToDefaultValue:(BOOL)resolveToDefault;
- (GXFontWeightType)fontWeightResolvingToDefaultValue:(BOOL)resolveToDefault;
- (GXFontStyleType)fontStyleResolvingToDefaultValue:(BOOL)resolveToDefault;
- (GXFontCategoryType)fontCategoryResolvingToDefaultValue:(BOOL)resolveToDefault;
- (nullable NSString *)fontFamilyResolvingToDefaultValue:(BOOL)resolveToDefault;

@end

NS_ASSUME_NONNULL_END
