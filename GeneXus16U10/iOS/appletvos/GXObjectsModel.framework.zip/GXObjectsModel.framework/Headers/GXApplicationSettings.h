//
//  GXApplicationSettings.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXApplicationImageUploadSettings.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXApplicationSettings : NSObject <NSCoding>

- (instancetype)initWithVersion:(nullable NSString *)version
					  themeName:(nullable NSString *)themeName
				navigationStyle:(nullable NSString *)navigationStyle
			convertTimesFromUTC:(BOOL)convertFromUTC
	defaultInterfaceOrientation:(GXInterfaceOrientation)orientation
			   imageUploadSizes:(nullable GXApplicationImageUploadSettings *)imgUploadSizes
			 validPlatformNames:(nullable NSArray<NSString *> *)validPlatformNames;

@property(nullable, nonatomic, strong, readonly) NSString *version;
@property(nullable, nonatomic, strong, readwrite) NSString *themeName;
@property(nonatomic, strong, readonly) NSString *navigationStyle;
@property(nonatomic, assign, readonly) BOOL convertTimesFromUTC;
@property(nonatomic, assign, readonly) GXInterfaceOrientation defaultInterfaceOrientation;
@property(nonatomic, strong, readonly) GXApplicationImageUploadSettings *imageUploadSizes;

@property(nonatomic, strong, readonly) NSArray<NSString *> *validPlatformNames;

@property(nullable, nonatomic, strong, readwrite) NSString *ideConnectionString;

@end


@interface GXApplicationSettings (GXModel)

+ (nullable GXApplicationSettings *)currentModelSettings;

@end

NS_ASSUME_NONNULL_END
