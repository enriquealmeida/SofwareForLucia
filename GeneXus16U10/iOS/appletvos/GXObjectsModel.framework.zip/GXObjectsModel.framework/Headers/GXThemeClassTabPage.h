//
//  GXThemeClassTabPage.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 12/08/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassTabPage : GXThemeClassBase

@end

NS_ASSUME_NONNULL_END
