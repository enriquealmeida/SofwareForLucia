//
//  GXModelManager+GXModelManagerExtension.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 26/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXModelManager.h>
#import <GXObjectsModel/GXModelLoadOperationContext+GXModelManagerExtension.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXModelManagerExtension <NSObject>

- (nullable NSArray<__kindof GXModelLoadOperation *> *)extensionModelLoadOperationsForContext:(GXModelLoadOperationContext *)context;
- (nullable NSDictionary<NSString *, id> *)loadExtensionModelObjectsFromCacheForApplication:(id <GXApplication>)application
																					  error:(out NSError * __autoreleasing __nullable * __nullable)error;
- (nullable NSDictionary<NSString *, id> *)onModelLoadOperationsDidFinishForContext:(GXModelLoadOperationContext *)context
																			  error:(out NSError * __autoreleasing __nullable * __nullable)error;
- (void)clearCachedExtensionModelObjectsForApplication:(id <GXApplication>)application;

@end

@interface GXModelManager (GXModelManagerExtension)

- (void)registerModelManagerExtension:(id <GXModelManagerExtension>)modelManagerExtension;

+ (nullable NSString *)defaultModelFileApplicationCacheDirectoryForApplication:(id <GXApplication>)application createIfNeeded:(BOOL)createIfNeeded;
+ (NSString *)modelFileFullPathForDirectoryPath:(NSString *)dirPath extension:(NSString *)extension;

@end

NS_ASSUME_NONNULL_END
