//
//  GXDebuggerModelService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXThemeClass.h>

@protocol GXDebuggerModelService <NSObject>

@property(nonatomic, assign, readonly, getter=isActive) BOOL active;

- (NSURL *)urlForImageName:(NSString *)imageName;
- (BOOL)hasOverrideForImageName:(NSString *)imageName;
- (void)notifyLayoutChanges;
- (GXThemeClass *)themeClassForName:(NSString *)name parentClass:(GXThemeClass *)parent;

@end
