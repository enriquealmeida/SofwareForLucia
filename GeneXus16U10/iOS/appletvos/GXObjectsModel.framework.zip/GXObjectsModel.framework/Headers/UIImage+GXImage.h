//
//  UIImage+GXImage.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 03/05/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import UIKit;
#import <GXObjectsModel/GXImage.h>

#define GXIMAGE_GXIMAGE @"gxImage" // GXImage

NS_ASSUME_NONNULL_BEGIN

@interface UIImage (GXImage)

+ (nullable UIImage *)gxImageNamed:(NSString *)name;

- (nullable NSData *)gxNSDataWithPNGFormat:(BOOL)png;

- (nullable NSData *)gxNSDataWithPNGFormat:(BOOL)png jpegCompressionQuality:(CGFloat)compressionQuality;

/*!
 Saves the image to file
 
 @param fileURL The candidate URL for saving the image file. If pathExtension is not png or jpg, a new URL with jpg extension is used
 @result The file URL where image was saved, nil image could not be saved
 */
- (nullable NSURL *)saveImageToFileURL:(NSURL *)fileURL;

/*!
 Saves the image to file
 
 @param fileURL The candidate URL for saving the image file. If pathExtension is not png or jpg, a new URL with jpg extension is used
 @param compressionQuality The compression quality used when saving an image as a JPEG image (value between 0.0 and 1.0)
 @result The file URL where image was saved, nil image could not be saved
 */
- (nullable NSURL *)saveImageToFileURL:(NSURL *)fileURL jpegCompressionQuality:(CGFloat)compressionQuality;

/*!
 Saves the image to file to a temporary file
 
 @param pathExtension Suggested file extension
 @result The file URL where image was saved, nil on error
 @discussion Creates a file URL using [GXUtilities createUniqueTemporaryFilePath] and the given pathExtension, then calls saveImageToFileURL:. Cosider using saveToGXDataTemporaryFileWithPathExtension instead if file needs to be accessible by GXFileSystemObject
 */
- (nullable NSURL *)saveToTemporaryFileWithPathExtension:(nullable NSString *)pathExtension;

/*!
 Saves the image to file to a temporary file
 
 @param pathExtension Suggested file extension
 @param compressionQuality The JPEG compression quality to use when saving the image (value between 0.0 and 1.0)
 @result The file URL where image was saved, nil on error
 @discussion Creates a file URL using [GXUtilities createUniqueTemporaryFilePath] and the given pathExtension, then calls saveImageToFileURL:. Cosider using saveToGXDataTemporaryFileWithPathExtension instead if file needs to be accessible by GXFileSystemObject
 */
- (nullable NSURL *)saveToTemporaryFileWithPathExtension:(nullable NSString *)pathExtension jpegCompressionQuality:(CGFloat)compressionQuality;

- (UIImage *)imageWithGXRenderingMode:(GXImageRenderingMode)renderingMode;

- (UIImage *)imageWithGXScalableEdgeInsets:(nullable NSValue *)scalableEdgeInsets useTileRezisingMode:(BOOL)tile;
- (UIImage *)gxResizableImageWithCapInsets:(UIEdgeInsets)capInsets useTileRezisingMode:(BOOL)tile;

- (UIImage *)imageWithGXFlipsForRTL:(BOOL)flipsForRTL;

@end

NS_ASSUME_NONNULL_END

