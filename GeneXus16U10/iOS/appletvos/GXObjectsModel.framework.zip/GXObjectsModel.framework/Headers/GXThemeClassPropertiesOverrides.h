//
//  GXThemeClassPropertiesOverrides.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 16/07/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>
#import <GXObjectsModel/GXThemeClass+PropertiesNames.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXThemeClassPropertiesOverrides <NSObject>

- (nullable id)themeClass:(nullable GXThemeClass *)themeClass overridePropertyValueForName:(NSString *)propertyName;

@end

NS_ASSUME_NONNULL_END
