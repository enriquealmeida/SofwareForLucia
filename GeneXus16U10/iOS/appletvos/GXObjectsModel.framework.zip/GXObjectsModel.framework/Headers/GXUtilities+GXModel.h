//
//  GXUtilities+GXModel.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 31/12/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXFoundation;

@interface GXUtilities (GXModel)

@property(class, nonatomic, assign, readonly) BOOL serverConnectionAvailable;

@end
