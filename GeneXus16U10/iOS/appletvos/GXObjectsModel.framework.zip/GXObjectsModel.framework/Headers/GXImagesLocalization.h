//
//  GXImagesLocalization.h
//  GXFlexibleClient
//
//  Created by Guillermo Pasquero on 11/1/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
@import UIKit;
#import <GXObjectsModel/GXImage.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXImagesLocalization : NSObject <NSCoding>

@property(nullable, nonatomic, strong, readonly) NSString *language;
@property(nullable, nonatomic, strong, readonly) NSString *theme;

- (instancetype)initWithImages:(nullable NSDictionary<NSString *, GXImage *> *)imagesByName
			 resourcesLocation:(nullable NSString *)location
					  language:(nullable NSString *)language
						 theme:(nullable NSString *)theme NS_DESIGNATED_INITIALIZER;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

/*!
 Returns the image, url and gxImage for the given name
 
 @param name Name of the image
 @param image Image to be returned if found embedded
 @param url Image url to be returned if image == NULL or not found embedded (*image == nil)
 @param gxImage GXImage to be returned if found
 @discussion If gxImage != NULL, the returned image (if not nil) hasn't gxImage's properties applied (like renderingMode and scalableEdgeInsets), however, if gxImage == NULL, the returned image has gxImage's properties applied.
 */
- (void)imageOrURLForName:(NSString *)name
					image:(out UIImage * __nullable __autoreleasing * __nullable)image
					  url:(out NSURL * __nullable __autoreleasing * __nullable)url
				  gxImage:(out GXImage * __nullable __autoreleasing * __nullable)gxImage;
- (nullable UIImage *)imageForName:(NSString *)name;
- (nullable NSURL *)urlForImageName:(NSString *)name;
- (nullable NSURL *)urlForImageGuid:(NSString *)guid;

- (nullable GXImage *)gxImageForName:(NSString *)name;
- (nullable GXImage *)gxImageForGuid:(NSString *)guid;

@end

NS_ASSUME_NONNULL_END
