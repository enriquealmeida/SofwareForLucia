//
//  GXActionParameter.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXActionDescriptorProtocol.h>
#import <GXObjectsModel/GXExpressionProtocol.h>
#import <GXObjectsModel/GXNamedElement.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXActionParameter : NSObject <GXActionParameterDescriptor, NSCoding>
@end


@interface GXActionParameter (Factory)

+ (GXActionParameterType)actionParameterTypeFromValueExpression:(nullable NSString *)valueExpression;

+ (nullable __kindof GXActionParameter *)actionParameterValueExpression:(NSString *)valueExpression
														fieldDescriptor:(nullable id<GXEntityDataFieldDescriptor>)descriptor;
+ (nullable __kindof GXActionParameter *)actionParameterValueExpression:(NSString *)valueExpression
														fieldDescriptor:(nullable id<GXEntityDataFieldDescriptor>)descriptor
											  calledTargetParameterName:(nullable NSString *)calledTargetParameterName;

+ (__kindof GXActionParameter *)actionParameterWithFieldDescriptor:(id<GXEntityDataFieldDescriptor>)descriptor;
+ (__kindof GXActionParameter *)actionParameterWithFieldDescriptor:(id<GXEntityDataFieldDescriptor>)descriptor
													fieldSpecifier:(nullable NSString *)fieldSpecifier; // Used only for GXEntityDataFieldTypeVariable
+ (__kindof GXActionParameter *)actionParameterWithFieldDescriptor:(id<GXEntityDataFieldDescriptor>)descriptor
													fieldSpecifier:(nullable NSString *)fieldSpecifier // Used only for GXEntityDataFieldTypeVariable
										 calledTargetParameterName:(nullable NSString *)calledTargetParameterName;

+ (__kindof GXActionParameter<GXActionParameterDescriptorExpression> *)actionParameterWithExpression:(id<GXExpression>)expression;
+ (__kindof GXActionParameter<GXActionParameterDescriptorExpression> *)actionParameterWithExpression:(id<GXExpression>)expression
																		   calledTargetParameterName:(nullable NSString *)calledTargetParameterName;

@end

NS_ASSUME_NONNULL_END
