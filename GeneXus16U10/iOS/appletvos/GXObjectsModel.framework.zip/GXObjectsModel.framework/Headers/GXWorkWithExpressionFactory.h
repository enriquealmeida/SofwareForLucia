//
//  GXWorkWithExpressionFactory.h
//  GXFlexibleClient
//
//  Created by willy on 2/6/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

#import <GXObjectsModel/GXWorkWithExpression.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithExpressionFactory : NSObject

+ (nullable __kindof GXWorkWithExpression *)workWithExpressionFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata
														dataElementsByName:(nullable NSDictionary<NSString *, id<GXEntityDataFieldDescriptor>> *)dataElementsByName
																	 error:(out NSError * __autoreleasing __nullable * __nullable)error;

@end

NS_ASSUME_NONNULL_END
