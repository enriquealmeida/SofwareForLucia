//
//  GXSecurityServiceAuthorizationRequestOptions.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXUserInterfaceContext.h>

NS_ASSUME_NONNULL_BEGIN

/// Security Service authorization request options
@interface GXSecurityServiceAuthorizationRequestOptions : NSObject

@property(nonatomic, assign) BOOL force;
@property(nonatomic, assign) BOOL anonymousLoginAllowed;
@property(nonatomic, assign) BOOL refreshTokenAllowed;
@property(nullable, nonatomic, strong) GXUserInterfaceContext *uiContext;
@property(nullable, nonatomic, strong) NSError *associatedError;

@end

NS_ASSUME_NONNULL_END
