//
//  GXThemeClassAnimation.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 8/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>
@import GXFoundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassAnimation : GXThemeClass

@property(nullable, nonatomic, strong, readonly) NSString *typeIdentifier;
@property(nonatomic, assign, readonly) GXLayoutDimension height;
@property(nonatomic, assign, readonly) GXLayoutDimension width;

@end


@interface GXThemeClassAnimation (GXExtensionProperties)

+ (void)registerExtensionPropertiesNames:(NSArray<NSString *> *)extensionPropertiesNames forTypeIdentifier:(NSString *)typeIdentifier;

@end

NS_ASSUME_NONNULL_END
