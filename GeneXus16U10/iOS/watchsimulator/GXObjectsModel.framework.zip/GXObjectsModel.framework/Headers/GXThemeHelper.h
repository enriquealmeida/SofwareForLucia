//
//  GXThemeHelper.h
//  GXObjectsModel
//
//  Created by Fabian Inthamoussu on 17/11/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXTheme.h>

@interface GXThemeHelper : NSObject

@end
