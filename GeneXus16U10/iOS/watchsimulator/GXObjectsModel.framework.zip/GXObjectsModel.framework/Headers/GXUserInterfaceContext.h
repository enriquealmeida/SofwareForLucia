//
//  GXUserInterfaceContext.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 16/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
#if TARGET_OS_IOS || TARGET_OS_TV
@import UIKit;
#elif TARGET_OS_WATCH
@import WatchKit;
#endif
#import <GXObjectsModel/GXUserInterfaceContextProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXUserInterfaceContext : NSObject

@property(nonatomic, strong, readonly) NSArray<id<GXUserInterfaceContext>> *userInterfaceContextItems;

- (void)addUserInterfaceContext:(nullable id <GXUserInterfaceContext>)uiContext;

#if !TARGET_OS_WATCH
- (void)addUserInterfaceContextWithView:(UIView *)view;
- (void)addUserInterfaceContextWithBarItem:(UIBarItem *)barItem
							viewController:(nullable UIViewController *)controller;
- (void)addUserInterfaceContextWithGestureRecognizer:(UIGestureRecognizer *)gestureRecognizer;
- (void)addUserInterfaceContextWithController:(UIViewController *)controller;
- (void)addUserInterfaceContextWithViewController:(UIViewController *)controller;
#else
- (void)addUserInterfaceContextWithInterfaceObject:(WKInterfaceObject *)interfaceObject;
- (void)addUserInterfaceContextWithController:(WKInterfaceController *)controller;
#endif // !TARGET_OS_WATCH
- (void)addEdittingUserInterfaceContext:(id<GXEditingUserInterfaceContext>)context;

@end

NS_ASSUME_NONNULL_END
