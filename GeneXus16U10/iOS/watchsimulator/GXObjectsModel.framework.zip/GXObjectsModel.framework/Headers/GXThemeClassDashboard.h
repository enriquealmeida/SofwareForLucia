//
//  GXThemeClassDashboard.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 11/05/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClass.h>

@class GXThemeClassList;
@class GXThemeClassTab;

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassDashboard : GXThemeClass

@property(nullable, nonatomic, strong, readonly) GXThemeClassList *dashboardGridClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClassTab *dashboardTabClass;

@end

NS_ASSUME_NONNULL_END
