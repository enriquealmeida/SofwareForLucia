//
//  GXExpressionEvaluatorService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 9/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXActionHandlerProtocol.h>
#import <GXObjectsModel/GXEntityDataProtocol.h>
#import <GXObjectsModel/GXExpressionProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXExpressionEvaluatorService <NSObject>

- (nullable id<GXCancelableOperation>)evaluateExpressionValue:(id<GXExpression>)expression
											   withEntityData:(nullable id<GXEntityData>)entityData
										 actionHandlerContext:(nullable id<GXActionHandlerContext>)context
										  completionWithError:(void(^)(id _Nullable expValue, NSError * _Nullable error))completion;

- (BOOL)tryResolveExpression:(id<GXExpressionWithFieldSpecifierResolver>)expression
			  fieldSpecifier:(out NSString * __nullable * __nonnull)fieldSpecifier
		rootTargetExpression:(out id<GXExpression> __nullable * __nonnull)rootTargetExpression
			  withEntityData:(nullable id<GXEntityData>)entityData
		actionHandlerContext:(nullable id<GXActionHandlerContext>)context;

@optional
- (nullable id)evaluateExpressionValue:(id<GXExpression>)expression
						withEntityData:(nullable id<GXEntityData>)entityData
				  actionHandlerContext:(nullable id<GXActionHandlerContext>)context __attribute__((deprecated));

- (void)evaluateExpressionValue:(id<GXExpression>)expression
				 withEntityData:(nullable id<GXEntityData>)entityData
		   actionHandlerContext:(nullable id<GXActionHandlerContext>)context
					 completion:(void(^)(id _Nullable expValue))completion __attribute__((deprecated));


@end

NS_ASSUME_NONNULL_END
