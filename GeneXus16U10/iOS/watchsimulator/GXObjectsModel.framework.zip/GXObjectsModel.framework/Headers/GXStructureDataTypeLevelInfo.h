//
//  GXStructureDataTypeLevelInfo.h
//  GXFlexibleClient
//
//  Created by willy on 8/9/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXBusinessComponentLevel.h>
#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXSDTDataCommon.h>
#import <GXObjectsModel/GXStructureDataTypeItemInfo.h>

@protocol GXEntityDataSDTFieldInfo;
@class GXStructureDataTypeInfo;

NS_ASSUME_NONNULL_BEGIN

@interface GXStructureDataTypeLevelInfo : GXNamedElement

@property(nonnull, nonatomic, readonly) NSString *name;
@property(nonatomic, readonly) BOOL isCollection;
@property(nullable, nonatomic, readonly) NSString *collectionItemName;
@property(nullable, nonatomic, readonly) id<GXEntityDataSDTFieldInfo> collectionItemSDTFieldInfo;
@property(nullable, nonatomic, readonly) NSString *jsonName;
@property(nullable, nonatomic, readonly) NSDictionary<NSString *, GXStructureDataTypeLevelInfo *> *levelsByName; // Keys are lowercase
@property(nullable, nonatomic, readonly) NSDictionary<NSString *, GXStructureDataTypeItemInfo *> *itemsByName; // Keys are lowercase

@property(null_unspecified, nonatomic, readonly) GXStructureDataTypeInfo *sdtInfo;
@property(nullable, nonatomic, readonly) GXStructureDataTypeLevelInfo *parentLevel;
          
- (nullable GXStructureDataTypeLevelInfo *)levelForName:(NSString *)name; // name is case insensitive
- (nullable GXStructureDataTypeLevelInfo *)levelWithCollectionItemName:(NSString *)colItemName; // compareOptions:0 recursinveIntoNonCollectionLevels:NO
- (nullable GXStructureDataTypeLevelInfo *)levelWithCollectionItemName:(NSString *)colItemName
														compareOptions:(NSStringCompareOptions)options
									 recursinveIntoNonCollectionLevels:(BOOL)recursive;

- (nullable GXStructureDataTypeItemInfo *)itemForName:(NSString *)name; // name is case insensitive
- (nullable GXStructureDataTypeItemInfo *)itemInfoForFieldSpecifier:(NSString *)fieldSpecifier;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;

@end

@interface GXStructureDataTypeBCLevelInfo : GXStructureDataTypeLevelInfo

@property(nonatomic, readonly) GXBusinessComponentLevel *bcLevel;

@end

NS_ASSUME_NONNULL_END
