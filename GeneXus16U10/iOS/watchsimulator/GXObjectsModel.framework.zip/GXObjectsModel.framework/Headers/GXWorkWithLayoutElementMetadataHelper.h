//
//  GXWorkWithLayoutElementMetadataHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 27/03/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXWorkWithLayoutElementAlignmentHelper.h>
#import <GXObjectsModel/GXWorkWithLayoutElementContainerLayoutHelper.h>
#import <GXObjectsModel/GXWorkWithLayoutElementExpandableBoundsHelper.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithLayoutElementMetadataHelper : NSObject

+ (NSError *)defaultModelErrorWithDeveloperDescription:(NSString *)desc;

+ (nullable GXWorkWithLayoutElementAlignmentHelper *)workWithLayoutElementAlignmentHelperFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (BOOL)workWithLayoutElementAutoGrowFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata defaultValue:(BOOL)defaultValue;
+ (BOOL)workWithLayoutElementPullToRefreshFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (BOOL)workWithLayoutElementInverseLoadingFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (BOOL)workWithLayoutElementEnableMultipleSelectionFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (nullable GXWorkWithLayoutElementContainerLayoutHelper *)workWithLayoutElementContainerLayoutHelperFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (nullable GXWorkWithLayoutElementExpandableBoundsHelper *)workWithLayoutElementExpandableBoundsHelperFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata;
+ (nullable GXWorkWithLayoutElementExpandableBoundsHelper *)workWithLayoutElementExpandableBoundsHelperFromMetadata:(nullable NSDictionary<NSString *, id> *)metadata
																						withDefaultExpandableBounds:(GXLayoutExpandableBounds)expandableBounds
																									expandDirection:(GXLayoutExpandDirection)expandDirection
																										expandLimit:(GXLayoutExpandLimit)expandLimit;

@end

NS_ASSUME_NONNULL_END
