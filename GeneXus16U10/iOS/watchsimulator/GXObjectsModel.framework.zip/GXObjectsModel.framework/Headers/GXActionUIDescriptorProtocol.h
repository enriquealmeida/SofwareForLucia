//
//  GXActionUIDescriptorProtocol.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 10/08/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXActionDescriptorProtocol.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_OPTIONS(uint_least8_t, GXActionBarUIPriorityType) {
	GXActionBarUIPriorityLow = 1,
	GXActionBarUIPriorityNormal = 1 << 1,
	GXActionBarUIPriorityHigh = 1 << 2
};
#define GXActionBarUIPriorityType_UNDEFINED ((GXActionBarUIPriorityType)UINT_LEAST8_MAX)

typedef NS_ENUM(uint_least8_t, GXActionBarUIPositionType) {
	GXActionBarUIPositionPriorityBased,
	GXActionBarUIPositionCustom
};
#define GXActionBarUIPositionType_UNDEFINED ((GXActionBarUIPositionType)UINT_LEAST8_MAX)

GXActionBarUIPriorityType GXActionBarUIPriorityFromString(NSString * __nullable priorityStr);

typedef NS_ENUM(uint_least8_t, GXActionUIImagePosition) {
    GXActionUIImagePositionAboveText,
    GXActionUIImagePositionBelowText,
    GXActionUIImagePositionBeforeText,
    GXActionUIImagePositionAfterText,
    GXActionUIImagePositionBehindText,
    GXActionUIImagePositionLeft
};
#define GXActionUIImagePosition_UNDEFINED ((GXActionUIImagePosition)UINT_LEAST8_MAX)

GXActionUIImagePosition GXActionUIImagePositionFromString(NSString * __nullable actionImagePosition, GXActionUIImagePosition defaultValue);

@protocol GXActionUIBaseDescriptor <NSObject>

@property(nullable, nonatomic, strong, readonly) NSString *actionUIThemeClass;
@property(nonatomic, assign, readonly) BOOL actionUIVisible;
@property(nonatomic, assign, readonly) BOOL actionUIEnabled;

@end

@protocol GXActionUIDescriptor <GXActionUIBaseDescriptor>

@property(nullable, nonatomic, strong, readonly) NSString *actionUICaption;
@property(nullable, nonatomic, strong, readonly) NSString *actionUIImage;
@property(nullable, nonatomic, strong, readonly) NSString *actionUIDisabledImage;
@property(nonatomic, assign, readonly) GXActionUIImagePosition actionUIImagePosition;

@optional
@property(nullable, nonatomic, strong, readonly) NSString *actionUICaptionWithoutTranslation;

@end

@protocol GXActionBarUIPositionDescriptor <NSObject>

@property(nonatomic, assign, readonly) GXActionBarUIPositionType actionBarUIPosition;

@end

@protocol GXActionBarUIPositionPriorityBasedDescriptor <GXActionBarUIPositionDescriptor> // actionBarUIPosition == GXActionBarUIPositionPriorityBased

@property(nonatomic, assign, readonly) GXActionBarUIPriorityType actionBarUIPriority;

@end

@protocol GXActionBarUIPositionCustomDescriptor <GXActionBarUIPositionDescriptor> // actionBarUIPosition == GXActionBarUIPositionCustom

@property(nonatomic, assign, readonly) GXHorizontalAlignType actionBarUIHorizontalAlign;
@property(nonatomic, assign, readonly) GXVerticalAlignType actionBarUIVerticalAlign;

@end

@protocol GXActionBarUIDescriptor <NSObject>

@property(nonatomic, strong, readonly) id<GXActionBarUIPositionDescriptor> actionBarUIPositionDescriptor;

#if TARGET_OS_IOS
@optional
@property(nonatomic, assign, readonly) GXActionBarUIPositionType actionBarUIPosition __attribute__((deprecated("Use actionBarUIPositionDescriptor instead")));
@property(nonatomic, assign, readonly) GXActionBarUIPriorityType actionBarUIPriority __attribute__((deprecated("Use actionBarUIPositionDescriptor instead")));
@property(nonatomic, assign, readonly) GXHorizontalAlignType actionBarUIHorizontalAlign __attribute__((deprecated("Use actionBarUIPositionDescriptor instead")));
@property(nonatomic, assign, readonly) GXVerticalAlignType actionBarUIVerticalAlign __attribute__((deprecated("Use actionBarUIPositionDescriptor instead")));
@required
#endif // TARGET_OS_IOS

@end

NS_ASSUME_NONNULL_END
