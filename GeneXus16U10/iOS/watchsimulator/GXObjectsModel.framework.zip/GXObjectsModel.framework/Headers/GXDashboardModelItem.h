//
//  GXDashboardModelItem.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 28/02/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXEventDescriptor.h>
#import <GXObjectsModel/GXMenuProtocol.h>
#import <GXObjectsModel/GXNamedElement.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXDashboardModelItem : GXNamedElement <GXMenuItem, NSCoding>

@property(nonatomic, strong, readonly) GXEventDescriptor *eventDescriptor;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;
- (instancetype)initWithEventDescriptor:(GXEventDescriptor *)eventDescriptor
								  title:(nullable NSString *)title
							  imageName:(nullable NSString *)imageName
					 themeClassFullName:(nullable NSString *)classFullName NS_DESIGNATED_INITIALIZER;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
