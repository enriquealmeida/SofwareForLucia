//
//  GXEntityHelper+GXDomainInfo.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

#import <GXObjectsModel/GXEntityHelper.h>
#import <GXObjectsModel/GXDomainInfo.h>
#import <GXObjectsModel/GXEntityDataFieldInfoProtocol.h>

@interface GXEntityHelper (GXDomainInfo)

+ (GXDomainInfo *)domainInfoFromFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo;

@end
