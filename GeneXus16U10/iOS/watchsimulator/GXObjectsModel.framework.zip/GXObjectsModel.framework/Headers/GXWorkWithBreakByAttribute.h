//
//  GXWorkWithBreakByAttribute.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 27/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXEntityListBreakByProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXWorkWithBreakByField : GXNamedElement <GXEntityListBreakByField>

- (instancetype)init NS_UNAVAILABLE;

@end

@interface GXWorkWithBreakByFieldAttribute : GXWorkWithBreakByField <GXEntityDataFieldAttributeDescriptor>
@end

@interface GXWorkWithBreakByFieldVariable : GXWorkWithBreakByField <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObjectInfo;

- (instancetype)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo NS_DESIGNATED_INITIALIZER;

- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
