//
//  GXApplicationStorageService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXApplicationProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXApplicationStorageService <NSObject>

#if !TARGET_OS_TV
- (NSString *)applicationDocumentsDirectory;
- (nullable NSString *)applicationDocumentsDirectoryForApplication:(id <GXApplication>)application; // createIfNeeded = NO
- (nullable NSString *)applicationDocumentsDirectoryForApplication:(id <GXApplication>)application createIfNeeded:(BOOL)createIfNeeded;

- (NSString *)applicationAppSupportDirectory;
- (nullable NSString *)applicationAppSupportDirectoryForApplication:(id <GXApplication>)application; // createIfNeeded = NO
- (nullable NSString *)applicationAppSupportDirectoryForApplication:(id <GXApplication>)application createIfNeeded:(BOOL)createIfNeeded;
#endif // !TARGET_OS_TV

- (NSString *)applicationCachesDirectory;
- (nullable NSString *)applicationCachesDirectoryForApplication:(id <GXApplication>)application; // createIfNeeded = NO
- (nullable NSString *)applicationCachesDirectoryForApplication:(id <GXApplication>)application createIfNeeded:(BOOL)createIfNeeded;

@end

NS_ASSUME_NONNULL_END
