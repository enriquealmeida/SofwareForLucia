//
//  GXCoreModule_SD_Offline_Database.h
//  GXCoreModule_SD_Offline_Database
//
//  Created by Marcos Crispino on 1/16/20.
//  Copyright © 2020 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_SD_Offline_Database.
FOUNDATION_EXPORT double GXCoreModule_SD_Offline_DatabaseVersionNumber;

//! Project version string for GXCoreModule_SD_Offline_Database.
FOUNDATION_EXPORT const unsigned char GXCoreModule_SD_Offline_DatabaseVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_SD_Offline_Database/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
