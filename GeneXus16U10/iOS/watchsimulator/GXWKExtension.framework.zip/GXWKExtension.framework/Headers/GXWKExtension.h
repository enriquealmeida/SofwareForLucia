//
//  GXWKExtension.h
//  GXWKExtension
//
//  Created by Fabian Inthamoussu on 12/9/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WatchKit/WatchKit.h>
//! Project version number for GXWKExtension.
FOUNDATION_EXPORT double GXWKExtensionVersionNumber;

//! Project version string for GXWKExtension.
FOUNDATION_EXPORT const unsigned char GXWKExtensionVersionString[];

