//
//  GXProcedureHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 25/09/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

#import <GXStandardClasses/GXProcedure.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXProcedureHelperOptionals <NSObject>

@optional
+ (NSArray *)executeOnlineProcedure:(NSString *)procName params:(NSArray *)params;

@end

@interface GXProcedureHelper : NSObject <GXProcedureHelperOptionals>

+ (nullable Class)gxOfflineProcedureClassForProcedureName:(NSString *)procedureName;

+ (NSArray *)executeOfflineProcedure:(Class)gxProcClass withParameters:(nullable NSArray *)gxProcParams;

+ (NSArray *)executeOfflineProcedureInstance:(GXProcedure *)gxProc withParameters:(nullable NSArray *)gxProcParams;

@end

NS_ASSUME_NONNULL_END