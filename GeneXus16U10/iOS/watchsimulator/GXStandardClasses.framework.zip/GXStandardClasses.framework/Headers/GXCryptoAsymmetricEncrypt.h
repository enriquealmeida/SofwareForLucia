//
//  GXCryptoAsymmetricEncrypt.h
//  GXStandardClasses
//
//  Created by Marcos Crispino on 13/3/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXStandardClasses/GXCryptoBaseType.h>
#import <GXStandardClasses/GXCryptoCertificate.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCryptoAsymmetricEncrypt : GXCryptoBaseType

/**
 Enables the specification of the hash algorithms that will be used. SHA256 is used by default.
 */
@property (nonatomic, retain) NSString *algorithm;

/**
 Allows us to specify the certificate that will be used for encrypting or de-encrypting.
 */
@property (nonatomic, retain) GXCryptoCertificate *certificate;

/**
 For a given text, it returns it encrypted using asymmetrical cryptography according to the algorithm and the public key of the certificate specified.
 */
- (NSString *)encrypt:(NSString *)text NS_SWIFT_NAME(encrypt(_:));

/**
 Returns the given text de-encrypted according to the algorithm and the private key of the certificate specified. A requirement is that the certificate must contain the private key.
 */
- (NSString *)decrypt:(NSString *)text NS_SWIFT_NAME(decrypt(_:));

@end

NS_ASSUME_NONNULL_END
