//
//  GXSynchronizationJSONReader.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 25/02/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXStandardClasses;

@class GXSynchronizationJSONReader;

@protocol GXSynchronizationJSONReaderDelegate <NSObject>

@required
- (NSString *)synchronizerVersionForJSONReader:(GXSynchronizationJSONReader *)reader;

- (void)synchronizationJSONReaderDidFinishWithErrorResponse:(NSURLResponse *)respnse receivedData:(NSData *)data;

- (void)synchronizationJSONReaderDidFinishWithError:(NSError *)error;

@optional
- (void)synchronizationJSONReaderDidFinishReceiveingDataFromServer:(GXSynchronizationJSONReader *)reader;

@end


@interface GXSynchronizationJSONReader : NSObject

@property (nonatomic, weak, readonly) id<GXSynchronizationJSONReaderDelegate> delegate;

- (id)initWithDelegate:(id<GXSynchronizationJSONReaderDelegate>)delegate;

- (BOOL)parseJSONFromURL:(NSURL *)url dataToSend:(NSData *)jsonData;

- (void)cancel;

- (BOOL)readBeginArray;

- (BOOL)readEndArray;

- (BOOL)endOfArray;

- (NSArray *)readNextArray;

- (GXStringCollection *)readNextStringCollection;

@end
