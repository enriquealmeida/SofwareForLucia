//
//  GXProgressIndicatorData.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 19/07/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXActivityIndicatorType) {
    GXActivityIndicatorTypeIndeterminated,
    GXActivityIndicatorTypeDeterminated
};

@interface GXProgressIndicatorData : NSObject

@property(nonatomic, assign, readwrite) GXActivityIndicatorType type;
@property(nullable, nonatomic, strong, readwrite) NSString *themeClassName;
@property(nullable, nonatomic, strong, readwrite) NSString *title;
@property(nullable, nonatomic, strong, readwrite) NSString *description;
@property(nonatomic, assign, readwrite) NSInteger maxValue;
@property(nonatomic, assign, readwrite) NSInteger value;
@property(nonatomic, assign, readonly) float normalizedValue;
@property(nonatomic, assign, readwrite) BOOL visible;

@end

NS_ASSUME_NONNULL_END
