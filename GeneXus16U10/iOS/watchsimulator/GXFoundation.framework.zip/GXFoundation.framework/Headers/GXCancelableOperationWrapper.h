//
//  GXCancelableOperationWrapper.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 04/01/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXFoundation/GXCancelableOperationBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCancelableOperationWrapper : GXCancelableOperationBase

- (instancetype)initWithInnerOperation:(id<GXCancelableOperation>)innerOperation NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

/// Assigning a new innerOperation when isCancelled, cancels the new operation
@property(nonatomic) id<GXCancelableOperation> innerOperation;

@end

NS_ASSUME_NONNULL_END
