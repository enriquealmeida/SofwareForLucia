//
//  NSSet+Helpers.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 02/05/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;

@interface NSMutableSet (Helpers)

/// Returns YES if the object was added, NO if it was removed
- (BOOL)addObjectOrRemoveIfContained:(id)object;

/// Returns YES if the object was added, NO if it was already contained
- (BOOL)addObjectIfNotContained:(id)object;

/// Retuns YES if the object was contained (and removed), NO otherwise
- (BOOL)removeObjectIfContained:(id)object;

- (void)removeObjectsInArray:(NSArray *)array;

@end
