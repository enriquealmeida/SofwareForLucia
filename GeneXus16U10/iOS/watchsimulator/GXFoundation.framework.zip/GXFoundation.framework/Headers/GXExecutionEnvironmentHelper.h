//
//  GXExecutionEnvironmentHelper.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 19/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#if !TARGET_OS_WATCH
@import UIKit;
#else
@import WatchKit;
#endif // !TARGET_OS_WATCH
#import <GXFoundation/GXExecutionEnvironment.h>

NS_ASSUME_NONNULL_BEGIN

extern NSString *const GXExecutionEnvironmentDidFinishLaunchingNotification;
extern NSString *const GXExecutionEnvironmentDarkUIStyleChangedNotification;

@interface GXExecutionEnvironmentHelper : NSObject

#pragma mark State

@property(class, assign, readonly) GXApplicationStateType applicationState;
@property(class, assign, readonly, getter=isTransitioningFromBackgroundToForeground) BOOL transitioningFromBackgroundToForeground;

+ (BOOL)activeStateNotificationsSupported;
@property(class, nullable, strong, readonly) NSString *currentContextDidBecomeActiveNotification;
@property(class, nullable, strong, readonly) NSString *currentContextWillResignActiveNotification;

@property(class, nullable, strong, readonly) NSString *currentContextDidReceiveMemoryWarningNotification;
@property(class, nullable, strong, readonly) NSString *currentContextWillTerminateNotification;

#pragma mark Multitasking

@property(class, assign, readonly, getter=isMultitaskingSupported) BOOL multitaskingSupported;
@property(class, assign, readonly) BOOL multitaskingNotificationsSupported;
@property(class, nullable, strong, readonly) NSString *currentContextDidEnterBackgroundNotification;
@property(class, nullable, strong, readonly) NSString *currentContextWillEnterForegroundNotification;

#pragma mark BackgroundTask

@property(class, readonly) BOOL backgroundTaskSupported;
+ (NSTimeInterval)backgroundTimeRemaining;

+ (GXBackgroundTaskIdentifier)backgroundTaskInvalidIdentifier;
+ (GXBackgroundTaskIdentifier)beginBackgroundTaskWithName:(nullable NSString *)taskName expirationHandler:(void(^ __nullable)(void))handler;
+ (void)endBackgroundTask:(GXBackgroundTaskIdentifier)identifier;

#pragma mark Applications Interop

#if TARGET_OS_IOS
+ (BOOL)openURL:(NSURL *)url __attribute__((deprecated("Use openURL:options:completionHandler: instead")));
#endif // TARGET_OS_IOS
+ (void)openURL:(NSURL *)url options:(nullable NSDictionary<NSString *, id> *)options completionHandler:(void (^ __nullable)(BOOL success))completion;
@property(class, nullable, nonatomic, strong, readonly) NSString *openURLOptionUniversalLinksOnlyKey;

+ (BOOL)canOpenURL:(NSURL *)url;

#pragma mark User Interface

#if !TARGET_OS_WATCH
@property(class, nonatomic, readonly) UITraitCollection *currentTraitCollection;
@property(class, nullable, strong, readonly) UIWindow *keyWindow;

+ (void)sendActionToFirstResponder:(SEL)action;
#else
@property(class, nullable, strong, readonly) WKInterfaceController *rootInterfaceController;
#endif // !TARGET_OS_WATCH
@property(class, nonatomic, readonly, getter=isDarkUIStyle) BOOL darkUIStyle;
@property(class, nonatomic, readonly) BOOL darkUIStyleRuntimeChangeSupported;

#if !TARGET_OS_WATCH
@property(class, nonatomic, assign, readonly) UIUserInterfaceLayoutDirection userInterfaceLayoutDirection;
#else
@property(class, nonatomic, assign, readonly) WKInterfaceLayoutDirection userInterfaceLayoutDirection;
#endif // !TARGET_OS_WATCH
@property(class, nonatomic, readonly, getter=isLayoutDirectionLeftToRight) BOOL layoutDirectionLeftToRight;
@property(class, nonatomic, readonly, getter=isLayoutDirectionRightToLeft) BOOL layoutDirectionRightToLeft;


#if TARGET_OS_IOS
@property(class, assign, readonly) CGRect statusBarFrame;
@property(class, assign, readonly) UIInterfaceOrientation interfaceOrientation;
@property(class, assign, readonly) UIInterfaceOrientationMask supportedInterfaceOrientationsForKeyWindow;
#endif

#if !TARGET_OS_WATCH
@property(class, nonatomic, strong, readonly) UIContentSizeCategory preferredContentSizeCategory;
@property(class, nonatomic, assign, readonly) BOOL preferredContentSizeCategoryIsAccessibilityCategory;
#endif // !TARGET_OS_WATCH

#pragma mark UIRemoteControlEvents

+ (void)beginReceivingRemoteControlEvents;
+ (void)endReceivingRemoteControlEvents;

@end

NS_ASSUME_NONNULL_END
