//
//  GXThreadErrorHandler.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 06/02/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXThreadErrorHandler : NSObject

+ (instancetype)errorHandler;

- (void)addErrorWithCode:(NSInteger)code description:(nullable NSString *)desc;

- (void)addError:(NSError *)error;

- (BOOL)hasError;

- (nullable NSArray<NSError *> *)getErrors; // array of NSError objects

- (void)clearErrors;

- (void)removeErrorsWithCode:(NSInteger)code;

@end

NS_ASSUME_NONNULL_END