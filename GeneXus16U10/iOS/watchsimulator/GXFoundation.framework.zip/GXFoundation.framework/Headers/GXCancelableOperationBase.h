//
//  GXCancelableOperationBase.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 04/01/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

#import <GXFoundation/GXCancelableOperationProtocol.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXCancelableOperationBase : NSObject <GXCancelableOperation>

@property(nonatomic, readonly, getter=isCancelled) BOOL cancelled;

- (void)performCancel; // ABSTRACT

@end

NS_ASSUME_NONNULL_END
