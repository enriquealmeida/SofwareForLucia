//
//  GXEntityDataQueryResultProtocol.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 29/10/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import GXObjectsModel;

@protocol GXEntityDataQueryResult <NSObject>

@property(nonatomic, strong, readonly) id resultData; // id<GXEntityData> or NSArray<NSArray<id<GXEntityData>> *> if entityDataSourceIsCollection
@property(nonatomic, strong, readonly) NSError *error;
@property(nonatomic, strong, readonly) NSDate *timeStamp;

- (BOOL)isSuccessful;

@end

@protocol GXEntityDataQuerySingleItemResult <GXEntityDataQueryResult>

@property(nonatomic, strong, readonly) id <GXEntityData> dataItem;

@end

@protocol GXEntityDataQueryCollectionResult <GXEntityDataQueryResult>

@property(assign, readonly)	NSUInteger count;
@property(assign, readonly, getter=isComplete) BOOL complete;
@property(nonatomic, strong, readonly) NSArray<NSArray<id<GXEntityData>> *> *dataItems; // @[section[row]]
@property(nonatomic, strong, readonly) NSArray<NSString *> *alphaIndexTitles;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, NSValue *> *alphaIndexRangesByTitle;

@end
