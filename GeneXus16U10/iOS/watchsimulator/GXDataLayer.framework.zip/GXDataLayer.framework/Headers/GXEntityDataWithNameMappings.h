//
//  GXEntityDataWithNameMappings.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 09/05/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import GXObjectsModel;

@interface GXEntityDataWithNameMappings : NSObject <GXEntityData>

@property(nonatomic, strong, readonly) NSDictionary *fieldNamesMapping;
@property(nonatomic, strong, readonly) id <GXEntityData> innerEntityData;

+ (id <GXEntityData>)entityDataWithFieldNamesMappings:(NSDictionary *)fieldNamesMapping
										   entityData:(id <GXEntityData>)entityData
											 allowNil:(BOOL)allowNil;

// Same as allowNil:YES
+ (id <GXEntityData>)entityDataWithFieldNamesMappings:(NSDictionary *)fieldNamesMapping
										   entityData:(id <GXEntityData>)entityData;

@end


@interface GXEntityDataWithNameMappingsOverrideValues : GXEntityDataWithNameMappings <GXEntityDataWithOverrideValues>
@end


@interface GXMutableEntityDataWithNameMappings : GXEntityDataWithNameMappings <GXMutableEntityData>
@end


@interface GXMutableEntityDataWithNameMappingsOverrideValues : GXEntityDataWithNameMappingsOverrideValues <GXMutableEntityData>
@end


@interface GXBusinessComponentLevelEntityDataWithNameMappings : GXMutableEntityDataWithNameMappings <GXBusinessComponentLevelEntityData>
@end


@interface GXBusinessComponentLevelEntityDataWithNameMappingsOverrideValues : GXMutableEntityDataWithNameMappingsOverrideValues <GXBusinessComponentLevelEntityData>
@end
