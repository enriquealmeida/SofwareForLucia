//
//  GXDataLayerServices.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 4/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXDataLayer/GXObjectUploaderService.h>
#import <GXDataLayer/GXSynchronizationBlobDownloadService.h>
#import <GXDataLayer/GXSynchronizationReceiveService.h>
#import <GXDataLayer/GXSynchronizationSendService.h>

@interface GXDataLayerServices : NSObject

+ (nullable id <GXObjectUploaderService>)objectUploaderService;
+ (nullable id <GXSynchronizationReceiveService>)synchronizationReceiveService;
+ (nullable id <GXSynchronizationSendService>)synchronizationSendService;
+ (nullable id <GXSynchronizationBlobDownloadService>)synchronizationBlobDownloadService;

@end
