//
//  GXCoreUI.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 10/2/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WatchKit/WatchKit.h>
//! Project version number for GXCoreUI.
FOUNDATION_EXPORT double GXCoreUIVersionNumber;

//! Project version string for GXCoreUI.
FOUNDATION_EXPORT const unsigned char GXCoreUIVersionString[];

#import <GXCoreUI/GXActionControllerDelegateProtocol.h>
#import <GXCoreUI/GXActionExObjEventsHelper+GXControl.h>
#import <GXCoreUI/GXActionHandler+GXControlRuntimePropertiesProxy.h>
#import <GXCoreUI/GXActionHandler+GXMenuActionHandlerProtocol.h>
#import <GXCoreUI/GXActionHandlerUIContext.h>
#import <GXCoreUI/GXActionHandlerUISender.h>
#import <GXCoreUI/GXActionsManager+GXActionHandlerUIDelegate.h>
#import <GXCoreUI/GXActionUIHandler.h>
#import <GXCoreUI/GXCallerDelegate.h>
#import <GXCoreUI/GXCallOptions+GXRuntime.h>
#import <GXCoreUI/GXControl.h>
#import <GXCoreUI/GXControlBase.h>
#import <GXCoreUI/GXControlBase+GXControlWithPromptRuleHelpers.h>
#import <GXCoreUI/GXControlBase+GXThemeClassPropertiesOverrides.h>
#import <GXCoreUI/GXControlBasePropertiesUserInterfaceContextProtocol.h>
#import <GXCoreUI/GXControlComponentProtocol.h>
#import <GXCoreUI/GXControlContainer.h>
#import <GXCoreUI/GXControlContainerBase.h>
#import <GXCoreUI/GXControlContainerContext.h>
#import <GXCoreUI/GXControlContainerLoadOptions.h>
#import <GXCoreUI/GXControlDynamic.h>
#import <GXCoreUI/GXControlEditableWithLabelBase.h>
#import <GXCoreUI/GXControlEditableWithLabelSingleEditorViewBase.h>
#import <GXCoreUI/GXControlFactory.h>
#import <GXCoreUI/GXControlGridBase.h>
#import <GXCoreUI/GXControlGridBase+GXAsyncReload.h>
#import <GXCoreUI/GXControlGridBase+GXControlGridItem.h>
#import <GXCoreUI/GXControlGridBase+GXLoadedInfo.h>
#import <GXCoreUI/GXControlGridBase+InverseLoadingSupport.h>
#import <GXCoreUI/GXControlGridBaseLoadedInfo.h>
#import <GXCoreUI/GXControlGridBaseLoadedInfo+Subclasses.h>
#import <GXCoreUI/GXControlGridBaseWithSelection.h>
#import <GXCoreUI/GXControlGridItem.h>
#import <GXCoreUI/GXControlHelpers.h>
#import <GXCoreUI/GXControlImage.h>
#import <GXCoreUI/GXControlInterfaceObjectsProvider.h>
#import <GXCoreUI/GXControllerProtocol.h>
#import <GXCoreUI/GXControlMultilineSelectionGridBase.h>
#import <GXCoreUI/GXControlTable.h>
#import <GXCoreUI/GXControlTableGridItem.h>
#import <GXCoreUI/GXControlWithActionSelectors.h>
#import <GXCoreUI/GXControlWithData.h>
#import <GXCoreUI/GXControlWithDataEditable.h>
#import <GXCoreUI/GXControlWithEvents.h>
#import <GXCoreUI/GXControlWithLabelBase.h>
#import <GXCoreUI/GXControlWithLabelSingleEditorViewBase.h>
#import <GXCoreUI/GXControlWithLabelSingleEditorViewProtocol.h>
#import <GXCoreUI/GXControlWithPromptRule.h>
#import <GXCoreUI/GXEntityActionHandler.h>
#import <GXCoreUI/GXEntityActionHandlerProtocol.h>
#import <GXCoreUI/GXEntityControllerProtocol.h>
#import <GXCoreUI/GXEntityHelper+GXCoreUI_BusinessComponentRelation.h>
#import <GXCoreUI/GXEntityModelHelper+GXCoreUI.h>
#import <GXCoreUI/GXEntityModelProtocol.h>
#import <GXCoreUI/GXEOProgressIndicator.h>
#import <GXCoreUI/GXLayoutControlUserInterfaceContextProtocol.h>
#import <GXCoreUI/GXLayoutHelper.h>
#import <GXCoreUI/GXMenuActionHandlerProtocol.h>
#import <GXCoreUI/GXMenuControllerProtocol.h>
#import <GXCoreUI/GXMenuRuntimeHelper+GXInternal.h>
#import <GXCoreUI/GXRootControllerHelper.h>
#import <GXCoreUI/GXRootControllerProtocol.h>
#import <GXCoreUI/GXThemeClassPropertiesOverridesWithDictionary.h>
#import <GXCoreUI/GXThemeHelper+GXControlTextView.h>
#import <GXCoreUI/GXUserInterfaceContext+GXControl.h>
#import <GXCoreUI/GXUserInterfaceContextFactory+GXControl.h>
#import <GXCoreUI/GXUserInterfaceContextHelper+GXControl.h>

#import <GXCoreUI/UIView+WebCacheOperation.h> // NSObject+WebCacheOperation
#import <GXCoreUI/UIViewController+GXCallOptions.h> // WKInterfaceController+GXCallOptions
#import <GXCoreUI/WKInterfaceController+GXPresentationInfo.h>
#import <GXCoreUI/WKInterfaceController+GXPropertiesObject.h>
#import <GXCoreUI/WKInterfaceImage+GXImageWebCache.h>
#import <GXCoreUI/WKInterfaceImage+WebCache.h>
