//
//  GXThemeHelper+GXControlTextView.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXCoreUI/GXControlTextViewProtocol.h>
#import <GXCoreUI/GXControl.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeHelper (GXControlTextView)

/**
 * Apply text or attributedText with theme class and format
 */
+ (void)setText:(nullable NSString *)text
 withThemeClass:(nullable id<GXThemeClassWithFont>)themeClass
	 textFormat:(GXLayoutControlTextFormat)textFormat
		 toView:(id<GXControlTextView>)view;

#if !TARGET_OS_WATCH
// Applies gxTextColor from the given themeClass or fallbackColor to the given view
+ (void)setTextColorWithThemeClass:(nullable GXThemeClass *)themeClass
					highlightStyle:(GXHighlightStyleType)highlightStyle
					 fallbackColor:(UIColor * _Nullable (^ _Nullable)(void))fallbackColorBlock
					  onlyIfNonNil:(BOOL)onlyIfNonNil
							toView:(id<GXControlTextView>)view;

+ (void)setTextColorWithControlDefaultFallbackColor:(id<GXControl>)control
									   onlyIfNonNil:(BOOL)onlyIfNonNil
											 toView:(id<GXControlTextView>)view;
#endif // !TARGET_OS_WATCH

@end

NS_ASSUME_NONNULL_END
