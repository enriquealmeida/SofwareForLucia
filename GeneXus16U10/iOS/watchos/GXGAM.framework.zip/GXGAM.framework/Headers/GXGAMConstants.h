//
//  GXGAMConstants.h
//  GXGAM
//
//  Created by Marcos Crispino on 7/16/19.
//  Copyright © 2019 GeneXus. All rights reserved.
//

@import Foundation;
@import GXObjectsModel;

#pragma mark - GAM Module names

#define kGXGAM_Module_Name @"GeneXusSecurity"

#define kGXGAM_GAMUserEO_Name @"GAMUser"
#define kGXGAM_GAMApplicationEO_Name @"GAMApplication"

#define kGXGAM_Module_GAMUserEO_FullName        kGXGAM_Module_Name kGXModule_Separator kGXGAM_GAMUserEO_Name
#define kGXGAM_Module_GAMApplicationEO_FullName kGXGAM_Module_Name kGXModule_Separator kGXGAM_GAMApplicationEO_Name
