//
//  GXCoreModule_SD_CardScanner.h
//  GXCoreModule_SD_CardScanner
//
//  Created by José Echagüe on 10/30/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_SD_CardScanner.
FOUNDATION_EXPORT double GXCoreModule_SD_CardScannerVersionNumber;

//! Project version string for GXCoreModule_SD_CardScanner.
FOUNDATION_EXPORT const unsigned char GXCoreModule_SD_CardScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_SD_CardScanner/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#if TARGET_OS_IOS
#import "CardIO.h"
#endif //TARGET_OS_IOS
