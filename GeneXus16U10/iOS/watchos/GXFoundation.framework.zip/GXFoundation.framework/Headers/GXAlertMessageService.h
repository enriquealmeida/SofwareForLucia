//
//  GXAlertMessageService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 21/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@protocol GXAlertMessageService <NSObject>

- (void)showMessage:(NSString *)message;
- (void)showMessages:(NSArray<NSString *> *)messages;

- (void)showMessage:(NSString *)message completion:(nullable void(^)(void))completion dismissedHandler:(nullable void(^)(void))dismissedHandler;
- (void)showMessages:(NSArray<NSString *> *)messages completion:(nullable void(^)(void))completion dismissedHandler:(nullable void(^)(void))dismissedHandler;

- (void)showAlertWithTitle:(nullable NSString *)alertTitle message:(nullable NSString *)alertMsg;
- (void)showAlertWithTitle:(nullable NSString *)alertTitle
				   message:(nullable NSString *)alertMsg
				completion:(nullable void(^)(void))completion
		  dismissedHandler:(nullable void(^)(void))dismissedHandler;

- (void)showAlertForError:(nullable NSError *)error;
- (void)showAlertForError:(nullable NSError *)error
			   completion:(nullable void(^)(void))completion
		 dismissedHandler:(nullable void(^)(void))dismissedHandler;

@end

NS_ASSUME_NONNULL_END