//
//  UIColor+Helpers.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 11/10/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import UIKit;

NS_ASSUME_NONNULL_BEGIN

@interface UIColor (Helpers)

+ (nullable UIColor *)colorFromValue:(id)value;

/// Returns the same value as GeneXus RGB function
@property(nonatomic, readonly) NSUInteger gxRGBColor;

- (CGFloat)gxColorAlpha;
- (BOOL)isGxColorTransparent;

- (CGFloat)gxColorPerceivedBrightness;
- (BOOL)isColorDark;
- (BOOL)isColorBright;

@end

NS_ASSUME_NONNULL_END
