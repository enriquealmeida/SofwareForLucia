//
//  NSArray+Helpers.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 31/10/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;

@interface NSArray<__covariant ObjectType> (Helpers)

/**
 * Applies the selector to each element of the array and returns a dictionary with the
 * results as keys and the elements of the array as values
 */
- (NSDictionary<id, ObjectType> *)dictionaryWithSelectorForKeys:(SEL)keySelector;

/**
 * Applies the block to each element of the array and returns a dictionary with the
 * results as keys and the elements of the array as values
 */
- (NSDictionary<id, ObjectType> *)dictionaryWithBlockForKeys:(id (^)(ObjectType element))block;

/**
 * Applies the block to each element and returns an array with the results
 */
- (NSArray *)map:(id (^)(ObjectType element))block;

/**
 * Applies the seletor to each element and returns an array with the results
 */
- (NSArray *)mapWithSelector:(SEL)selector;

/**
 * Returns the first element of the array that passes the test given by the block
 */
- (ObjectType)findFirst:(BOOL (^)(ObjectType element))block;

/**
 * Returns the last element of the array that passes the test given by the block
 */
- (ObjectType)findLast:(BOOL (^)(ObjectType element))block;

/**
 * Returns a new array containing only the objects passing the test given by the block
 */
- (NSArray<ObjectType> *)filter:(BOOL (^)(ObjectType element))block;

/**
 * Converts an array of arrays into a flattened array (one-level deep)
 */
- (NSArray *)flatten;

/**
 * Randomly shuffles the elements of the array
 */
- (NSArray<ObjectType> *)shuffledArray;

/**
 * Looks for the given object and returns an array without it
 */
- (NSArray<ObjectType> *)arrayByRemovingObject:(ObjectType)element;

/**
 * Looks for the given object using reference comparison and returns an array without it
 */
- (NSArray<ObjectType> *)arrayByRemovingObjectIdenticalTo:(ObjectType)element;

@end

@interface NSMutableArray<ObjectType> (Helpers)

- (void)addObjectsFromSet:(NSSet<ObjectType> *)set;

- (void)filterUsingBlock:(BOOL (^)(ObjectType element))block;

/**
 * Randomly in-place shuffles the elements of the mutable array
 */
- (void)shuffle;

@end
