//
//  GXUtilities+GXFatalErrorHandling.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 16/01/2020.
//  Copyright © 2020 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXFoundation/GXUtilities.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXUtilities (GXFatalErrorHandling)

+ (void)installUncaughtExceptionsHandler;

#pragma mark - Try Recover Fatal Error

/// Same as [self tryRecoverFatalError:developerDescription withExceptionName:nil recoveryBlock:^BOOL{ return YES; }]
+ (void)tryRecoverFatalError:(NSString *)developerDescription;

/// Same as [self tryRecoverFatalError:developerDescription withExceptionName:exceptionName recoveryBlock:^BOOL{ return YES; }]
+ (void)tryRecoverFatalError:(NSString *)developerDescription withExceptionName:(nullable NSExceptionName)exceptionName;

/// Same as [self tryRecoverFatalError:developerDescription withExceptionName:nil recoveryBlock:recoveryBlock]
+ (void)tryRecoverFatalError:(NSString *)developerDescription withRecoveryBlock:(NS_NOESCAPE BOOL(^)(void))recoveryBlock;

/*!
 Handles fatal error and tries to recover using the given recoveryBlock if [self showDeveloperInfo] == true
 
 @param developerDescription developer description to be used for the error / exception
 @param exceptionName exception name to be used if could not recover. NSInternalInconsistencyException is used if nil.
 @param recoveryBlock recovery block to be used if [self showDeveloperInfo] == true
 @discussion Tries to recover from a fatal error. If could no recover ([self showDeveloperInfo] == false or recoveryBlock returned false), an exception is rised with the given exceptionName and developerDescription, otherwise (could recover) an alert is shown to the developer.
 */
+ (void)tryRecoverFatalError:(NSString *)developerDescription
		   withExceptionName:(nullable NSExceptionName)exceptionName
			   recoveryBlock:(NS_NOESCAPE BOOL(^)(void))recoveryBlock;

#pragma mark - Try Handle Fatal Error

/// Same as [self tryHandleFatalError:developerDescription withExceptionName:nil recoveryBlock:^BOOL{ return YES; }]
+ (NSError *)tryHandleFatalError:(NSString *)developerDescription;

/// Same as [self tryHandleFatalError:developerDescription withExceptionName:exceptionName recoveryBlock:^BOOL{ return YES; }]
+ (NSError *)tryHandleFatalError:(NSString *)developerDescription withExceptionName:(nullable NSExceptionName)exceptionName;

/// Same as [self tryHandleFatalError:developerDescription withExceptionName:nil recoveryBlock:recoveryBlock]
+ (NSError *)tryHandleFatalError:(NSString *)developerDescription withRecoveryBlock:(NS_NOESCAPE BOOL(^)(void))recoveryBlock;

/*!
 Tries to recover from fatal error using the given recoveryBlock if [self showDeveloperInfo] == true
 
 @param developerDescription developer description to be used for the error / exception
 @param exceptionName exception name to be used if could not recover. NSInternalInconsistencyException is used if nil.
 @param recoveryBlock recovery block to be used if [self showDeveloperInfo] == true
 @result Returns an error with the given developerDescription if was able to recover
 @discussion Tries to recover from a fatal error. If could no recover ([self showDeveloperInfo] == false or recoveryBlock returned false), an exception is rised with the given exceptionName and developerDescription, otherwise (could recover) returns an error with the given developerDescription
 */
+ (NSError *)tryHandleFatalError:(NSString *)developerDescription
			   withExceptionName:(nullable NSExceptionName)exceptionName
				   recoveryBlock:(NS_NOESCAPE BOOL(^)(void))recoveryBlock;

@end

NS_ASSUME_NONNULL_END
