//
//  GXEONetworkAPI.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 5/9/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import GXFoundation;
@import GXStandardClasses;

@interface GXEONetworkAPI : GXExternalObjectBase

+ (NSString *)applicationServerURL;

+ (void)setApplicationServerURL:(NSString *)urlString NS_SWIFT_NAME(setApplicationServerURL(_:));

+ (void)isServerAvailableWithCompletionBlock:(void(^)(BOOL serverAvailable))block; // Same as calling [self isServerAvailable:[self applicationServerURL] completionBlock:block]
+ (BOOL)isServerAvailable; // Synchronic, must not be called on main thread. Same as calling [self isServerAvailable:[self applicationServerURL]]

+ (void)isServerAvailable:(NSString *)urlString completionBlock:(void(^)(BOOL serverAvailable))block;
+ (BOOL)isServerAvailable:(NSString *)urlString; // Synchronic, must not be called on main thread

+ (void)connectionTypeWithCompletionBlock:(void(^)(GXNetworkStatusType connectionType))block; // Same as calling [self connectiontype:[self applicationServerURL] completionBlock:block]
+ (GXNetworkStatusType)connectionType; // Synchronic, must not be called on main thread. Same as calling [self connectiontype:[self applicationServerURL]]

+ (void)connectionType:(NSString *)urlString completionBlock:(void(^)(GXNetworkStatusType connectionType))block;
+ (GXNetworkStatusType)connectionType:(NSString *)urlString; // Synchronic, must not be called on main thread


+ (void)isTrafficBasedCostWithCompletionBlock:(void(^)(BOOL trafficBasedCost))block; // Same as calling [self isTrafficBasedCost:[self applicationServerURL] completionBlock:block]
+ (BOOL)isTrafficBasedCost; // Synchronic, must not be called on main thread. Same as calling [self isTrafficBasedCost:[self applicationServerURL]]

+ (void)isTrafficBasedCost:(NSString *)urlString completionBlock:(void(^)(BOOL trafficBasedCost))block;
+ (BOOL)isTrafficBasedCost:(NSString *)urlString; // Synchronic, must not be called on main thread

@end
