//
//  GXOfflineHelper.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 4/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXOfflineHelper : NSObject

+ (BOOL)isSwiftGenerator;

+ (nullable Class)classFromString:(NSString *)name;

+ (nullable SEL)selectorFromMethodName:(NSString *)name parametersCount:(NSUInteger)parCount;

@end

NS_ASSUME_NONNULL_END
