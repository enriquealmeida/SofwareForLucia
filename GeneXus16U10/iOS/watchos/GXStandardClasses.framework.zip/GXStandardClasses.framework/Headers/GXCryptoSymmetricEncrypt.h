//
//  GXCryptoSymmetricEncrypt.h
//  GXStandardClasses
//
//  Created by Marcos Crispino on 13/3/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXStandardClasses/GXCryptoBaseType.h>

NS_ASSUME_NONNULL_BEGIN

#define kGXCryptoAlgorithmEncrypt_Rijndael @"Rijndael"
#define kGXCryptoAlgorithmEncrypt_DES @"DES"
#define kGXCryptoAlgorithmEncrypt_TripleDES @"TripleDES"

@interface GXCryptoSymmetricEncrypt : GXCryptoBaseType

/**
 Specifies the encryption algorithm.
 Valid values are: kGXCryptoAlgorithmEncrypt_Rijndael, kGXCryptoAlgorithmEncrypt_DES, kGXCryptoAlgorithmEncrypt_TripleDES
 */
@property (nonatomic, retain) NSString *algorithm;

/**
 Encryption key, generated automatically upon creating the instance. (Required when decrypting)
 */
@property (nonatomic, retain) NSString *key;

/**
 Encryption initialization vector, generated automatically upon creating the instance. (Required when decrypting)
 */
@property (nonatomic, retain) NSString *iv;

@property (nonatomic, assign) NSInteger keySize;

@property (nonatomic, assign) NSInteger blockSize;

@property (nonatomic, assign) NSInteger keySizeInBits;

@property (nonatomic, assign) NSInteger blockSizeInBits;

/**
 For a given text, it returns an encrypted text using symmetric cryptography according to the algorithm, the key and the initialization vector specified.
 */
- (NSString *)encrypt:(NSString *)text NS_SWIFT_NAME(encrypt(_:));

/**
 Returns the given text, de-encrypted according to the algorithm, the key and the initialization vector -IV (*) specified.
 */
- (NSString *)decrypt:(NSString *)text NS_SWIFT_NAME(decrypt(_:));

@end

NS_ASSUME_NONNULL_END
