//
//  GXActionExObjAudioRecorderHandler.h
//  GXCoreBL
//
//  Created by Marcos Crispino on 23/12/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
@import GXCoreBL;

@interface GXActionExObjAudioRecorderHandler : GXActionExternalObjectHandler

@end
