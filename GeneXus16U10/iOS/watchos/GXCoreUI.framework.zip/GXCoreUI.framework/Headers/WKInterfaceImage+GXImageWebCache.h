//
//  WKInterfaceImage+GXImageWebCache.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 20/2/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/WKInterfaceImage+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

typedef UIImage * _Nonnull (^GXImageWebCacheTransformImage)(UIImage *image, GXImage * _Nullable gxImage, BOOL isEmbededImage);
typedef UIImage * _Nullable (^GXImageWebCachePlaceholderImageProvider)(NSString * __autoreleasing _Nullable * _Nullable placeholderImageName,
NSURL * __autoreleasing _Nullable * _Nullable placeholderImageURL,
GXImage *  __autoreleasing _Nullable * _Nullable placeholderGxImage);

@interface WKInterfaceImage (GXImageWebCache)

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithBackgroundMode:(GXBackgroundImageMode)bgMode
																		  scaleType:(GXImageScaleType)scaleType
																	  renderingMode:(GXImageRenderingMode)renderingMode;

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithBackgroundMode:(GXBackgroundImageMode)bgMode;
- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithScaleType:(GXImageScaleType)scaleType;
- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithRenderingMode:(GXImageRenderingMode)renderingMode;

- (nullable GXImageWebCacheTransformImage)gxDefaultImageTransformWithThemeClass:(nullable GXThemeClass *)themeClass;

+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithImage:(nullable UIImage *)image;
+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithImageName:(nullable NSString *)imageName;
+ (nullable GXImageWebCachePlaceholderImageProvider)gxPlaceholderImageProviderWithThemeClass:(nullable GXThemeClass *)themeClass;

#pragma mark - Image with name

- (void)gxSetImageNamed:(nullable NSString *)imageName;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
		 transformImage:(nullable GXImageWebCacheTransformImage)transformImage;

- (void)gxSetImageNamed:(nullable NSString *)imageName
	   placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
		 transformImage:(nullable GXImageWebCacheTransformImage)transformImage
				options:(GXWebImageOptions)options
			   progress:(nullable GXWebImageDownloaderProgressBlock)progressBlock
			  completed:(nullable GXWebImageCompletionBlock)completedBlock;

- (void)gxSetImageNamed:(nullable NSString *)imageName themeClass:(nullable GXThemeClass *)themeClass;

#pragma mark - Placeholder

- (void)gxSetPlaceHolderImageAsFinalImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider;
- (void)gxSetPlaceHolderImageAsFinalImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
								completed:(nullable GXWebImageCompletionBlock)completedBlock;

@end




@interface WKInterfaceImage (GXEntityDataImageWebCache)

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue
						  placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
							transformImage:(nullable GXImageWebCacheTransformImage)transformImage;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue
						  placeholderImage:(nullable GXImageWebCachePlaceholderImageProvider)placeholderImageProvider
							transformImage:(nullable GXImageWebCacheTransformImage)transformImage
								   options:(GXWebImageOptions)options
								  progress:(nullable GXWebImageDownloaderProgressBlock)progressBlock
								 completed:(nullable GXWebImageCompletionBlock)completedBlock;

- (void)gxSetImageFromEntityDataFieldValue:(nullable id)entityDataFieldValue themeClass:(nullable GXThemeClass *)themeClass;

@end

NS_ASSUME_NONNULL_END
