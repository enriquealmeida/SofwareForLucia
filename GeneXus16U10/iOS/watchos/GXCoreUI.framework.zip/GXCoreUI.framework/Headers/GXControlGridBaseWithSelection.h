//
//  GXControlGridBaseWithSelection.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 19/07/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

#import <GXCoreUI/GXControlGridBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXControlGridBaseWithSelection : GXControlGridBase

- (void)clearEntityDataSelectionModifiedIndexPaths;
- (void)clearFilteredEntityDataSelectionModifiedIndexPaths;
#if TARGET_OS_IOS
- (void)clearFilteredEntityDataSelectionModifiedIndexes __attribute__((deprecated("Use clearFilteredEntityDataSelectionModifiedIndexPaths instead")));
#endif // TARGET_OS_IOS

- (nullable NSArray<NSIndexPath *> *)selectedEntitiesIndexPaths;
- (nullable NSArray<NSIndexPath *> *)selectedFilteredEntitiesIndexPaths;
#if TARGET_OS_IOS
- (nullable NSIndexSet *)selectedFilteredEntitiesIndexes __attribute__((deprecated("Use selectedFilteredEntitiesIndexPaths instead")));
#endif // TARGET_OS_IOS

- (nullable NSArray<id<GXEntityData>> *)selectedEntitiesData;
- (nullable NSArray<id<GXEntityData>> *)selectedFilteredEntitiesData;


// Helper methods

//! Same as layoutGridItemNameForEntityData:atIndex:section: but also loads selected if not NULL
- (nullable NSString *)layoutGridItemNameForEntityData:(id<GXEntityData>)entityData atIndex:(NSUInteger)index section:(NSUInteger)section selected:(BOOL * _Nullable)selected; // filtered:NO
//! Same as layoutGridItemNameForEntityData:atIndex:section:filtered: but also loads selected if not NULL
- (nullable NSString *)layoutGridItemNameForEntityData:(id<GXEntityData>)entityData atIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered selected:(BOOL * _Nullable)selected;
#if TARGET_OS_IOS
//! Same as layoutGridItemNameForFilteredEntityData:atIndex: but also loads selected if not NULL
- (nullable NSString *)layoutGridItemNameForFilteredEntityData:(id<GXEntityData>)entityData atIndex:(NSUInteger)index selected:(BOOL * _Nullable)selected __attribute__((deprecated("Use layoutGridItemNameForEntityData:atIndex:section:filtered:selected: instead")));
#endif // TARGET_OS_IOS


- (void)fireSelectionChangedEventWithIndexPath:(NSIndexPath *)pIndexPath
									completion:(void (^ _Nullable)(void))block;

/*!
 Current resolved list selection style
 
 @result Current resolved list selection style, never equals GXListSelectionTypeDefault
 */
@property(nonatomic, assign, readonly) GXListSelectionType validResolvedSelectionType;

//! Invalidates validResolvedSelectionType, it will be reloaded on next call
- (void)invalidateValidResolvedSelectionType;



/*!
 Checks if the grid item is selected
 
 @param index The grid item index in section to check selection
 @param section The grid section index
 @result YES if the entity data at given index path is selected, NO otherwise
 */
- (BOOL)isEntityDataSelectedAtIndex:(NSUInteger)index section:(NSUInteger)section; // filtered:NO
/*!
 Checks if the grid item is selected
 
 @param index The grid item index in section to check selection
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @result YES if the entity data at given index path is selected, NO otherwise
 */
- (BOOL)isEntityDataSelectedAtIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Checks if the filtered grid item is selected
 
 @param index The filtered grid item index to check selection
 @result YES if the filtered entity data at given index is selected, NO otherwise
 */
- (BOOL)isFilteredEntityDataAtIndexSelected:(NSUInteger)index __attribute__((deprecated("Use isEntityDataSelectedAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

/*!
 Selects/Deselects entity data at given index path
 
 @param index The grid item index in section to select/deselect
 @param section The grid section index
 @result YES if the entity data at given index path is selected, NO otherwise
 */
- (BOOL)selectEntityDataAtIndex:(NSUInteger)index section:(NSUInteger)section; // filtered:NO
/*!
 Selects/Deselects entity data at given index path
 
 @param index The grid item index in section to select/deselect
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @result YES if the entity data at given index path is selected, NO otherwise
 */
- (BOOL)selectEntityDataAtIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Selects/Deselects filtered entity data at given index
 
 @param index The filtered grid item index to select/deselect
 @result YES if the filtered entity data at given index is selected, NO otherwise
 */
- (BOOL)selectFilteredEntityDataAtIndex:(NSUInteger)index __attribute__((deprecated("Use selectEntityDataAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

/*!
 Sets the selection for the entity data at given index path
 
 @param index The grid item index in section to apply selection
 @param section The grid section index
 @param selected The new value for the selection
 @result YES if the selection changed, NO otherwise
 */
- (BOOL)setEntityDataAtIndex:(NSUInteger)index section:(NSUInteger)section selected:(BOOL)selected; // filtered:NO
/*!
 Sets the selection for the entity data at given index path
 
 @param index The grid item index in section to apply selection
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @param selected The new value for the selection
 @result YES if the selection changed, NO otherwise
 */
- (BOOL)setEntityDataAtIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered selected:(BOOL)selected;
#if TARGET_OS_IOS
/*!
 Sets the selection for the filtered entity data at given index
 
 @param index The filtered grid item section to apply selection
 @param selected The new value for the selection
 @result YES if the selection changed, NO otherwise
 */
- (BOOL)setFilteredEntityDataAtIndex:(NSUInteger)index selected:(BOOL)selected __attribute__((deprecated("Use setEntityDataAtIndex:section:filtered:selected: instead")));
#endif // TARGET_OS_IOS

/*!
 Checks if the default selection can be executed for the given index and section
 
 @param index The grid item index in section to evaluate
 @param section The grid section index
 @result YES if executeDefaultSelectionForEntityAtIndex:section: can be executed, NO otherwise
 */
- (BOOL)canExecuteDefaultSelectionForEntityAtIndex:(NSUInteger)index section:(NSUInteger)section; // filtered:NO
/*!
 Checks if the default selection can be executed for the given index and section
 
 @param index The grid item index in section to evaluate
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @result YES if executeDefaultSelectionForEntityAtIndex:section: can be executed, NO otherwise
 */
- (BOOL)canExecuteDefaultSelectionForEntityAtIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Checks if the default selection can be executed for the given filtered index
 
 @param index The filtered grid item index to evaluate
 @result YES if executeDefaultSelectionForFilteredEntityAtIndex: can be executed, NO otherwise
 */
- (BOOL)canExecuteDefaultSelectionForFilteredEntityAtIndex:(NSUInteger)index __attribute__((deprecated("Use canExecuteDefaultSelectionForEntityAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

/*!
 Executes the default selection/deselection for the given index and section
 
 @param index The grid item index in section to execute default selection
 @param section The grid section index
 @result A set of NSIndexPath for the rows which selection changed
 */
- (nullable NSSet<NSIndexPath *> *)executeDefaultSelectionForEntityAtIndex:(NSUInteger)index section:(NSUInteger)section; // filtered:NO
/*!
 Executes the default selection/deselection for the given index and section
 
 @param index The grid item index in section to execute default selection
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @result A set of NSIndexPath for the rows which selection changed
 */
- (nullable NSSet<NSIndexPath *> *)executeDefaultSelectionForEntityAtIndex:(NSUInteger)index section:(NSUInteger)section filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Executes the default selection/deselection for the given filtered index
 
 @param index The filtered grid item index to execute default selection
 @result An index set for the filtered rows which selection changed
 */
- (nullable NSIndexSet *)executeDefaultSelectionForFilteredEntityAtIndex:(NSUInteger)index __attribute__((deprecated("Use executeDefaultSelectionForEntityAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

/*!
 Checks if selected highlight style should be applied while grid item is selected
 
 @result YES if GXHighlightStyleSelected should be applied while grid item is selected, NO otherwise
 @discussion Selected highlight style should be applied when resolved list selection style is keep while executing or until new selection and there is no default selected layout
 */
- (BOOL)shouldApplyHighlightStyleSelectedOnSelection;

#pragma mark - GXListSelectionTypeKeepUntilNewSelection Helpers

/*!
 Keeps track of action handler execution
 
 @param actionHandler The action handler to keep track execution
 @param index The grid item index in section of action handler execution
 @param section The grid section index
 @result YES if the action execution is being tracked, NO otherwise
 @discussion When the action finishes executing keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section: is called.
 */
- (BOOL)keepSelectionWhileExecutingActionHandler:(id <GXActionHandler>)actionHandler
								forEntityAtIndex:(NSUInteger)index
										 section:(NSUInteger)section; // filtered:NO
/*!
 Keeps track of action handler execution
 
 @param actionHandler The action handler to keep track execution
 @param index The grid item index in section of action handler execution
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @result YES if the action execution is being tracked, NO otherwise
 @discussion When the action finishes executing keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section: is called.
 */
- (BOOL)keepSelectionWhileExecutingActionHandler:(id <GXActionHandler>)actionHandler
								forEntityAtIndex:(NSUInteger)index
										 section:(NSUInteger)section
										filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Keeps track of action handler execution
 
 @param actionHandler The action handler to keep track execution
 @param index The filtered grid item index of action handler execution
 @result YES if the action execution is being tracked, NO otherwise
 @discussion When the action finishes executing selectionWhileExecutingActionHandlerEnded:forEntityAtIndex:section:filtered: is called.
 */
- (BOOL)keepSelectionWhileExecutingActionHandler:(id <GXActionHandler>)actionHandler
						forFilteredEntityAtIndex:(NSUInteger)index __attribute__((deprecated("Use keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

/*!
 Called when the SelectionChanged Grid event is triggered to allow performing some additional actions to keep the selection while the event is running
 
 @param pIndexPath The index path of the selected item
 @param actionHandler The action handler executing the SelectionChanged event
 @discusion Default implementation does nothing
 */
- (void)keepSelectionWhileExecutingIfNeededForIndexPath:(NSIndexPath *)pIndexPath actionHandler:(id<GXActionHandler>)actionHandler;

#if TARGET_OS_IOS
/*!
 Call back for tracked action handler execution end, see keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section:
 
 @param actionHandler The action handler that finished executing
 @param index The grid item index in section of action handler execution
 @param section The grid section index
 @discussion Abstract, subclasses must override this method
 */
- (void)selectionWhileExecutingActionHandlerEnded:(id<GXActionHandler>)actionHandler
								 forEntityAtIndex:(NSUInteger)index
										  section:(NSInteger)section __attribute__((deprecated("Use selectionWhileExecutingActionHandlerEnded:forEntityAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS
/*!
 Call back for tracked action handler execution end, see keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section:
 
 @param actionHandler The action handler that finished executing
 @param index The grid item index in section of action handler execution
 @param section The grid section index
 @param filtered YES if the entity data is filtered, NO otherwise
 @discussion Abstract, subclasses must override this method
 */
- (void)selectionWhileExecutingActionHandlerEnded:(id<GXActionHandler>)actionHandler
								 forEntityAtIndex:(NSUInteger)index
										  section:(NSInteger)section
										 filtered:(BOOL)filtered;
#if TARGET_OS_IOS
/*!
 Call back for tracked action handler execution end, see keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section:filtered:
 
 @param actionHandler The action handler that finished executing
 @param index The filtered grid item index of action handler execution
 @discussion Abstract, subclasses must override this method
 */
- (void)selectionWhileExecutingActionHandlerEnded:(id<GXActionHandler>)actionHandler
						 forFilteredEntityAtIndex:(NSUInteger)index __attribute__((deprecated("Use selectionWhileExecutingActionHandlerEnded:forEntityAtIndex:section:filtered: instead")));
#endif // TARGET_OS_IOS

//! Stops tracking action execution, see keepSelectionWhileExecutingActionHandler:forEntityAtIndex:section:filtered:
- (void)stopKeepingSelectionWhileExecuting; // filtered and non filtered
- (void)stopKeepingSelectionWhileExecuting:(BOOL)filtered;

@end

NS_ASSUME_NONNULL_END
