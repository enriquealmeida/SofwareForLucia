//
//  GXActionUIHandler.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 3/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXObjectsModel;
@import GXObjectsModel.Swift;
@import GXCoreBL;

@interface GXActionHandler (GXActionHandlerUIDelegate) <GXActionUIHandler, GXActionHandlerUIDelegate>

#pragma mark Helpers

@property(nullable, nonatomic, strong, readonly) GXUserInterfaceContext *userInterfaceContext;
@property(nullable, nonatomic, strong, readonly) id <GXActionHandlerUserInterfaceControllerProtocol> gxActionHandlerUserInterfaceController;
@property(nullable, nonatomic, strong, readonly) id <GXControllerPresentationHandlerProtocol> gxActionHandlerControllerPresentationHandler;

@end


#if TARGET_OS_IOS
@interface GXActionHandler (GXActionHandlerUIDelegate_Deprecated)

@property(nullable, nonatomic, strong, readonly) id <GXActionHandlerViewController> gxActionHandlerViewController __attribute__((deprecated("Use gxActionHandlerUserInterfaceController instead")));
@property(nullable, nonatomic, strong, readonly) id <GXViewControllerPresentationHandler> gxActionHandlerViewControlerPresentationHandler __attribute__((deprecated("Use gxActionHandlerUserInterfaceController instead")));

@end
#endif // TARGET_OS_IOS
