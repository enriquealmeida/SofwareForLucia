//
//  GXControlBase+GXThemeClassPropertiesOverrides.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 16/07/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXCoreUI/GXControlBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXControlBase (GXThemeClassPropertiesOverrides) <GXThemeClassPropertiesOverrides>

/// Returns the value previously stored with setThemeClassPropertyValueOverride:forName:
- (nullable id)themeClassPropertyValueOverrideForName:(NSString *)propertyName;
/// Stores the given value for the given property name. If propertyValue == nil, removes the override for the given property name.
- (void)setThemeClassPropertyValueOverride:(nullable id)propertyValue forName:(NSString *)propertyName;
/// Removes the override for the given property name. Same as calling [self setThemeClassPropertyValueOverride:nil forName:propertyName].
- (void)removeThemeClassPropertyValueOverrideForName:(NSString *)propertyName;

/**
 * Called on setThemeClassPropertyValueOverride:forName: if the property value changes
 * Default implementation calls [self onThemeClassChanged:self.themeClass]
 */
- (void)onThemeClassPropertyValueOverrideDidChange:(NSString *)propertyName oldValue:(nullable id)oldPropertyValue;

@end

NS_ASSUME_NONNULL_END
