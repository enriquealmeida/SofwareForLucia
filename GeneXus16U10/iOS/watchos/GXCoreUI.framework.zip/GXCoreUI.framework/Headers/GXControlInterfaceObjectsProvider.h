//
//  GXControlInterfaceObjectsProvider.h
//  GXCoreUI
//
//  Created by Fabian Inthamoussu on 6/1/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

@import WatchKit;

NS_ASSUME_NONNULL_BEGIN

@protocol GXControlInterfaceObjectsProvider <NSObject>

- (nullable WKInterfaceObject *)gxControlInterfaceObjectFor:(NSString *)controlName;

- (nullable WKInterfaceLabel *)gxControlInterfaceLabelFor:(NSString *)controlName;

- (nullable WKInterfaceObject *)gxControlEditorInterfaceObjectFor:(NSString *)controlName;

- (nullable WKInterfaceObject *)gxControlUserControlInterfaceObjectFor:(NSString *)controlName objectName:(NSString *)objectName;

@end

NS_ASSUME_NONNULL_END
