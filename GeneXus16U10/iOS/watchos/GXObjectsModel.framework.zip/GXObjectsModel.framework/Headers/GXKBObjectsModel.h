//
//  GXKBObjectsModel.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 10/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXAttributeInfo.h>
#import <GXObjectsModel/GXBusinessComponentModel.h>
#import <GXObjectsModel/GXDashboardModel.h>
#import <GXObjectsModel/GXDomainInfo.h>
#import <GXObjectsModel/GXNamedElement.h>
#import <GXObjectsModel/GXProcedureModel.h>
#import <GXObjectsModel/GXResources.h>
#import <GXObjectsModel/GXStructureDataTypeInfo.h>
#import <GXObjectsModel/GXTheme.h>
#import <GXObjectsModel/GXWorkWithModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXKBObjectsModel : NSObject <NSCoding>

- (instancetype)initWithObjectModelsById:(nullable NSDictionary <NSString *, NSDictionary<NSString *, __kindof GXNamedElement *> *> *)objectModels
							   resources:(GXResources *)resources NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXAttributeInfo *> *attributeInfoByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXBusinessComponentModel *> *businessComponentsByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXDashboardModel *> *dashboardsByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXDomainInfo *> *domainInfoByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXProcedureModel *> *proceduresByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXStructureDataTypeInfo *> *sdtInfoByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXTheme *> *themesByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXWorkWithModel *> *workWithsByName;
@property(nonatomic, strong, readonly) NSDictionary<NSString *, GXWorkWithModel *> *workWithsByBusinessComponentName;

@property(nonatomic, strong, readonly) GXResources *resources;

- (nullable GXNamedElement *)objectForName:(NSString *)name type:(GXObjectType)type;
- (nullable GXAttributeInfo *)attributeInfoForName:(NSString *)name;
- (nullable GXBusinessComponentModel *)businessComponentForName:(NSString *)name;
- (nullable GXDashboardModel *)dashboardForName:(NSString *)name;
- (nullable GXDomainInfo *)domainInfoForName:(NSString *)name;
- (nullable GXProcedureModel *)procedureForName:(NSString *)name;
- (nullable GXStructureDataTypeInfo *)sdtInfoForName:(NSString *)name;
- (nullable GXTheme *)themeForName:(NSString *)name;
- (nullable GXWorkWithModel *)workWithForName:(NSString *)name;
- (nullable GXWorkWithModel *)workWithForBusinessComponent:(NSString *)entityType;


@end

@interface GXKBObjectsModel (GXModel)

+ (nullable GXKBObjectsModel *)currentModel;

@end

NS_ASSUME_NONNULL_END
