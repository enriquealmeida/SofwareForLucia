//
//  GXThemeClassImage.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 25/04/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassAttribute.h>
#import <GXObjectsModel/GXThemeClassWithDimensions.h>
#import <GXObjectsModel/GXThemeClassWithMotionEffect.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(uint_least8_t, GXImageScaleType) {
	GXImageScaleTypeFit,
	GXImageScaleTypeNoScale,
	GXImageScaleTypeFill,
	GXImageScaleTypeFillKeepingAspect,
	GXImageScaleTypeTile,
};
#define GXImageScaleType_UNDEFINED ((GXImageScaleType)UINT_LEAST8_MAX)

@interface GXThemeClassImage : GXThemeClassAttribute <GXThemeClassWithDimensions, GXThemeClassWithMotionEffect>

@property(nonatomic, assign, readonly) BOOL imageLoadingIndicator;
@property(nullable, nonatomic, strong, readonly) NSString *placeholderImage;
@property(nonatomic, assign, readonly) GXImageScaleType scaleType;

@end

NS_ASSUME_NONNULL_END
