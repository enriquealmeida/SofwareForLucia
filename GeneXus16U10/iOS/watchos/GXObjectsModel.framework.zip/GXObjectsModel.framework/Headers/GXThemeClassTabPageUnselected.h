//
//  GXThemeClassTabPageUnselected.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 12/08/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassTabPage.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassTabPageUnselected : GXThemeClassTabPage

@end

NS_ASSUME_NONNULL_END
