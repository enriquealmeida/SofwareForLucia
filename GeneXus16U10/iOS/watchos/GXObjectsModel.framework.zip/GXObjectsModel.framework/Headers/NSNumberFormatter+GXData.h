//
//  NSNumberFormatter+GXData.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 31/08/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXEntityDataFieldInfoProtocol.h>

@interface NSNumberFormatter (GXData)

+ (NSNumberFormatter *)numberFormatterForGXEntityDataFieldInfo:(id<GXEntityDataFieldInfo>)fieldInfo;

@end
