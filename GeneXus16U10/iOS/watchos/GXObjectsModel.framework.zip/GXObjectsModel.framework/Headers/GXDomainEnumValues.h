//
//  GXDomainEnumValues.h
//  GXObjectsModel
//
//  Created by Marcos Crispino on 10/23/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

@import GXFoundation;
#import <GXObjectsModel/GXDomainEnumValue.h>

NS_ASSUME_NONNULL_BEGIN

typedef enum : NSUInteger {
	GXDomainEnumValuesModificationNone = 0,
	GXDomainEnumValuesModificationInserted,
	GXDomainEnumValuesModificationUpdated,
	GXDomainEnumValuesModificationDeleted,
} GXDomainEnumValuesModificationType;

typedef struct {
	GXDomainEnumValuesModificationType type;
	NSUInteger index;
	NSString *desc;
} GXDomainEnumValuesModificationResult;

@interface GXDomainEnumValues : NSObject <NSCoding>

@property (nonatomic, assign, readonly) NSUInteger count;

- (id)initWithEnumValues:(NSArray<GXDomainEnumValue *> *)enumValues;
+ (id)domainEnumValuesWithMetadata:(NSArray<NSDictionary<NSString *, id> *> *)metadata dataType:(GXDataType)dataType;

- (NSString *)descriptionForEnumValue:(id)value;
- (NSArray<GXDomainEnumValue *> *)allEnumValues;
- (NSUInteger)indexOfEnumValue:(id)value;

- (NSUInteger)indexOfEnumDescription:(NSString *)desc;

- (GXDomainEnumValue *)domainEnumValueAtIndex:(NSUInteger)index;

- (GXDomainEnumValue *)domainEnumValueAtGXIndex:(id)gxIndex;

#pragma mark - Mutating

- (GXDomainEnumValuesModificationResult)addValue:(id)value description:(NSString *)desc atGXIndex:(id)gxIndex;
- (GXDomainEnumValuesModificationResult)removeValueAtGXIndex:(id)gxIndex;
- (void)removeAllValues;

@end

NS_ASSUME_NONNULL_END
