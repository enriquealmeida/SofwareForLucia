//
//  GXSecurityService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 15/1/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXModel.h>
#import <GXObjectsModel/GXSecurityServiceAuthorizationRequestOptions.h>

@protocol GXSecurityService;

NS_ASSUME_NONNULL_BEGIN

extern NSString *const GXSecurityServiceAuthorizationChangedNotification;
extern NSString *const GXSecurityServiceAuthorizationChangedModelKey;
extern NSString *const GXSecurityServiceLoginDidSucceedNotification;

typedef void (^GXSecurityServiceAuthorizationCompletionBlock)(BOOL success, NSError * _Nullable error);

@protocol GXSecurityService <NSObject>

- (BOOL)hasAuthorization;
- (BOOL)hasValidAuthorization;

- (BOOL)requestAuthorizationRequiredForApplicationEntryPoint:(GXModel *)model;

- (nullable id <NSObject>)requestAuthorizationForApplicationEntryPoint:(GXModel *)model
															 uiContext:(nullable GXUserInterfaceContext *)uiContext
															completion:(nullable GXSecurityServiceAuthorizationCompletionBlock)completion;

/*!
 Request authorization with the given options
 
 @param options Optional options. Default options are used if nil.
 @param completion Optional completion block to be called when authorization request finishes or is cancelled.
 @result Opaque request object to be used in cancelAutorizationRequest:. Return value is retained by the service.
 @discussion Note completion can be called before this method return
 */
- (nullable id <NSObject>)requestAuthorizationWithOptions:(nullable GXSecurityServiceAuthorizationRequestOptions *)options
											   completion:(nullable GXSecurityServiceAuthorizationCompletionBlock)completion;

// Cancel previous authorization request with the given object (returnred by requestAuthorization... methods).
- (void)cancelAutorizationRequest:(id <NSObject>)requestObject;

// Cancel all previous authorization requests
- (void)cancelAllAuthorizationRequests;

/*!
 Handles http response errors and returns recover options if can recover from security error by requesting authorization
 
 @param response Received http response.
 @param data Received response data.
 @param error Error from response and data. Always non nil error if response.statusCode >= 400.
 @param recoverOptions Non nil only if [GXObjectsModelServices securityService] is non nil too.
 @discussion If returned recoverOptions != nil, caller can try recovering from the returned security error by calling requestAuthorizationWithOptions:recoverOptions completion:.
 */
- (BOOL)handleSecurityErrorFromResponse:(NSHTTPURLResponse *)response
								   data:(nullable NSData *)data
								  error:(out NSError * __autoreleasing _Nullable * _Nullable)error
	 recoverAuthorizationRequestOptions:(out GXSecurityServiceAuthorizationRequestOptions * __autoreleasing _Nullable * _Nonnull)recoverOptions;

- (void)logout;

@optional
- (BOOL)showChangePasswordObject:(void(^ __nullable)(BOOL success))completionBlock;
- (BOOL)showNotAuthorizedObject;

- (nullable NSString *)currentUserIdentifier;

@end

NS_ASSUME_NONNULL_END
