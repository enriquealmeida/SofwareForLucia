//
//  GXStructureDataTypeInfo.h
//  GXFlexibleClient
//
//  Created by willy on 8/9/11.
//  Copyright 2011 Artech. All rights reserved.
//


@import Foundation;
#import <GXObjectsModel/GXStructureDataTypeLevelInfo.h>
#import <GXObjectsModel/GXTypedObjectInfo.h>

@class GXKBObjectsModel;

NS_ASSUME_NONNULL_BEGIN

/**
 * Represents an SDT (GXStructureDataTypeInfo) or a collection level item (GXStructureDataTypeLevelInfo.collectionItemSDTFieldInfo).
 * @discussion Some constrains:
 * @discussion	self.entityDataFieldInfoDataType == GXDataTypeSDT
 * @discussion	self.entityDataFieldInfoBasedOnName == nil
 * @discussion	self.entityDataFieldInfoBasedOnType == GXBasedOnTypeNone
 * @discussion	self.entityDataFieldInfoBasedOnInfo == nil
 */
@protocol GXEntityDataSDTFieldInfo <GXEntityDataFieldInfo>

/**
 * SDT field type name.
 * @discussion i.e. GeneXus.Common.Messages (same as GXStructureDataTypeInfo.name) of GeneXus.Common.Messages.Message (sublevel collectionItemName)
 */
@property(nonatomic, strong, readonly) NSString *entityDataSDTFieldInfoSDTTypeName;
/**
 * SDT field associated level.
 * @discussion i.e. GeneXus.Common.Messages and GeneXus.Common.Messages.Message returns the same level info (SDT's collection root level with isCollection == YES), however self.entityDataFieldInfoIsCollection returns different values (YES and NO respectively).
 */
@property(nonatomic, strong, readonly) GXStructureDataTypeLevelInfo *entityDataSDTFieldInfoSDTLevelInfo;

@optional
/// Cast over entityDataFieldInfoCollectionItemFieldInfo
@property(nullable, nonatomic, strong, readonly) id<GXEntityDataSDTFieldInfo> entityDataFieldInfoCollectionItemSDTFieldInfo;

@end

@interface GXStructureDataTypeInfo : GXTypedObjectInfo <GXEntityDataSDTFieldInfo>

@property(nonatomic, strong, readonly) GXStructureDataTypeLevelInfo *rootLevel;

- (nullable GXStructureDataTypeItemInfo *)itemInfoForFieldSpecifier:(NSString *)fieldSpecifier;

+ (nullable id<GXEntityDataSDTFieldInfo>)sdtFieldInfoForName:(NSString *)sdtBasedOnName; // model:nil
+ (nullable id<GXEntityDataSDTFieldInfo>)sdtFieldInfoForName:(NSString *)sdtBasedOnName model:(nullable GXKBObjectsModel *)model;

/// If fieldInfo.entityDataFieldInfoDataType != GXDataTypeSDT, returns nil. Otherwise returns the SDT field info for the given field info
+ (nullable id<GXEntityDataSDTFieldInfo>)sdtFieldInfoFromFieldInfo:(id<GXEntityDataFieldInfo>)fieldInfo;
/// If fieldInfo.entityDataFieldInfoDataType != GXDataTypeSDT, returns nil. Otherwise returns the SDT based on name for the given field info
+ (nullable NSString *)sdtDataBasedOnNameFromFieldInfo:(id<GXEntityDataFieldInfo>)fieldInfo;

+ (NSString *)fieldSpecifierForIndexer:(nullable NSArray *)indexer fieldSpecifier:(NSString *)fieldSpecifier;

/**
 * If the given field descriptor's field info data type is SDT return the field info for the given
 * fieldSpecifier (if found), field descriptor's field info otherwise
 */
+ (nullable id <GXEntityDataFieldInfo>)resolvedFieldInfoForFieldDescriptor:(id <GXEntityDataFieldDescriptor>)fieldDesc
															fieldSpecifier:(nullable NSString *)fieldSpecifier;

/**
 * If the given field info data type is SDT return the field info for the given
 * fieldSpecifier (if found), field descriptor's field info otherwise
 */
+ (nullable id <GXEntityDataFieldInfo>)resolvedFieldInfoForFieldInfo:(id <GXEntityDataFieldInfo>)fieldInfo
													  fieldSpecifier:(nullable NSString *)fieldSpecifier;

@end

@interface GXStructureDataTypeInfo (GXDeprecated)

+ (nullable GXStructureDataTypeInfo *)sdtInfoForName:(NSString *)sdtName __attribute__((deprecated("Use sdtFieldInfoForName: instead for resolving based on SDT or GXKBObjectsModel.currentModel sdtInfoForName: for the SDT object")));

@end

NS_ASSUME_NONNULL_END
