//
//  GXObjectsModelServices.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 11/11/15.
//  Copyright © 2015 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXAlertUIMessageService.h>
#import <GXObjectsModel/GXApplicationStorageService.h>
#import <GXObjectsModel/GXControlModelService.h>
#import <GXObjectsModel/GXDebuggerModelService.h>
#import <GXObjectsModel/GXExpressionEvaluatorService.h>
#import <GXObjectsModel/GXSecurityService.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXObjectsModelServices : NSObject

+ (id<GXAlertUIMessageService>)alertUIMessageService;
+ (id<GXApplicationStorageService>)applicationStorageService;
+ (id<GXControlModelService>)controlModelService;
+ (nullable id<GXDebuggerModelService>)debuggerService;
+ (id <GXExpressionEvaluatorService>)expressionEvaluatorService;
+ (nullable id<GXSecurityService>)securityService;

@end

NS_ASSUME_NONNULL_END
