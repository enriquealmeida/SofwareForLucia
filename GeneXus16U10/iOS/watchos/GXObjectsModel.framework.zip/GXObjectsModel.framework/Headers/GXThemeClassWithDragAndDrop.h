//
//  GXThemeClassWithDragAndDrop.h
//  GXFlexibleClient
//
//  Created by willy on 3/12/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@class GXThemeClass;

@protocol GXThemeClassWithDragAndDrop <NSObject>

@property(nullable, nonatomic, strong, readonly) GXThemeClass *startDraggingThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *acceptDragThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *noAcceptDragThemeClass;
@property(nullable, nonatomic, strong, readonly) GXThemeClass *dragOverThemeClass;

@end

NS_ASSUME_NONNULL_END