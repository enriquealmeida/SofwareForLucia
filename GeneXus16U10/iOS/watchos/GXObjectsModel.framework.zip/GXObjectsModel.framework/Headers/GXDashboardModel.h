//
//  GXDashboardModel.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 05/08/10.
//  Copyright 2010 Artech. All rights reserved.
//

#import <GXObjectsModel/GXMenuProtocol.h>
#import <GXObjectsModel/GXSDObjectModel.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXDashboardModel : GXSDObjectModel <GXMenu, NSCoding>

- (instancetype)initWithName:(NSString *)name
		  instanceProperties:(nullable NSDictionary<NSString *, id> *)instanceProperties
					   title:(nullable NSString *)title
		 backgroundImageName:(nullable NSString *)background
			 headerImageName:(nullable NSString *)header
				 controlType:(GXMenuControlType)controlType
					   items:(nullable NSArray<id<GXMenuItem>> *)items
			   notifications:(nullable NSArray<id<GXEventDescriptor>> *)notifications
					  events:(nullable NSArray<id<GXEventDescriptor>> *)events
		 showApplicationBars:(BOOL)showApplicationBars
			appBarsClassName:(nullable NSString *)appBarsClassName
			showLogoutButton:(BOOL)showLogoutButton
		  themeClassFullName:(nullable NSString *)themeClassFullName NS_DESIGNATED_INITIALIZER;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
