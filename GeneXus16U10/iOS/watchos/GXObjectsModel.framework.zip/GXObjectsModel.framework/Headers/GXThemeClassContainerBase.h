//
//  GXThemeClassContainerBase.h
//  GXFlexibleClient
//
//  Created by willy on 5/16/11.
//  Copyright 2011 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>
#import <GXObjectsModel/GXThemeClassWithPadding.h>
#import <GXObjectsModel/GXThemeClassWithMotionEffect.h>
#import <GXObjectsModel/GXThemeClassWithScroll.h>

@interface GXThemeClassContainerBase : GXThemeClassBase <GXThemeClassWithPadding, GXThemeClassWithMotionEffect, GXThemeClassWithScroll>

@end
