//
//  GXThemeClassDashboardOption.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 31/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXObjectsModel/GXThemeClassBase.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeClassDashboardOption : GXThemeClassBase

@property(nullable, nonatomic, strong, readonly) GXThemeClass *imageThemeClass;

@end

NS_ASSUME_NONNULL_END
