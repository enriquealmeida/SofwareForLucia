//
//  GXEntityDataQueryResult.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 24/11/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXEntityDataQueryResultProtocol.h>

@interface GXEntityDataQueryResult : NSObject <GXEntityDataQueryResult> // ABASTRACT

- (instancetype)initWithResultData:(id)resultData
						 timeStamp:(NSDate *)timeStamp
							 error:(NSError *)error NS_DESIGNATED_INITIALIZER;
- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)entityDataQueryResultWithError:(NSError *)error;

@end

@interface GXEntityDataQuerySingleItemResult : GXEntityDataQueryResult <GXEntityDataQuerySingleItemResult>

+ (instancetype)entityDataQueryResultWithResultData:(id <GXEntityData>)resultData
										  timeStamp:(NSDate *)timeStamp;

@end

@interface GXEntityDataQueryCollectionResult : GXEntityDataQueryResult <GXEntityDataQueryCollectionResult>

- (instancetype)initWithResultData:(NSArray<NSArray<id<GXEntityData>> *> *)resultData
						 timeStamp:(NSDate *)timeStamp
							 error:(NSError *)error
							 count:(NSUInteger)count
						  complete:(BOOL)complete
				  alphaIndexTitles:(NSArray<NSString *> *)alphaIndexTitles
		   alphaIndexRangesByTitle:(NSDictionary<NSString *, NSValue *> *)alphaIndexRangesByTitle NS_DESIGNATED_INITIALIZER;

+ (instancetype)entityDataQueryResultWithResultData:(NSArray<NSArray<id<GXEntityData>> *> *)resultData
										  timeStamp:(NSDate *)timeStamp
											  count:(NSUInteger)count
										   complete:(BOOL)complete
								   alphaIndexTitles:(NSArray<NSString *> *)alphaIndexTitles
							alphaIndexRangesByTitle:(NSDictionary<NSString *, NSValue *> *)alphaIndexRangesByTitle;

@end
