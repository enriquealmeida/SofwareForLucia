//
//  GXBinaryDataFieldReference.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 23/05/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;

typedef NS_ENUM(uint_least8_t, GXBinaryDataFieldReferenceType) {
	GXBinaryDataFieldReferenceTypeSingle,
	GXBinaryDataFieldReferenceTypeComposite
};

@interface GXBinaryDataFieldReference : NSObject // Abstract

@property(nonatomic, assign, readonly) GXBinaryDataFieldReferenceType type;
@property(nonatomic, strong, readonly) NSString *name;

- (id)initWithName:(NSString *)name;

@end

extern NSString *const GXSingleBinaryDataFieldReferenceTypedObjectInfoUserInfoKey;
extern NSString *const GXSingleBinaryDataFieldReferenceCallerTypedObjectInfoUserInfoKey;

@interface GXSingleBinaryDataFieldReference : GXBinaryDataFieldReference

/**
 * objectReference could be of be NSURL, NSString (with url) or NSData
 */
@property(nonatomic, strong, readonly) NSObject *objectReference;
@property(nonatomic, strong, readwrite) NSString *uploadedObjectId;
@property(nonatomic, strong, readwrite) NSDictionary *userInfo;

- (id)initWithName:(NSString *)name objectReference:(NSObject *)objectReference;

/**
 * Checks if the reference is valid.
 *
 * @discussion For NSData and remote URLs it always returns YES. For file URLs, checks if the file exists
 */
- (BOOL)isValidReference;

/**
 * Returns the file name, if any
 *
 * @return nil for references that are of type NSData and remote URLs
 * @return the file name if the reference is a local file
 */
- (NSString *)objectReferenceName;

@end

@interface GXCompositeBinaryDataFieldReference : GXBinaryDataFieldReference

- (id)initWithName:(NSString *)name objectReferences:(NSArray *)objectReferences objectReferencesIndexes:(NSIndexSet *)indexSet;

- (void)enumerateObjectReferencesWithBlock:(void(^)(GXBinaryDataFieldReference *objRef, NSUInteger idx, BOOL *stop))block;

@end
