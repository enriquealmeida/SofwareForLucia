//
//  GXEntityHelper+GXDynamicProperties.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 20/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXDynamicPropertiesCollection.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXEntityHelper (GXDynamicProperties)

+ (nullable GXDynamicPropertiesCollection *)parseDynamicPropertiesCollectionFromValue:(nullable id)value;
+ (nullable GXDynamicPropertiesCollection *)parseDynamicPropertiesCollectionFromEntityData:(nullable id<GXEntityData>)entityData;

@end


#if TARGET_OS_IOS
@interface GXEntityHelper (GXDynamicProperties_Deprecated)

+ (nullable NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)parseDynamicPropertiesFromValue:(nullable id)value __attribute__((deprecated("Use parseDynamicPropertiesCollectionFromValue: instead.")));
+ (nullable NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)parseDynamicPropertiesFromEntityData:(nullable id<GXEntityData>)entityData __attribute__((deprecated("Use parseDynamicPropertiesCollectionFromEntityData: instead.")));

+ (nullable GXDynamicPropertiesCollection *)dynamicPropertiesCollectionFromDictionary:(nullable NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)dynamicPropertiesByControlName __attribute__((deprecated("Use GXDynamicPropertiesCollection instead.")));
+ (nullable NSDictionary<NSString *, NSDictionary<NSString *, id> *> *)dynamicPropertiesDictionaryFromCollection:(nullable GXDynamicPropertiesCollection *)dynamicPropertiesCollection __attribute__((deprecated("Use GXDynamicPropertiesCollection instead.")));

@end
#endif // TARGET_OS_IOS

NS_ASSUME_NONNULL_END
