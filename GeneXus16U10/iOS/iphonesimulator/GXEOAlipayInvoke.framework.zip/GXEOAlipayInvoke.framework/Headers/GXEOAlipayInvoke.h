//
//  GXEOAlipayInvoke.h
//  GXEOAlipayInvoke
//
//  Created by Marcos Crispino on 22/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXEOAlipayInvoke.
FOUNDATION_EXPORT double GXEOAlipayInvokeVersionNumber;

//! Project version string for GXEOAlipayInvoke.
FOUNDATION_EXPORT const unsigned char GXEOAlipayInvokeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXEOAlipayInvoke/PublicHeader.h>

#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#import <GXEOAlipayInvoke/GXActionExObjAlipayInvokeHandler.h>
#import <GXEOAlipayInvoke/GXEOAlipayInvokeExtensionLibrary.h>
#import <GXEOAlipayInvoke/GXEOAlipayInvokeOpenURLHandler.h>
