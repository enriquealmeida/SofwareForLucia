//
//  GXActionExObjAlipayInvokeHandler.h
//  GXEOAlipayInvoke
//
//  Created by Marcos Crispino on 23/8/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <GXCoreBL/GXCoreBL.h>

@interface GXActionExObjAlipayInvokeHandler : GXActionExternalObjectHandler

+ (NSString *)externalObjectName;

@end
