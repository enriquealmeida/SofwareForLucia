//
//  GXDynamicControlService.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 10/17/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;
#import <GXObjectsModel/GXDynamicDataServiceProtocol.h>
#import <GXObjectsModel/GXNamedElement.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXDynamicControlService : GXNamedElement <GXRemoteDynamicDataService, GXLocalDynamicDataService>

- (instancetype)initWithServiceName:(NSString *)dynamicDataServiceName
				   serviceUrlString:(NSString *)urlString
						 parameters:(nullable NSArray<id<GXActionParameterDescriptor>> *)parameters NS_DESIGNATED_INITIALIZER;

- (instancetype)init NS_UNAVAILABLE;
- (instancetype)initWithName:(nullable NSString *)name NS_UNAVAILABLE;
- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_DESIGNATED_INITIALIZER;

@end

NS_ASSUME_NONNULL_END
