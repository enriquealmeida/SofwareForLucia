//
//  GXUserInterfaceContextFactory.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 16/11/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import "GXUserInterfaceContext.h"

NS_ASSUME_NONNULL_BEGIN

@interface GXUserInterfaceContextFactory : NSObject

#if !TARGET_OS_WATCH
+ (nullable id <GXViewUserInterfaceContext>)userInterfaceContextWithView:(nullable UIView *)view;

+ (nullable id <GXBarItemUserInterfaceContext>)userInterfaceContextWithBarItem:(nullable UIBarItem *)barItem
																viewController:(nullable UIViewController *)controller;

+ (nullable id <GXGestureRecognizerUserInterfaceContext>)userInterfaceContextWithGestureRecognizer:(nullable UIGestureRecognizer *)gestureRecognizer;

+ (nullable id <GXViewControllerUserInterfaceContext>)userInterfaceContextWithViewController:(nullable UIViewController *)controller;
+ (nullable id <GXViewControllerUserInterfaceContext>)userInterfaceContextWithController:(nullable UIViewController *)controller;
#else
+ (nullable id <GXViewUserInterfaceContext>)userInterfaceContextWithInterfaceObject:(nullable WKInterfaceObject *)interfaceObject;

+ (nullable id <GXControllerUserInterfaceContext>)userInterfaceContextWithController:(nullable WKInterfaceController *)controller;
#endif // !TARGET_OS_WATCH

@end

NS_ASSUME_NONNULL_END
