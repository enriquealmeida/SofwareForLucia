//
//  GXThemeHelper+GXThemeClass.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 13/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <GXObjectsModel/GXThemeHelper.h>

NS_ASSUME_NONNULL_BEGIN

@interface GXThemeHelper (GXThemeClass)

+ (GXLayoutQuadDimension)marginFromClass:(nullable GXThemeClass *)themeClass;
+ (GXLayoutQuadDimension)paddingFromClass:(nullable GXThemeClass *)themeClass;
+ (CGFloat)borderWidthFromClass:(nullable GXThemeClass *)themeClass;

+ (CGSize)calculatedSizeForThemeClassWithDimensions:(nullable GXThemeClass *)themeClass;

+ (CGSize)totalExtraSizeFormThemeClass:(nullable GXThemeClass *)themeClass
					 consideringMargins:(BOOL)considerMargins;

@end

NS_ASSUME_NONNULL_END
