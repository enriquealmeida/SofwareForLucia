//
//  GXDomainEnumValue.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 29/11/10.
//  Copyright 2010 Artech. All rights reserved.
//

@import Foundation;
@import GXFoundation;

@interface GXDomainEnumValue : NSObject <NSCoding>

@property(nonatomic, strong, readonly) id value;
@property(nonatomic, strong, readonly) NSString *desc;

- (id)initWithDescription:(NSString *)desc value:(id)value;
- (id)initWithMetadata:(NSDictionary<NSString *, id> *)metadata dataType:(GXDataType)dataType;

- (id)fieldEnumValue;
- (NSString *)fieldEnumValueDescription;

@end
