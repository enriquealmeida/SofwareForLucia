//
//  NSCalendar+GXObjectsModel_Calendar.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 1/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
@import GXFoundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSCalendar (GXObjectsModel_Calendar)

+ (NSCalendar *)gxCalendarCurrentTimeZone;

@end

NS_ASSUME_NONNULL_END
