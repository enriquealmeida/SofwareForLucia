//
//  GXAlertUIMessageService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 12/2/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXUserInterfaceContext.h>

@class GXAlertUIAction;

typedef NS_ENUM(NSUInteger, GXAlertUIMessageServiceRecoveryAttempterMode) {
	GXAlertUIMessageServiceRecoveryAttempterMode_RecoveryAttempterOnly,
	GXAlertUIMessageServiceRecoveryAttempterMode_ActionsOnly,
	GXAlertUIMessageServiceRecoveryAttempterMode_FallbackToActions,
};

NS_ASSUME_NONNULL_BEGIN

@protocol GXAlertUIMessageService <GXAlertMessageService>

- (void)showAlertWithTitle:(nullable NSString *)alertTitle
				   message:(nullable NSString *)alertMsg
				 uiContext:(nullable GXUserInterfaceContext *)uiContext;

- (void)showAlertWithTitle:(nullable NSString *)alertTitle
				   message:(nullable NSString *)alertMsg
				completion:(nullable void(^)(void))completion
		  dismissedHandler:(nullable void(^)(void))dismissedHandler
				 uiContext:(nullable GXUserInterfaceContext *)uiContext;

- (void)showAlertWithTitle:(nullable NSString *)alertTitle
				   message:(nullable NSString *)alertMsg
				   actions:(nullable NSArray<GXAlertUIAction *> *)actions
				completion:(nullable void(^)(void))completion
		  dismissedHandler:(nullable void(^)(void))dismissedHandler
				 uiContext:(nullable GXUserInterfaceContext *)uiContext;


- (void)showAlertForError:(nullable NSError *)error
				uiContext:(nullable GXUserInterfaceContext *)uiContext;

- (void)showAlertForError:(nullable NSError *)error
			   completion:(nullable void(^)(void))completion
		 dismissedHandler:(nullable void(^)(void))dismissedHandler
				uiContext:(nullable GXUserInterfaceContext *)uiContext;

- (void)showAlertForError:(nullable NSError *)error
	recoveryAttempterMode:(GXAlertUIMessageServiceRecoveryAttempterMode)recoveryAttempterMode
				  actions:(nullable NSArray<GXAlertUIAction *> *)actions
			   completion:(nullable void(^)(void))completion
		 dismissedHandler:(nullable void(^)(void))dismissedHandler
				uiContext:(nullable GXUserInterfaceContext *)uiContext;

#if TARGET_OS_WATCH
- (void)dismissPresentedAlert;
#endif // TARGET_OS_WATCH

@end

NS_ASSUME_NONNULL_END
