//
//  GXControlModelService.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 8/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@protocol GXControlModelService <NSObject>

- (nullable NSDictionary<NSString *, id> *)transformControlType:(NSString *)controlType
								   customPropertiesFromMetadata:(nullable NSDictionary<NSString *, id> *)customProperties;

@end

NS_ASSUME_NONNULL_END