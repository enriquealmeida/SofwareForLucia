//
//  GXProcedureParameter.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 08/03/11.
//  Copyright 2011 Artech. All rights reserved.
//


@import Foundation;
@import GXFoundation;
#import <GXObjectsModel/GXParametersDescriptorProtocol.h>
#import <GXObjectsModel/GXTypedObjectInfo.h>

@interface GXProcedureParameter : GXNamedElement <GXParameterDescriptor> // Abstract

- (id)initWithName:(NSString *)name kind:(GXParameterKind)kind;

@end


@interface GXProcedureParameterAttribute : GXProcedureParameter <GXEntityDataFieldAttributeDescriptor>

@end


@interface GXProcedureParameterVariable : GXProcedureParameter <GXEntityDataFieldVariableDescriptor>

@property(nonatomic, strong, readonly) GXTypedObjectInfo *typedObject;

- (id)initWithTypedObjectInfo:(GXTypedObjectInfo *)typedObjectInfo
						 kind:(GXParameterKind)kind;

@end


@interface GXProcedureParameterVariableOldMetadataFormat : GXProcedureParameter <GXEntityDataFieldVariableDescriptor, GXEntityDataFieldInfo>

- (id)initWithName:(NSString *)name
			  kind:(GXParameterKind)kind
		  dataType:(GXDataType)dataType
	  isCollection:(BOOL)isCollection;

@end
