//
//  GXTimeZone.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 11/4/13.
//  Copyright (c) 2013 Artech. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface GXTimeZone : NSObject

+ (NSTimeZone *)currentTimeZone;

+ (NSString *)currentTimeZoneName;

+ (NSNumber *)currentTimeZoneOffset;

+ (BOOL)setCurrentTimeZoneWithName:(NSString *)tzName;

+ (NSDate *)convertDateTime:(NSDate *)dateTime fromTimeZone:(NSString *)tzName;

@end

NS_ASSUME_NONNULL_END
