//
//  NSString+MimeTypes.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 30/08/11.
//  Copyright (c) 2011 Artech. All rights reserved.
//

@import Foundation;

@interface NSString (MimeTypes)

- (NSString *)mimeTypeForPathExtension;

@end
