//
//  NSCalendar+GXCalendar.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 1/4/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@interface NSCalendar (GXCalendar)

+ (NSCalendar *)gxCalendar;

@end

NS_ASSUME_NONNULL_END