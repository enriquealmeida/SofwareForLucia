//
//  GXCancelableOperationProtocol.h
//  GXFoundation
//
//  Created by Fabian Inthamoussu on 04/01/2019.
//  Copyright © 2019 GeneXus. All rights reserved.
//

@import Foundation;

NS_ASSUME_NONNULL_BEGIN

@protocol GXCancelableOperation <NSObject>

- (void)cancel;

@end

@interface NSOperation (GXCancelableOperation) <GXCancelableOperation>
@end

NS_ASSUME_NONNULL_END
