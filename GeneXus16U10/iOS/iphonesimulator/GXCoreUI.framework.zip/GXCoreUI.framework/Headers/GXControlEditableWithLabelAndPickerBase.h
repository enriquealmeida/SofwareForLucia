//
//  GXControlEditableWithLabelAndPickerBase.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 26/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXCoreUI/GXControlEditableWithLabelSingleEditorViewBase.h>

@interface GXControlEditableWithLabelAndPickerBase : GXControlEditableWithLabelSingleEditorViewBase

#pragma mark - Abstract

/**
 * Returns a string with the value to be displayed in the control
 */
- (nullable NSString *)fieldValueToLoad;

@end
