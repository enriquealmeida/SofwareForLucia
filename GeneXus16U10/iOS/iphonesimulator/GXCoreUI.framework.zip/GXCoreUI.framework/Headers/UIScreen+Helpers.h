//
//  UIScreen+Helpers.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 1/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

@import UIKit;

#if TARGET_OS_IOS
@interface UIScreen (Helpers)

@property(nonatomic, assign, readonly) CGRect gxApplicationFrame __attribute__((deprecated("Use bounds instead")));

@end
#endif // TARGET_OS_IOS
