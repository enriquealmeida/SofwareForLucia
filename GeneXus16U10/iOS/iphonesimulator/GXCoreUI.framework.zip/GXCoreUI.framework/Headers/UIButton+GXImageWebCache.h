//
//  UIButton+GXImageWebCache.h
//  GXFlexibleClient
//
//  Created by willy on 5/10/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import UIKit;
@import GXObjectsModel;
@import GXCoreBL;
#import <GXCoreUI/UIButton+WebCache.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (GXImageWebCache)

- (void)gxSetImageNamed:(nullable NSString *)imageName forState:(UIControlState)state;

- (void)gxSetBackgroundImageNamed:(nullable NSString *)imageName forState:(UIControlState)state;

@end

NS_ASSUME_NONNULL_END
