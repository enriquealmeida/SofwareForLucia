//
//  GXControlWithActionBarItems.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 12/01/12.
//  Copyright (c) 2012 Artech. All rights reserved.
//

#import <GXCoreUI/GXControl.h>
#import <GXCoreUI/GXControlActionBarItem.h>

NS_ASSUME_NONNULL_BEGIN

@protocol GXControlActionBarItem;
@protocol GXControlWithActionBarItemsDelegate;

typedef NS_OPTIONS(uint_least8_t, GXControlWithActionBarItemsEnumerationOptions) {
	GXControlWithActionBarItems_None = 0,
	GXControlWithActionBarItems_ExistingOnly = 1 << 0,	// User to avoid child controls creation
	GXControlWithActionBarItems_VisibleOnly = 1 << 1,
	GXControlWithActionBarItems_CurrentComponentOnly = 1 << 2,
};

@protocol GXControlWithActionBarItems <GXControl>

@property(nullable, nonatomic, weak) id<GXControlWithActionBarItemsDelegate> controlWithActionBarItemsDelegate;

@property(nullable, nonatomic, strong, readonly) NSArray<id<GXControlActionBarItem>> *controlActionBarItems;

- (void)enumerateControlActionBarItemsWithBlock:(void (^)(id <GXControlActionBarItem> item, BOOL *stop))block options:(GXControlWithActionBarItemsEnumerationOptions)options;

@optional
/// Controls that need to display buttons in the left section of the navigation bar, shoud return here an array of UIBarButtonItem
- (nullable NSArray<UIBarButtonItem *> *)controlRequiredNavigationBarLeftItems __attribute__((deprecated("Use controlActionBarItems instead")));

/// Controls that need to display buttons in the right section of the navigation bar, shoud return here an array of UIBarButtonItem
- (nullable NSArray<UIBarButtonItem *> *)controlRequiredNavigationBarRightItems __attribute__((deprecated("Use controlActionBarItems instead")));

/// Controls that need to display buttons in the toolbar, shoud return here an array of UIBarButtonItem
- (nullable NSArray<UIBarButtonItem *> *)controlRequiredToolbarBarItems __attribute__((deprecated("Use controlActionBarItems instead")));

/**
 * If this method returns YES or is not implemented, application bar default button class is applied to items returned in methods:
 * controlRequiredNavigationBarLeftItems, controlRequiredNavigationBarRightItems & controlRequiredToolbarBarItems
 */
- (BOOL)shouldApplyApplicationBarDefaultButtonClassToControlBarItems __attribute__((deprecated("Use controlActionBarItems instead")));

@end

#pragma mark -

@protocol GXControlWithActionBarItemsDelegate <NSObject>

/// The control should call this method if it needs to refresh the actions
- (void)controlWithActionBarItemsNeedsReloadActions:(id<GXControlWithActionBarItems>)control;
/// The control should call this method if it needs to refresh the actions with explicit animated transition
- (void)controlWithActionBarItemsNeedsReloadActions:(id<GXControlWithActionBarItems>)control animated:(BOOL)animated;

@end

NS_ASSUME_NONNULL_END
