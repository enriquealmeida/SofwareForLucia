//
//  GXAddressBookContact.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 21/08/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXObjectsModel;
#if !TARGET_OS_TV
@import Contacts;
#endif // !TARGET_OS_TV

NS_ASSUME_NONNULL_BEGIN

#define GXSDTContactInfo_SDTTypeName			kGXCoreModuleName_GeneXus_SD kGXModule_Separator @"ContactInfo"

#define GXSDTContactInfo_FirstName				@"FirstName"
#define GXSDTContactInfo_LastName				@"LastName"
#define GXSDTContactInfo_EMail					@"EMail"
#define GXSDTContactInfo_Phone					@"Phone"
#define GXSDTContactInfo_CompanyName			@"CompanyName"
#define GXSDTContactInfo_Photo					@"Photo"
#define GXSDTContactInfo_Notes					@"Notes"
#define GXSDTContactInfo_DisplayName			@"DisplayName"

#if !TARGET_OS_TV
@interface GXAddressBookContact : NSObject

@property (nullable, nonatomic, strong) NSString *firstName;
@property (nullable, nonatomic, strong) NSString *lastName;
@property (nullable, nonatomic, strong) NSString *email;
@property (nullable, nonatomic, strong) NSString *phone;
@property (nullable, nonatomic, strong) NSString *companyName;
@property (nullable, nonatomic, strong) NSURL *photoURL;
@property (nullable, nonatomic, strong) NSString *notes;
@property (nullable, nonatomic, strong) NSString *displayName;

- (instancetype)initWithContact:(CNContact *)contact;

- (instancetype)init NS_UNAVAILABLE;

- (NSDictionary<NSString *, id> *)dictionaryRepresentation;

+ (NSArray<id<CNKeyDescriptor>> *)contactsFrameworkKeysToFetch;

@end
#endif // !TARGET_OS_TV

#if TARGET_OS_IOS
@interface GXAddressBookContact (GXDeprecated)

+ (NSArray<id<CNKeyDescriptor>> *)contactsFrameworkKesyToFetch  __attribute__((deprecated("Use contactsFrameworkKeysToFetch instead")));

@end
#endif // TARGET_OS_IOS

NS_ASSUME_NONNULL_END
