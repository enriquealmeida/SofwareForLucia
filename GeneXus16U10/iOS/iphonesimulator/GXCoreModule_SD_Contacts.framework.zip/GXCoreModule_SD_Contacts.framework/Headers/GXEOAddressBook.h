//
//  GXEOAddressBook.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 21/08/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXCoreBL;
@import GXStandardClasses;
#import <GXCoreModule_SD_Contacts/GXAddressBookContact.h>
#if !TARGET_OS_TV
@import Contacts;
#endif // !TARGET_OS_TV

NS_ASSUME_NONNULL_BEGIN

@interface GXEOAddressBook : GXExternalObjectBase

#if !TARGET_OS_TV
/**
 * Instantiates a Contact Store object and checks if the application has permition to read from it.
 *
 * @param block The completion block that will be called when the operation finishes, receives the error (if it failed) or nil
 */
- (void)executeBlockWithAuthorizationStatusDetermined:(void(^)(CNContactStore * _Nullable contactStore, NSError * _Nullable error))block;

/*!
 Returns the list of contacts stored in the device
 
 @param block Completion handler, must no be NULL. Contacts parameter is a NSArray of GXAddressBookContact.
 @result YES if completion handler will be called async, no otherwise.
 */
- (BOOL)getAllContactsArrayWithCompletionBlock:(void(^)(NSArray<GXAddressBookContact *> * _Nullable contacts, NSError * _Nullable error))block;
#endif // !TARGET_OS_TV

@end

@interface GXEOAddressBook (OfflineGenerator)

- (GXObjectCollection *)getAllContacts;

@end

NS_ASSUME_NONNULL_END
