//
//  GXEntityDataFieldImagePickerController.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 22/03/11.
//  Copyright 2011 Artech. All rights reserved.
//

@import GXCoreUI;

NS_ASSUME_NONNULL_BEGIN

@interface GXEntityDataFieldImagePickerController : UIImagePickerController <GXEntityDataFieldImagePickerProtocol,
																				GXEntityDataFieldEditorViewControllerHelperDelegate,
																				UINavigationControllerDelegate,
																				UIImagePickerControllerDelegate>

@property(nonatomic, strong, readonly) GXEntityDataFieldEditorViewControllerHelper *editorHelper;

- (nullable instancetype)initWithEntityData:(id <GXEntityDataWithOverrideValues>)entityData
							fieldDescriptor:(id <GXEntityDataFieldDescriptor>)fieldDesc
							 fieldSpecifier:(nullable NSString *)fieldSpecifier
									indexer:(nullable NSArray *)indexer
								 sourceType:(UIImagePickerControllerSourceType)sourceType
									  error:(out NSError * __autoreleasing _Nullable * _Nullable)error NS_DESIGNATED_INITIALIZER;

- (nullable instancetype)initWithCoder:(NSCoder *)aDecoder NS_UNAVAILABLE;
- (instancetype)initWithNavigationBarClass:(nullable Class)navigationBarClass toolbarClass:(nullable Class)toolbarClass NS_UNAVAILABLE;
- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil NS_UNAVAILABLE;
- (instancetype)initWithRootViewController:(UIViewController *)rootViewController NS_UNAVAILABLE;

@end

@interface GXEntityDataFieldImagePickerController (Deprecated)

+ (BOOL)isCamaraAvailableForPhoto __attribute__((deprecated("Use [GXImagePickerControllerHelper isCameraAvailableForPhoto] instead")));
+ (BOOL)isCamaraAvailableForMovie __attribute__((deprecated("Use [GXImagePickerControllerHelper isCameraAvailableForMovie] instead")));
+ (BOOL)isPhotoLibraryAvailableForPhoto __attribute__((deprecated("Use [GXImagePickerControllerHelper isPhotoLibraryAvailableForPhoto] instead")));
+ (BOOL)isPhotoLibraryAvailableForMovie __attribute__((deprecated("Use [GXImagePickerControllerHelper isPhotoLibraryAvailableForMovie] instead")));

+ (NSError *)cameraNotAvailableError __attribute__((deprecated("Use [GXImagePickerControllerHelper cameraNotAvailableError] instead")));
+ (NSError *)photoLibraryNotAvailableError __attribute__((deprecated("Use [GXImagePickerControllerHelper photoLibraryNotAvailableError] instead")));

+ (void)executeBlockWithCameraAuthorized:(void(^)(AVAuthorizationStatus authStatus, NSError * _Nullable error))block __attribute__((deprecated("Use [GXImagePickerControllerHelper executeBlockWithCameraAuthorized:] instead")));
+ (void)executeBlockWithPhotoLibraryAuthorized:(void(^)(PHAuthorizationStatus authStatus, NSError * _Nullable error))block __attribute__((deprecated("Use [GXImagePickerControllerHelper executeBlockWithPhotoLibraryAuthorized:] instead")));

+ (void)defaultImagePickerController:(UIImagePickerController *)picker
	   didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
					handlerWithBlock:(void(^)(NSURL * _Nullable pickedMediaFileURL, BOOL isTempFileURL))resultBlock __attribute__((deprecated("Use [GXImagePickerControllerHelper defaultImagePickerControllerDidFinishPickingMediaWithInfo:handlerWithBlock:] instead")));

- (void)executeBlockWithAuthorizedStatus:(void(^)(NSError * _Nullable error))block __attribute__((deprecated("Use [GXImagePickerControllerHelper executeBlockWithAuthorizedStatusForPicker:block:] instead")));
- (void)executeBlockWithAuthorizedStatus:(void(^)(NSError * _Nullable error))block ignoreDeniedStatusErrorForPhotoLibrary:(BOOL)ignoreDeniedStatusErrorForPhotoLibrary __attribute__((deprecated("Use [GXImagePickerControllerHelper executeBlockWithAuthorizedStatusForPicker:ignoreDeniedStatusErrorForPhotoLibrary:block:] instead")));
@end

NS_ASSUME_NONNULL_END
