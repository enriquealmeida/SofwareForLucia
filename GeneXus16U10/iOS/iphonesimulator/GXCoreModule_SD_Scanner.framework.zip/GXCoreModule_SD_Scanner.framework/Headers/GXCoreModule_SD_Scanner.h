//
//  GXCoreModule_SD_Scanner.h
//  GXCoreModule_SD_Scanner
//
//  Created by Fabian Inthamoussu on 30/5/16.
//  Copyright © 2016 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXCoreModule_SD_Scanner.
FOUNDATION_EXPORT double GXCoreModule_SD_ScannerVersionNumber;

//! Project version string for GXCoreModule_SD_Scanner.
FOUNDATION_EXPORT const unsigned char GXCoreModule_SD_ScannerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXCoreModule_SD_Scanner/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif
