//
//  GXEntityHelper+GXEntityData.h
//  GXFlexibleClient
//
//  Created by Fabian Inthamoussu on 20/12/15.
//  Copyright © 2015 GeneXus. All rights reserved.
//

@import GXObjectsModel;
#import <GXDataLayer/GXEntityDataDetailProviderProtocol.h>

@interface GXEntityHelper (GXEntityData)

+ (BOOL)isEntityData:(id <GXEntityData>)data1
		 equalToData:(id <GXEntityData>)data2
		  descriptor:(id <GXEntityDataDescriptor>)descriptor; // nilDescMeansEquals = NO

+ (BOOL)isEntityData:(id <GXEntityData>)data1
		 equalToData:(id <GXEntityData>)data2
		  descriptor:(id <GXEntityDataDescriptor>)descriptor
  nilDescMeansEquals:(BOOL)nilDescriptorMeansEquals;

+ (BOOL)isEntityData:(id <GXEntityData>)data1
		 equalToData:(id <GXEntityData>)data2
comparingFieldDescriptors:(NSArray<id<GXEntityDataFieldDescriptor>> *)fieldDescriptors;

/*!
 Checks if the given entity data is empty and has no fields
 
 @param entityData Entity data to check
 @result YES if the given entity data is empty and has no fields, NO otherwise
 @discussion An entity data is considered empty if valueForEntityDataFieldName: will return always nil, and to have no field if hasValueForEntityDataFieldName: will return allways NO. Passing nil returns YES.
 */
+ (BOOL)isEntityDataEmptyWithoutFields:(id <GXEntityData>)entityData;

+ (NSArray *)entityDataFieldsValuesForDescriptor:(id <GXEntityDataDescriptor>)descriptor
											data:(id <GXEntityData>)data;

+ (NSArray *)entityDataFieldsValuesForFieldNames:(NSArray<NSString *> *)fieldNames
								  fromEntityData:(id <GXEntityData>)data;


+ (id)updateEntityData:(id<GXEntityDataWithOverrideValues>)entityData
	forFieldDescriptor:(id<GXEntityDataFieldDescriptor>)fieldDescriptor
indexedFfieldSpecifier:(NSString *)fieldSpecifier
	 resolvedFieldInfo:(id<GXEntityDataFieldInfo>)resolvedFieldInfo
			 withValue:(id)newValue; // allowNull == YES

+ (id)updateEntityData:(id<GXEntityDataWithOverrideValues>)entityData
	forFieldDescriptor:(id<GXEntityDataFieldDescriptor>)fieldDescriptor
indexedFfieldSpecifier:(NSString *)fieldSpecifier
	 resolvedFieldInfo:(id<GXEntityDataFieldInfo>)resolvedFieldInfo
			 withValue:(id)newValue
			 allowNull:(BOOL)allowNull;

+ (id <GXEntityDataWithOverrideValues>)entityDataFromEntityDataDetailProvider:(id <GXEntityDataDetailProvider>)provider
																		 mode:(GXModeType)mode;

@end
