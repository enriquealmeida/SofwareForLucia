//
//  GXAppleMapsSDMaps.h
//  GXAppleMapsSDMaps
//
//  Created by José Echagüe on 4/24/18.
//  Copyright © 2018 GeneXus. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for GXAppleMapsSDMaps_.
FOUNDATION_EXPORT double GXAppleMapsSDMapsVersionNumber;

//! Project version string for GXAppleMapsSDMaps_.
FOUNDATION_EXPORT const unsigned char GXAppleMapsSDMapsVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXAppleMapsSDMaps/PublicHeader.h>

#import <GXAppleMapsSDMaps/GXUC_MapKitList.h>
