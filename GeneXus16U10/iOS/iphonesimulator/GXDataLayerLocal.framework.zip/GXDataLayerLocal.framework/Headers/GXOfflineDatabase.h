//
//  GXOfflineDatabase.h
//  GXFlexibleClient
//
//  Created by Marcos Crispino on 26/02/14.
//  Copyright (c) 2014 Artech. All rights reserved.
//

@import GXStandardClasses;
#import <GXDataLayerLocal/GXSynchronizationJSONReader.h>

@interface GXOfflineDatabase : GXProcedure

@property (nonatomic, retain) GXSynchronizationJSONReader *jsonReader;

@property (nonatomic, strong, readonly) NSString *metadataStatusResponse;
@property (nonatomic, strong, readonly) NSString *metadataVersionString;
@property (nonatomic, strong, readonly) NSString *metadataSchemaVersionString;
@property (nonatomic, strong, readonly) NSString *metadataSyncCheckStatusResponse;
@property (nonatomic, strong, readonly) NSArray *tableHashes;

- (void)executeSynchronization;

- (void)addTableHashFromTableMetadata:(GXStringCollection *)tblMetadata;

@end
