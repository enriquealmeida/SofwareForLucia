//
//  GXEOWeChatInvoke.h
//  GXEOWeChatInvoke
//
//  Created by Marcos Crispino on 22/9/17.
//  Copyright © 2017 GeneXus. All rights reserved.
//

#import <Foundation/Foundation.h>
//! Project version number for GXEOWeChatInvoke.
FOUNDATION_EXPORT double GXEOWeChatInvokeVersionNumber;

//! Project version string for GXEOWeChatInvoke.
FOUNDATION_EXPORT const unsigned char GXEOWeChatInvokeVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GXEOWeChatInvoke/PublicHeader.h>


#if TARGET_OS_IOS || TARGET_OS_TV
#import <UIKit/UIKit.h>
#elif TARGET_OS_WATCH
#import <WatchKit/WatchKit.h>
#endif

#if TARGET_OS_IOS
#import <GXEOWeChatInvoke/GXWeChatHelper.h>
#endif
