/**
*    GXflow player plugin
*	 Version 1.0
*    Copyright (c) 2018 Genexus.
*
*/

var GXflowPlayer = Class.create({

	initialize: function(diagram) {

		this.diagram = diagram;
		
		var ImageSrc = new Array ("play","play_over","played","pause","pause_over", "paused", "stop","stop_over","stoped",
					  "stop_disabled", "start","start_over","started","end","end_over","ended","position",
					  "position_over","positioned","position_disabled","positionline");
										
		var ImageList = new Array();

		for (i=1; i < ImageSrc.length; i++) {
			ImageList[i] = new Image();
			ImageList[i].src = this.getImage(ImageSrc[i]);
		}		

		this.speed = 500;	
		this.labels = null;
		this.reset();
	},	
	
	reset: function(){
	
		this.state = "Paused";	

		document.images["play"].src = this.getImage("play");	
		document.images["stop"].src = this.getImage("stop_disabled");
		if (this.labels)
			document.images["play"].title = this.getLabel("PLAY");
		
	},
	
	getImage: function(image){
			var imagePath = window.GXflowResourcesURL;
			var imageExt  = ".gif";	
			return (imagePath + "wf_player_" + image + imageExt);	
	},	
	
	notifyEnd: function(){
		this.initialize();
	},		

	moveClip: function(){
		var e = document.getElementById("positionDiv");
		e.style.left = "30px";
	},	
	
	setLabels : function(array){
		this.labels = array;
	},
	
	getLabel: function(key){
		if (this.labels)
			return this.labels[key];
	},		
	
	onMouseOver: function(e){

		var e = e || window.event;
		var eSrc = e.target || e.srcElement;
		
		switch(eSrc.id){
		
			case "play":	{
						switch(this.state){
							case "Stopped":	{eSrc.src = this.getImage("play_over");}
									break;						
							case "Paused":	{eSrc.src = this.getImage("play_over");}
									break;
							case "Playing":	{eSrc.src = this.getImage("pause_over");}
									break;												
						}						
					}
					break;
							
			case "stop":	{
						switch(this.state){
							case "Playing":	{eSrc.src = this.getImage("stop_over");}
									break;					
						}						
					}
					break;
							
			case "start":	{
						eSrc.src = this.getImage("start_over");
					}
					break;

			case "end":	{
						eSrc.src = this.getImage("end_over");
					}
					break;

			case "position":	{
							switch(this.state){
								case "Playing":	{eSrc.src = this.getImage("position_over");}
										break;					
							}						
						}
						break;
		}
	},

	onMouseOut: function(e){

		var e = e || window.event;
		var eSrc = e.target || e.srcElement;
		
		switch(eSrc.id){
		
			case "play":	{
						switch(this.state){
							case "Stopped":	{eSrc.src = this.getImage("play");}
									break;						
							case "Paused":	{eSrc.src = this.getImage("play");}
									break;
							case "Playing":	{eSrc.src = this.getImage("pause");}
									break;												
						}						
					}
					break;
							
			case "stop":	{
						switch(this.state){
							case "Playing":	{eSrc.src = this.getImage("stop");}
									break;					
							}						
					}
					break;
							
			case "start":	{
						eSrc.src = this.getImage("start");
					}
					break;

			case "end":	{
						eSrc.src = this.getImage("end");
					}
					break;
				
		}
	},

	onMouseDown: function(e){

		var e = e || window.event;
		var eSrc = e.target || e.srcElement;
		
		switch(eSrc.id){
		
			case "play":	{
						switch(this.state){
							case "Stopped":	{eSrc.src = this.getImage("played");}
									break;						
							case "Paused":	{eSrc.src = this.getImage("played");}
									break;
							case "Playing":	{eSrc.src = this.getImage("paused");}
									break;												
						}						
					}
					break;
							
			case "stop":	{
						switch(this.state){
							case "Playing":	{eSrc.src = this.getImage("stoped");}
									break;					
						}						
					}
					break;
							
			case "start":	{
						eSrc.src = this.getImage("started");
					}
					break;

			case "end":	{
						eSrc.src = this.getImage("ended");
					}
					break;
				
		}
	},

	onClick: function(e){

		var e = e || window.event;
		var eSrc = e.target || e.srcElement;
		
		switch(eSrc.id){
		
			case "play":	{
						switch(this.state){
							case "Paused":	{
									this.state = "Playing";
									eSrc.src = this.getImage("pause_over");
									eSrc.title = this.getLabel("PAUSE");
									document.images["stop"].src = this.getImage("stop");
									this.diagram.startAnimation(this.speed, this.reset, this);
									}
									break;
							case "Playing":	{
									this.state = "Paused";
									eSrc.src = this.getImage("play_over");
									eSrc.title = this.getLabel("PLAY");
									this.diagram.pauseAnimation();
									}
									break;												
						}						
					}
					break;
							
			case "stop":	{
						switch(this.state){
							case "Playing":	{
									this.state = "Paused";
									eSrc.src = this.getImage("stop_over");
									this.diagram.stopAnimation();
									}
									break;	
						}
					}
					break;
							
			case "start":	{
						eSrc.src = this.getImage("start_over");
						this.diagram.resetAnimation();
					}
					break;

			case "end":	{
						eSrc.src = this.getImage("end_over");
						this.diagram.startAnimation(1, this.reset, this);
					}
					break;					
		}
	}
	
});