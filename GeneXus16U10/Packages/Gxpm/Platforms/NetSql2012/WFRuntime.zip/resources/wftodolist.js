/*!   GeneXus C# 16_0_10-142546 on 7/4/2020 15:43:47.98
*/
gx.evt.autoSkip = false;
gx.define('wftodolist', true, function (CmpContext) {
   this.ServerClass =  "wftodolist" ;
   this.PackageName =  "GXflow.Programs" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV16UsrSH=gx.fn.getControlValue("vUSRSH") ;
      this.AV7filter=gx.fn.getControlValue("vFILTER") ;
      this.AV8limit=gx.fn.getIntegerValue("vLIMIT",gx.thousandSeparator) ;
      this.AV6error=gx.fn.getIntegerValue("vERROR",gx.thousandSeparator) ;
   };
   this.e13192_client=function()
   {
      this.clearMessages();
      this.refreshOutputs([]);
      return gx.$.Deferred().resolve();
   };
   this.e14192_client=function()
   {
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e15192_client=function()
   {
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[5,8,9,12];
   this.GXLastCtrlId =12;
   this.GridContainer = new gx.grid.grid(this, 2,"WbpLvl2",2,"Grid","Grid","GridContainer",this.CmpContext,this.IsMasterPage,"wftodolist",[],true,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,false,false);
   var GridContainer = this.GridContainer;
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.startTable("Table1",5,"0px");
   GridContainer.addHtmlCode("<tbody>");
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addSingleLineEdit("Workitemid",8,"vWORKITEMID","","","workitemId","int",10,"chr",10,10,"right",null,[],"Workitemid","workitemId",true,0,false,false,"Attribute",1,"");
   GridContainer.addTextBlock('TXBSUBJECT',"e13192_client",9);
   GridContainer.endCell();
   GridContainer.endRow();
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addTextBlock('TXBPOINTS',null,12);
   GridContainer.endCell();
   GridContainer.endRow();
   GridContainer.addHtmlCode("</tbody>");
   GridContainer.endTable();
   GridContainer.endCell();
   GridContainer.endRow();
   this.GridContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridContainer);
   GXValidFnc[5]={ id: 5, fld:"TABLE1",grid:2};
   GXValidFnc[8]={ id:8 ,lvl:2,type:"int",len:10,dec:0,sign:false,pic:"ZZZZZZZZZ9",ro:0,isacc:0,grid:2,gxgrid:this.GridContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWORKITEMID",gxz:"ZV19workitemId",gxold:"OV19workitemId",gxvar:"AV19workitemId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV19workitemId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV19workitemId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vWORKITEMID",row || gx.fn.currentGridRowImpl(2),gx.O.AV19workitemId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV19workitemId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vWORKITEMID",row || gx.fn.currentGridRowImpl(2),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[9]={ id: 9, fld:"TXBSUBJECT", format:0,grid:2,evt:"e13192_client"};
   GXValidFnc[12]={ id: 12, fld:"TXBPOINTS", format:0,grid:2};
   this.ZV19workitemId = 0 ;
   this.OV19workitemId = 0 ;
   this.AV8limit = 0 ;
   this.AV19workitemId = 0 ;
   this.AV16UsrSH = "" ;
   this.AV7filter = {ProcessDefinitionId:0,ProcessDefinitionGUID:"",ProcessDefinitionName:"",ProcessDefinitionVersion:0,ActivityId:0,ActivityName:"",UserId:"",UserName:"",RoleId:0,ProcessInstanceId:0,Name:"",Description:"",CreatedFrom:gx.date.nullDate(),CreatedTo:gx.date.nullDate(),EndedFrom:gx.date.nullDate(),EndedTo:gx.date.nullDate(),UpdatedFrom:gx.date.nullDate(),UpdatedTo:gx.date.nullDate(),DeadlineFrom:gx.date.nullDate(),DeadlineTo:gx.date.nullDate(),From:gx.date.nullDate(),To:gx.date.nullDate(),Subject:"",Priority:0,State:"",Warning:"",Deadline:"",EventType:0,EventTarget:0,OutOfOffice:"",ApplicationData:[],Restrictions:[],ProcessDefinitionsNames:[],ActiveState:"",Application:"",DocumentTypeId:0,DocumentInstanceId:0,EdgeType:"",WorkitemId:0,ActionId:0,Author:"",Language:"",Query:"",FullTextQuery:"",Blocked:"",RestrictionName:"",RestrictionValue:"",Start:0,Limit:0,Version:0,Id:0,ActivityCls:"",Parent:0,Connected:0,States:[],Attributes:[],ObjectId:"",ObjectType:0,Trigger:0,ClientApp:"",LicenseType:0,LicenseStatus:0,LicenseRunLevel:0} ;
   this.AV6error = 0 ;
   this.Events = {"e14192_client": ["ENTER", true] ,"e15192_client": ["CANCEL", true] ,"e13192_client": ["'OPEN'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRID_nFirstRecordOnPage'},{av:'GRID_nEOF'},{av:'gx.fn.getCtrlProperty("vWORKITEMID","Visible")',ctrl:'vWORKITEMID',prop:'Visible'},{av:'AV8limit',fld:'vLIMIT',pic:'ZZZ9'},{av:'sPrefix'},{av:'AV16UsrSH',fld:'vUSRSH',pic:''},{av:'AV7filter',fld:'vFILTER',pic:''},{av:'AV6error',fld:'vERROR',pic:'ZZZ9'}],[]];
   this.EvtParms["START"] = [[],[{av:'AV16UsrSH',fld:'vUSRSH',pic:''},{av:'gx.fn.getCtrlProperty("TXBPOINTS_" + gx.currentRows[2],"Caption")',ctrl:'TXBPOINTS',prop:'Caption'},{av:'gx.fn.getCtrlProperty("vWORKITEMID","Visible")',ctrl:'vWORKITEMID',prop:'Visible'}]];
   this.EvtParms["GRID.LOAD"] = [[{av:'AV16UsrSH',fld:'vUSRSH',pic:''},{av:'AV7filter',fld:'vFILTER',pic:''},{av:'AV8limit',fld:'vLIMIT',pic:'ZZZ9'},{av:'AV6error',fld:'vERROR',pic:'ZZZ9'}],[{av:'AV6error',fld:'vERROR',pic:'ZZZ9'},{av:'AV19workitemId',fld:'vWORKITEMID',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TXBSUBJECT_" + gx.currentRows[2],"Caption")',ctrl:'TXBSUBJECT',prop:'Caption'}]];
   this.EvtParms["'OPEN'"] = [[],[]];
   this.setVCMap("AV16UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV7filter", "vFILTER", 0, "WFSDTFilter", 0, 0);
   this.setVCMap("AV8limit", "vLIMIT", 0, "int", 4, 0);
   this.setVCMap("AV6error", "vERROR", 0, "int", 4, 0);
   this.setVCMap("AV16UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV7filter", "vFILTER", 0, "WFSDTFilter", 0, 0);
   this.setVCMap("AV8limit", "vLIMIT", 0, "int", 4, 0);
   this.setVCMap("AV6error", "vERROR", 0, "int", 4, 0);
   GridContainer.addRefreshingVar({rfrVar:"AV19workitemId", rfrProp:"Visible", gxAttId:"Workitemid"});
   GridContainer.addRefreshingVar({rfrVar:"AV16UsrSH"});
   GridContainer.addRefreshingVar({rfrVar:"AV7filter"});
   GridContainer.addRefreshingVar({rfrVar:"AV8limit"});
   GridContainer.addRefreshingVar({rfrVar:"AV6error"});
   GridContainer.addRefreshingParm({rfrVar:"AV19workitemId", rfrProp:"Visible", gxAttId:"Workitemid"});
   GridContainer.addRefreshingParm({rfrVar:"AV16UsrSH"});
   GridContainer.addRefreshingParm({rfrVar:"AV7filter"});
   GridContainer.addRefreshingParm({rfrVar:"AV8limit"});
   GridContainer.addRefreshingParm({rfrVar:"AV6error"});
   this.Initialize( );
});
