/*!   GeneXus C# 16_0_10-142546 on 7/4/2020 15:43:47.31
*/
gx.evt.autoSkip = false;
gx.define('wfstartdeadlines', true, function (CmpContext) {
   this.ServerClass =  "wfstartdeadlines" ;
   this.PackageName =  "GXflow.Programs" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV8filter=gx.fn.getControlValue("vFILTER") ;
      this.AV18UsrSH=gx.fn.getControlValue("vUSRSH") ;
      this.AV10limit=gx.fn.getIntegerValue("vLIMIT",gx.thousandSeparator) ;
      this.AV7error=gx.fn.getIntegerValue("vERROR",gx.thousandSeparator) ;
   };
   this.e131a2_client=function()
   {
      this.clearMessages();
      this.refreshOutputs([]);
      return gx.$.Deferred().resolve();
   };
   this.e141a2_client=function()
   {
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e151a2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[6,9,10,13,16,19];
   this.GXLastCtrlId =19;
   this.GridContainer = new gx.grid.grid(this, 2,"WbpLvl2",3,"Grid","Grid","GridContainer",this.CmpContext,this.IsMasterPage,"wfstartdeadlines",[],true,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,false,false);
   var GridContainer = this.GridContainer;
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.startTable("Table1",6,"0px");
   GridContainer.addHtmlCode("<tbody>");
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addSingleLineEdit("Workitemid",9,"vWORKITEMID","","","workitemId","int",10,"chr",10,10,"right",null,[],"Workitemid","workitemId",true,0,false,false,"Attribute",1,"");
   GridContainer.startTable("Table2",10,"0px");
   GridContainer.addHtmlCode("<tbody>");
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addTextBlock('TXBSUBJECT',"e131a2_client",13);
   GridContainer.endCell();
   GridContainer.startCell("","","","","","","20px","","","");
   GridContainer.endCell();
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addTextBlock('TXBDEADLINE',null,16);
   GridContainer.endCell();
   GridContainer.endRow();
   GridContainer.addHtmlCode("</tbody>");
   GridContainer.endTable();
   GridContainer.endCell();
   GridContainer.endRow();
   GridContainer.startRow("","","","","","");
   GridContainer.startCell("","","","","","","","","","");
   GridContainer.addTextBlock('TXBPOINTS',null,19);
   GridContainer.endCell();
   GridContainer.endRow();
   GridContainer.addHtmlCode("</tbody>");
   GridContainer.endTable();
   GridContainer.endCell();
   GridContainer.endRow();
   this.GridContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridContainer);
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:3};
   GXValidFnc[9]={ id:9 ,lvl:2,type:"int",len:10,dec:0,sign:false,pic:"ZZZZZZZZZ9",ro:0,isacc:0,grid:3,gxgrid:this.GridContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vWORKITEMID",gxz:"ZV21workitemId",gxold:"OV21workitemId",gxvar:"AV21workitemId",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',v2v:function(Value){if(Value!==undefined)gx.O.AV21workitemId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV21workitemId=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vWORKITEMID",row || gx.fn.currentGridRowImpl(3),gx.O.AV21workitemId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV21workitemId=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vWORKITEMID",row || gx.fn.currentGridRowImpl(3),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[10]={ id: 10, fld:"TABLE2",grid:3};
   GXValidFnc[13]={ id: 13, fld:"TXBSUBJECT", format:0,grid:3,evt:"e131a2_client"};
   GXValidFnc[16]={ id: 16, fld:"TXBDEADLINE", format:0,grid:3};
   GXValidFnc[19]={ id: 19, fld:"TXBPOINTS", format:0,grid:3};
   this.ZV21workitemId = 0 ;
   this.OV21workitemId = 0 ;
   this.AV10limit = 0 ;
   this.AV21workitemId = 0 ;
   this.AV8filter = {ProcessDefinitionId:0,ProcessDefinitionGUID:"",ProcessDefinitionName:"",ProcessDefinitionVersion:0,ActivityId:0,ActivityName:"",UserId:"",UserName:"",RoleId:0,ProcessInstanceId:0,Name:"",Description:"",CreatedFrom:gx.date.nullDate(),CreatedTo:gx.date.nullDate(),EndedFrom:gx.date.nullDate(),EndedTo:gx.date.nullDate(),UpdatedFrom:gx.date.nullDate(),UpdatedTo:gx.date.nullDate(),DeadlineFrom:gx.date.nullDate(),DeadlineTo:gx.date.nullDate(),From:gx.date.nullDate(),To:gx.date.nullDate(),Subject:"",Priority:0,State:"",Warning:"",Deadline:"",EventType:0,EventTarget:0,OutOfOffice:"",ApplicationData:[],Restrictions:[],ProcessDefinitionsNames:[],ActiveState:"",Application:"",DocumentTypeId:0,DocumentInstanceId:0,EdgeType:"",WorkitemId:0,ActionId:0,Author:"",Language:"",Query:"",FullTextQuery:"",Blocked:"",RestrictionName:"",RestrictionValue:"",Start:0,Limit:0,Version:0,Id:0,ActivityCls:"",Parent:0,Connected:0,States:[],Attributes:[],ObjectId:"",ObjectType:0,Trigger:0,ClientApp:"",LicenseType:0,LicenseStatus:0,LicenseRunLevel:0} ;
   this.AV18UsrSH = "" ;
   this.AV7error = 0 ;
   this.Events = {"e141a2_client": ["ENTER", true] ,"e151a2_client": ["CANCEL", true] ,"e131a2_client": ["'OPEN'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRID_nFirstRecordOnPage'},{av:'GRID_nEOF'},{av:'gx.fn.getCtrlProperty("vWORKITEMID","Visible")',ctrl:'vWORKITEMID',prop:'Visible'},{av:'AV10limit',fld:'vLIMIT',pic:'ZZZ9'},{av:'sPrefix'},{av:'AV8filter',fld:'vFILTER',pic:''},{av:'AV18UsrSH',fld:'vUSRSH',pic:''},{av:'AV7error',fld:'vERROR',pic:'ZZZ9'}],[]];
   this.EvtParms["START"] = [[],[{av:'AV18UsrSH',fld:'vUSRSH',pic:''},{av:'gx.fn.getCtrlProperty("TXBPOINTS","Caption")',ctrl:'TXBPOINTS',prop:'Caption'},{av:'gx.fn.getCtrlProperty("vWORKITEMID","Visible")',ctrl:'vWORKITEMID',prop:'Visible'}]];
   this.EvtParms["GRID.LOAD"] = [[{av:'AV8filter',fld:'vFILTER',pic:''},{av:'AV18UsrSH',fld:'vUSRSH',pic:''},{av:'AV10limit',fld:'vLIMIT',pic:'ZZZ9'},{av:'AV7error',fld:'vERROR',pic:'ZZZ9'}],[{av:'AV8filter',fld:'vFILTER',pic:''},{av:'AV7error',fld:'vERROR',pic:'ZZZ9'},{av:'gx.fn.getCtrlProperty("TXBSUBJECT","Caption")',ctrl:'TXBSUBJECT',prop:'Caption'}]];
   this.EvtParms["'OPEN'"] = [[],[]];
   this.setVCMap("AV8filter", "vFILTER", 0, "WFSDTFilter", 0, 0);
   this.setVCMap("AV18UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV10limit", "vLIMIT", 0, "int", 4, 0);
   this.setVCMap("AV7error", "vERROR", 0, "int", 4, 0);
   this.setVCMap("AV8filter", "vFILTER", 0, "WFSDTFilter", 0, 0);
   this.setVCMap("AV18UsrSH", "vUSRSH", 0, "svchar", 200, 100);
   this.setVCMap("AV10limit", "vLIMIT", 0, "int", 4, 0);
   this.setVCMap("AV7error", "vERROR", 0, "int", 4, 0);
   GridContainer.addRefreshingVar({rfrVar:"AV21workitemId", rfrProp:"Visible", gxAttId:"Workitemid"});
   GridContainer.addRefreshingVar({rfrVar:"AV8filter"});
   GridContainer.addRefreshingVar({rfrVar:"AV18UsrSH"});
   GridContainer.addRefreshingVar({rfrVar:"AV10limit"});
   GridContainer.addRefreshingVar({rfrVar:"AV7error"});
   GridContainer.addRefreshingParm({rfrVar:"AV21workitemId", rfrProp:"Visible", gxAttId:"Workitemid"});
   GridContainer.addRefreshingParm({rfrVar:"AV8filter"});
   GridContainer.addRefreshingParm({rfrVar:"AV18UsrSH"});
   GridContainer.addRefreshingParm({rfrVar:"AV10limit"});
   GridContainer.addRefreshingParm({rfrVar:"AV7error"});
   this.Initialize( );
});
