/*!   GeneXus Java 16_0_10-142546 on July 4, 2020 15:59:32.62
*/
gx.evt.autoSkip = false;
gx.define('wfmyperformance', true, function (CmpContext) {
   this.ServerClass =  "wfmyperformance" ;
   this.PackageName =  "com.gxflow" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.Validv_From=function()
   {
      return this.validCliEvt("Validv_From", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vFROM");
         this.AnyError  = 0;
         if ( ! ( (new gx.date.gxdate('').compare(this.AV28from)===0) || new gx.date.gxdate( this.AV28from ).compare( gx.date.ymdtod( 1753, 1, 1) ) >= 0 ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "from"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e13162_client=function()
   {
      return this.executeServerEvent("VPROCESSGUID.CLICK", true, null, false, true);
   };
   this.e14162_client=function()
   {
      return this.executeServerEvent("VTASKGUID.CLICK", true, null, false, true);
   };
   this.e15162_client=function()
   {
      return this.executeServerEvent("VROLEID.CLICK", true, null, false, true);
   };
   this.e16162_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e18162_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[4,7,10,13,15,18,20,23,25,28,30,33,38,41,44,53,56];
   this.GXLastCtrlId =56;
   this.GXUI_PANEL2Container = gx.uc.getNew(this, 2, 0, "gxui.Panel", this.CmpContext + "GXUI_PANEL2Container", "Gxui_panel2", "GXUI_PANEL2");
   var GXUI_PANEL2Container = this.GXUI_PANEL2Container;
   GXUI_PANEL2Container.setProp("Class", "Class", "", "char");
   GXUI_PANEL2Container.setProp("Enabled", "Enabled", true, "boolean");
   GXUI_PANEL2Container.setProp("Width", "Width", 100, "num");
   GXUI_PANEL2Container.setProp("Height", "Height", 900, "num");
   GXUI_PANEL2Container.setProp("Draggable", "Draggable", "false", "str");
   GXUI_PANEL2Container.setProp("ShowAsWindow", "Showaswindow", false, "bool");
   GXUI_PANEL2Container.setProp("Layout", "Layout", "default", "str");
   GXUI_PANEL2Container.setProp("AddToParentGxUIControl", "Addtoparentgxuicontrol", true, "bool");
   GXUI_PANEL2Container.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GXUI_PANEL2Container.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GXUI_PANEL2Container.setProp("Visible", "Visible", true, "boolean");
   GXUI_PANEL2Container.setProp("Refresh", "Refresh", false, "boolean");
   GXUI_PANEL2Container.setProp("AutoWidth", "Autowidth", "true", "str");
   GXUI_PANEL2Container.setProp("AutoHeight", "Autoheight", "false", "str");
   GXUI_PANEL2Container.setProp("Title", "Title", gx.getMessage( "GXWF_My Performance"), "str");
   GXUI_PANEL2Container.setProp("IconCls", "Iconcls", "", "str");
   GXUI_PANEL2Container.setProp("Cls", "Cls", "", "str");
   GXUI_PANEL2Container.setProp("Frame", "Frame", "true", "str");
   GXUI_PANEL2Container.setProp("Border", "Border", true, "bool");
   GXUI_PANEL2Container.setProp("Modal", "Modal", false, "bool");
   GXUI_PANEL2Container.setProp("UseToolbar", "Usetoolbar", "false", "str");
   GXUI_PANEL2Container.addV2CFunction('AV32gxuiToolbar', "vGXUITOOLBAR", 'SetToolbarData');
   GXUI_PANEL2Container.addC2VFunction(function(UC) { UC.ParentObject.AV32gxuiToolbar=UC.GetToolbarData();gx.fn.setControlValue("vGXUITOOLBAR",UC.ParentObject.AV32gxuiToolbar); });
   GXUI_PANEL2Container.setProp("Resizable", "Resizable", "false", "str");
   GXUI_PANEL2Container.setProp("MinWidth", "Minwidth", 100, "num");
   GXUI_PANEL2Container.setProp("MaxWidth", "Maxwidth", 800, "num");
   GXUI_PANEL2Container.setProp("MinHeight", "Minheight", 100, "num");
   GXUI_PANEL2Container.setProp("MaxHeight", "Maxheight", 600, "num");
   GXUI_PANEL2Container.setProp("Pinned", "Pinned", "true", "str");
   GXUI_PANEL2Container.setProp("Handles", "Handles", "s e se", "str");
   GXUI_PANEL2Container.setProp("Collapsible", "Collapsible", "false", "str");
   GXUI_PANEL2Container.setProp("Collapsed", "Collapsed", "false", "str");
   GXUI_PANEL2Container.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GXUI_PANEL2Container.setProp("Stateful", "Stateful", "true", "str");
   GXUI_PANEL2Container.setProp("StateId", "Stateid", "", "str");
   GXUI_PANEL2Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(GXUI_PANEL2Container);
   this.GXUI_PANEL3Container = gx.uc.getNew(this, 8, 0, "gxui.Panel", this.CmpContext + "GXUI_PANEL3Container", "Gxui_panel3", "GXUI_PANEL3");
   var GXUI_PANEL3Container = this.GXUI_PANEL3Container;
   GXUI_PANEL3Container.setProp("Class", "Class", "", "char");
   GXUI_PANEL3Container.setProp("Enabled", "Enabled", true, "boolean");
   GXUI_PANEL3Container.setProp("Width", "Width", 100, "num");
   GXUI_PANEL3Container.setProp("Height", "Height", 100, "num");
   GXUI_PANEL3Container.setProp("Draggable", "Draggable", "false", "str");
   GXUI_PANEL3Container.setProp("ShowAsWindow", "Showaswindow", false, "bool");
   GXUI_PANEL3Container.setProp("Layout", "Layout", "default", "str");
   GXUI_PANEL3Container.setProp("AddToParentGxUIControl", "Addtoparentgxuicontrol", true, "bool");
   GXUI_PANEL3Container.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GXUI_PANEL3Container.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GXUI_PANEL3Container.setProp("Visible", "Visible", true, "boolean");
   GXUI_PANEL3Container.setProp("Refresh", "Refresh", false, "boolean");
   GXUI_PANEL3Container.setProp("AutoWidth", "Autowidth", "true", "str");
   GXUI_PANEL3Container.setProp("AutoHeight", "Autoheight", "true", "str");
   GXUI_PANEL3Container.setProp("Title", "Title", "", "str");
   GXUI_PANEL3Container.setProp("IconCls", "Iconcls", "", "str");
   GXUI_PANEL3Container.setProp("Cls", "Cls", "", "str");
   GXUI_PANEL3Container.setProp("Frame", "Frame", "false", "str");
   GXUI_PANEL3Container.setProp("Border", "Border", true, "bool");
   GXUI_PANEL3Container.setProp("Modal", "Modal", false, "bool");
   GXUI_PANEL3Container.setProp("UseToolbar", "Usetoolbar", "false", "str");
   GXUI_PANEL3Container.addV2CFunction('AV32gxuiToolbar', "vGXUITOOLBAR", 'SetToolbarData');
   GXUI_PANEL3Container.addC2VFunction(function(UC) { UC.ParentObject.AV32gxuiToolbar=UC.GetToolbarData();gx.fn.setControlValue("vGXUITOOLBAR",UC.ParentObject.AV32gxuiToolbar); });
   GXUI_PANEL3Container.setProp("Resizable", "Resizable", "false", "str");
   GXUI_PANEL3Container.setProp("MinWidth", "Minwidth", 100, "num");
   GXUI_PANEL3Container.setProp("MaxWidth", "Maxwidth", 800, "num");
   GXUI_PANEL3Container.setProp("MinHeight", "Minheight", 100, "num");
   GXUI_PANEL3Container.setProp("MaxHeight", "Maxheight", 600, "num");
   GXUI_PANEL3Container.setProp("Pinned", "Pinned", "true", "str");
   GXUI_PANEL3Container.setProp("Handles", "Handles", "s e se", "str");
   GXUI_PANEL3Container.setProp("Collapsible", "Collapsible", "false", "str");
   GXUI_PANEL3Container.setProp("Collapsed", "Collapsed", "false", "str");
   GXUI_PANEL3Container.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GXUI_PANEL3Container.setProp("Stateful", "Stateful", "true", "str");
   GXUI_PANEL3Container.setProp("StateId", "Stateid", "", "str");
   GXUI_PANEL3Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(GXUI_PANEL3Container);
   this.GXUI_PANEL1Container = gx.uc.getNew(this, 36, 15, "gxui.Panel", this.CmpContext + "GXUI_PANEL1Container", "Gxui_panel1", "GXUI_PANEL1");
   var GXUI_PANEL1Container = this.GXUI_PANEL1Container;
   GXUI_PANEL1Container.setProp("Class", "Class", "", "char");
   GXUI_PANEL1Container.setProp("Enabled", "Enabled", true, "boolean");
   GXUI_PANEL1Container.setProp("Width", "Width", 100, "num");
   GXUI_PANEL1Container.setProp("Height", "Height", 100, "num");
   GXUI_PANEL1Container.setProp("Draggable", "Draggable", "true", "str");
   GXUI_PANEL1Container.setProp("ShowAsWindow", "Showaswindow", false, "bool");
   GXUI_PANEL1Container.setProp("Layout", "Layout", "default", "str");
   GXUI_PANEL1Container.setProp("AddToParentGxUIControl", "Addtoparentgxuicontrol", true, "bool");
   GXUI_PANEL1Container.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GXUI_PANEL1Container.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GXUI_PANEL1Container.setProp("Visible", "Visible", true, "boolean");
   GXUI_PANEL1Container.setProp("Refresh", "Refresh", false, "boolean");
   GXUI_PANEL1Container.setProp("AutoWidth", "Autowidth", "true", "str");
   GXUI_PANEL1Container.setProp("AutoHeight", "Autoheight", "true", "str");
   GXUI_PANEL1Container.setProp("Title", "Title", gx.getMessage( "GXWF_My Performance"), "str");
   GXUI_PANEL1Container.setProp("IconCls", "Iconcls", "", "str");
   GXUI_PANEL1Container.setProp("Cls", "Cls", "", "str");
   GXUI_PANEL1Container.setProp("Frame", "Frame", "true", "str");
   GXUI_PANEL1Container.setProp("Border", "Border", true, "bool");
   GXUI_PANEL1Container.setProp("Modal", "Modal", false, "bool");
   GXUI_PANEL1Container.setProp("UseToolbar", "Usetoolbar", "false", "str");
   GXUI_PANEL1Container.addV2CFunction('AV32gxuiToolbar', "vGXUITOOLBAR", 'SetToolbarData');
   GXUI_PANEL1Container.addC2VFunction(function(UC) { UC.ParentObject.AV32gxuiToolbar=UC.GetToolbarData();gx.fn.setControlValue("vGXUITOOLBAR",UC.ParentObject.AV32gxuiToolbar); });
   GXUI_PANEL1Container.setProp("Resizable", "Resizable", "false", "str");
   GXUI_PANEL1Container.setProp("MinWidth", "Minwidth", 100, "num");
   GXUI_PANEL1Container.setProp("MaxWidth", "Maxwidth", 800, "num");
   GXUI_PANEL1Container.setProp("MinHeight", "Minheight", 100, "num");
   GXUI_PANEL1Container.setProp("MaxHeight", "Maxheight", 600, "num");
   GXUI_PANEL1Container.setProp("Pinned", "Pinned", "true", "str");
   GXUI_PANEL1Container.setProp("Handles", "Handles", "s e se", "str");
   GXUI_PANEL1Container.setProp("Collapsible", "Collapsible", "false", "str");
   GXUI_PANEL1Container.setProp("Collapsed", "Collapsed", "false", "str");
   GXUI_PANEL1Container.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GXUI_PANEL1Container.setProp("Stateful", "Stateful", "true", "str");
   GXUI_PANEL1Container.setProp("StateId", "Stateid", "", "str");
   GXUI_PANEL1Container.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(GXUI_PANEL1Container);
   this.MYPERFORMANCEContainer = gx.uc.getNew(this, 47, 15, "QueryViewer", this.CmpContext + "MYPERFORMANCEContainer", "Myperformance", "MYPERFORMANCE");
   var MYPERFORMANCEContainer = this.MYPERFORMANCEContainer;
   MYPERFORMANCEContainer.setProp("Enabled", "Enabled", true, "boolean");
   MYPERFORMANCEContainer.setProp("ObjectId", "Objectid", "12", "str");
   MYPERFORMANCEContainer.setProp("ObjectType", "Objecttype", "Query", "str");
   MYPERFORMANCEContainer.setProp("QueryInfo", "Queryinfo", "", "char");
   MYPERFORMANCEContainer.setProp("IsExternalQuery", "Isexternalquery", false, "boolean");
   MYPERFORMANCEContainer.setProp("ExternalQueryResult", "Externalqueryresult", "", "char");
   MYPERFORMANCEContainer.setProp("ObjectInfo", "Objectinfo", "", "char");
   MYPERFORMANCEContainer.addV2CFunction('AV59MyPerformanceAxes', "vMYPERFORMANCEAXES", 'SetAxes');
   MYPERFORMANCEContainer.addC2VFunction(function(UC) { UC.ParentObject.AV59MyPerformanceAxes=UC.GetAxes();gx.fn.setControlValue("vMYPERFORMANCEAXES",UC.ParentObject.AV59MyPerformanceAxes); });
   MYPERFORMANCEContainer.setProp("AllowChangeAxesOrder", "Allowchangeaxesorder", false, "bool");
   MYPERFORMANCEContainer.addV2CFunction('AV39Parameters', "vPARAMETERS", 'SetParameters');
   MYPERFORMANCEContainer.addC2VFunction(function(UC) { UC.ParentObject.AV39Parameters=UC.GetParameters();gx.fn.setControlValue("vPARAMETERS",UC.ParentObject.AV39Parameters); });
   MYPERFORMANCEContainer.setProp("ObjectName", "Objectname", "WFUserPerformanceVsTeamAverage", "str");
   MYPERFORMANCEContainer.setProp("Object", "Objectcall", "", "str");
   MYPERFORMANCEContainer.setProp("Class", "Class", "QueryViewer", "str");
   MYPERFORMANCEContainer.setProp("ShrinkToFit", "Shrinktofit", false, "boolean");
   MYPERFORMANCEContainer.setProp("AutoResize", "Autoresize", false, "boolean");
   MYPERFORMANCEContainer.setProp("AutoResizeType", "Autoresizetype", "", "char");
   MYPERFORMANCEContainer.setProp("Width", "Width", "300px", "str");
   MYPERFORMANCEContainer.setProp("Height", "Height", "300px", "str");
   MYPERFORMANCEContainer.setProp("Axes Selectors", "Showaxesselectors", "", "char");
   MYPERFORMANCEContainer.setProp("FontFamily", "Fontfamily", "", "char");
   MYPERFORMANCEContainer.setProp("FontSize", "Fontsize", '', "int");
   MYPERFORMANCEContainer.setProp("FontColor", "Fontcolor", '', "int");
   MYPERFORMANCEContainer.setProp("AutoRefreshGroup", "Autorefreshgroup", "", "str");
   MYPERFORMANCEContainer.setProp("DisableColumnSort", "Disablecolumnsort", false, "boolean");
   MYPERFORMANCEContainer.setProp("AllowSelection", "Allowselection", false, "bool");
   MYPERFORMANCEContainer.setProp("RememberLayout", "Rememberlayout", true, "bool");
   MYPERFORMANCEContainer.setProp("ExportToXML", "Exporttoxml", true, "bool");
   MYPERFORMANCEContainer.setProp("ExportToHTML", "Exporttohtml", true, "bool");
   MYPERFORMANCEContainer.setProp("ExportToXLS", "Exporttoxls", true, "bool");
   MYPERFORMANCEContainer.setProp("ExportToXLSX", "Exporttoxlsx", true, "bool");
   MYPERFORMANCEContainer.setProp("ExportToPDF", "Exporttopdf", true, "bool");
   MYPERFORMANCEContainer.setProp("Type", "Type", "Chart", "str");
   MYPERFORMANCEContainer.setProp("ShowDataAs", "Showdataas", "", "char");
   MYPERFORMANCEContainer.setProp("Orientation", "Orientation", "", "char");
   MYPERFORMANCEContainer.setProp("IncludeTrend", "Includetrend", false, "boolean");
   MYPERFORMANCEContainer.setProp("TrendPeriod", "Trendperiod", "", "char");
   MYPERFORMANCEContainer.setProp("IncludeSparkline", "Includesparkline", false, "boolean");
   MYPERFORMANCEContainer.setProp("IncludeMaxAndMin", "Includemaxandmin", false, "boolean");
   MYPERFORMANCEContainer.setProp("ChartType", "Charttype", "Column", "str");
   MYPERFORMANCEContainer.setProp("Title", "Title", "", "str");
   MYPERFORMANCEContainer.setProp("PlotSeries", "Plotseries", "InTheSameChart", "str");
   MYPERFORMANCEContainer.setProp("ShowValues", "Showvalues", true, "bool");
   MYPERFORMANCEContainer.setProp("XAxisLabels", "Xaxislabels", "Horizontally", "str");
   MYPERFORMANCEContainer.setProp("XAxisIntersectionAtZero", "Xaxisintersectionatzero", false, "bool");
   MYPERFORMANCEContainer.setProp("XAxisTitle", "Xaxistitle", "", "str");
   MYPERFORMANCEContainer.setProp("YAxisTitle", "Yaxistitle", "", "str");
   MYPERFORMANCEContainer.setProp("Paging", "Paging", false, "boolean");
   MYPERFORMANCEContainer.setProp("PageSize", "Pagesize", '', "int");
   MYPERFORMANCEContainer.setProp("CurrentPage", "Currentpage", '', "int");
   MYPERFORMANCEContainer.setProp("ShowDataLabelsIn", "Showdatalabelsin", "", "char");
   MYPERFORMANCEContainer.setProp("ItemClickData", "Itemclickdata", '', "str");
   MYPERFORMANCEContainer.setProp("ItemDoubleClickData", "Itemdoubleclickdata", '', "str");
   MYPERFORMANCEContainer.setProp("DragAndDropData", "Draganddropdata", '', "str");
   MYPERFORMANCEContainer.setProp("FilterChangedData", "Filterchangeddata", '', "str");
   MYPERFORMANCEContainer.setProp("ItemExpandData", "Itemexpanddata", '', "str");
   MYPERFORMANCEContainer.setProp("ItemCollapseData", "Itemcollapsedata", '', "str");
   MYPERFORMANCEContainer.setProp("AppSettings", "Appsettings", "", "char");
   MYPERFORMANCEContainer.setProp("AvoidAutomaticShow", "Avoidautomaticshow", false, "boolean");
   MYPERFORMANCEContainer.setProp("ExecuteShow", "Executeshow", false, "boolean");
   MYPERFORMANCEContainer.setProp("ServiceUrl", "Serviceurl", "", "char");
   MYPERFORMANCEContainer.setProp("GenType", "Gentype", "", "char");
   MYPERFORMANCEContainer.setProp("DesignRenderOutputType", "Designrenderoutputtype", "", "char");
   MYPERFORMANCEContainer.setProp("Visible", "Visible", true, "bool");
   MYPERFORMANCEContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(MYPERFORMANCEContainer);
   this.MYPERFORMANCETRENDContainer = gx.uc.getNew(this, 50, 15, "QueryViewer", this.CmpContext + "MYPERFORMANCETRENDContainer", "Myperformancetrend", "MYPERFORMANCETREND");
   var MYPERFORMANCETRENDContainer = this.MYPERFORMANCETRENDContainer;
   MYPERFORMANCETRENDContainer.setProp("Enabled", "Enabled", true, "boolean");
   MYPERFORMANCETRENDContainer.setProp("ObjectId", "Objectid", "13", "str");
   MYPERFORMANCETRENDContainer.setProp("ObjectType", "Objecttype", "Query", "str");
   MYPERFORMANCETRENDContainer.setProp("QueryInfo", "Queryinfo", "", "char");
   MYPERFORMANCETRENDContainer.setProp("IsExternalQuery", "Isexternalquery", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("ExternalQueryResult", "Externalqueryresult", "", "char");
   MYPERFORMANCETRENDContainer.setProp("ObjectInfo", "Objectinfo", "", "char");
   MYPERFORMANCETRENDContainer.addV2CFunction('AV60MyPerformanceTrendAxes', "vMYPERFORMANCETRENDAXES", 'SetAxes');
   MYPERFORMANCETRENDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV60MyPerformanceTrendAxes=UC.GetAxes();gx.fn.setControlValue("vMYPERFORMANCETRENDAXES",UC.ParentObject.AV60MyPerformanceTrendAxes); });
   MYPERFORMANCETRENDContainer.setProp("AllowChangeAxesOrder", "Allowchangeaxesorder", false, "bool");
   MYPERFORMANCETRENDContainer.addV2CFunction('AV39Parameters', "vPARAMETERS", 'SetParameters');
   MYPERFORMANCETRENDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV39Parameters=UC.GetParameters();gx.fn.setControlValue("vPARAMETERS",UC.ParentObject.AV39Parameters); });
   MYPERFORMANCETRENDContainer.setProp("ObjectName", "Objectname", "WFUserPerformanceTrend", "str");
   MYPERFORMANCETRENDContainer.setProp("Object", "Objectcall", "", "str");
   MYPERFORMANCETRENDContainer.setProp("Class", "Class", "QueryViewer", "str");
   MYPERFORMANCETRENDContainer.setProp("ShrinkToFit", "Shrinktofit", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("AutoResize", "Autoresize", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("AutoResizeType", "Autoresizetype", "", "char");
   MYPERFORMANCETRENDContainer.setProp("Width", "Width", "600px", "str");
   MYPERFORMANCETRENDContainer.setProp("Height", "Height", "300px", "str");
   MYPERFORMANCETRENDContainer.setProp("Axes Selectors", "Showaxesselectors", "", "char");
   MYPERFORMANCETRENDContainer.setProp("FontFamily", "Fontfamily", "", "char");
   MYPERFORMANCETRENDContainer.setProp("FontSize", "Fontsize", '', "int");
   MYPERFORMANCETRENDContainer.setProp("FontColor", "Fontcolor", '', "int");
   MYPERFORMANCETRENDContainer.setProp("AutoRefreshGroup", "Autorefreshgroup", "", "str");
   MYPERFORMANCETRENDContainer.setProp("DisableColumnSort", "Disablecolumnsort", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("AllowSelection", "Allowselection", false, "bool");
   MYPERFORMANCETRENDContainer.setProp("RememberLayout", "Rememberlayout", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("ExportToXML", "Exporttoxml", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("ExportToHTML", "Exporttohtml", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("ExportToXLS", "Exporttoxls", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("ExportToXLSX", "Exporttoxlsx", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("ExportToPDF", "Exporttopdf", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("Type", "Type", "Chart", "str");
   MYPERFORMANCETRENDContainer.setProp("ShowDataAs", "Showdataas", "", "char");
   MYPERFORMANCETRENDContainer.setProp("Orientation", "Orientation", "", "char");
   MYPERFORMANCETRENDContainer.setProp("IncludeTrend", "Includetrend", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("TrendPeriod", "Trendperiod", "", "char");
   MYPERFORMANCETRENDContainer.setProp("IncludeSparkline", "Includesparkline", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("IncludeMaxAndMin", "Includemaxandmin", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("ChartType", "Charttype", "Line", "str");
   MYPERFORMANCETRENDContainer.setProp("Title", "Title", "", "str");
   MYPERFORMANCETRENDContainer.setProp("PlotSeries", "Plotseries", "InTheSameChart", "str");
   MYPERFORMANCETRENDContainer.setProp("ShowValues", "Showvalues", true, "bool");
   MYPERFORMANCETRENDContainer.setProp("XAxisLabels", "Xaxislabels", "Horizontally", "str");
   MYPERFORMANCETRENDContainer.setProp("XAxisIntersectionAtZero", "Xaxisintersectionatzero", false, "bool");
   MYPERFORMANCETRENDContainer.setDynProp("XAxisTitle", "Xaxistitle", "", "str");
   MYPERFORMANCETRENDContainer.setDynProp("YAxisTitle", "Yaxistitle", "", "str");
   MYPERFORMANCETRENDContainer.setProp("Paging", "Paging", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("PageSize", "Pagesize", '', "int");
   MYPERFORMANCETRENDContainer.setProp("CurrentPage", "Currentpage", '', "int");
   MYPERFORMANCETRENDContainer.setProp("ShowDataLabelsIn", "Showdatalabelsin", "", "char");
   MYPERFORMANCETRENDContainer.setProp("ItemClickData", "Itemclickdata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("ItemDoubleClickData", "Itemdoubleclickdata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("DragAndDropData", "Draganddropdata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("FilterChangedData", "Filterchangeddata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("ItemExpandData", "Itemexpanddata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("ItemCollapseData", "Itemcollapsedata", '', "str");
   MYPERFORMANCETRENDContainer.setProp("AppSettings", "Appsettings", "", "char");
   MYPERFORMANCETRENDContainer.setProp("AvoidAutomaticShow", "Avoidautomaticshow", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("ExecuteShow", "Executeshow", false, "boolean");
   MYPERFORMANCETRENDContainer.setProp("ServiceUrl", "Serviceurl", "", "char");
   MYPERFORMANCETRENDContainer.setProp("GenType", "Gentype", "", "char");
   MYPERFORMANCETRENDContainer.setProp("DesignRenderOutputType", "Designrenderoutputtype", "", "char");
   MYPERFORMANCETRENDContainer.setProp("Visible", "Visible", true, "bool");
   MYPERFORMANCETRENDContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(MYPERFORMANCETRENDContainer);
   GXValidFnc[4]={ id: 4, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"TABLE9",grid:0};
   GXValidFnc[10]={ id: 10, fld:"TABLE3",grid:0};
   GXValidFnc[13]={ id: 13, fld:"TEXTBLOCK5", format:0,grid:0};
   GXValidFnc[15]={ id:15 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPROCESSGUID",gxz:"ZV61processGUID",gxold:"OV61processGUID",gxvar:"AV61processGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV61processGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV61processGUID=Value},v2c:function(){gx.fn.setComboBoxValue("vPROCESSGUID",gx.O.AV61processGUID);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV61processGUID=this.val()},val:function(){return gx.fn.getControlValue("vPROCESSGUID")},nac:gx.falseFn,evt:"e13162_client"};
   this.declareDomainHdlr( 15 , function() {
   });
   GXValidFnc[18]={ id: 18, fld:"TEXTBLOCK41", format:0,grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vTASKGUID",gxz:"ZV62taskGUID",gxold:"OV62taskGUID",gxvar:"AV62taskGUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV62taskGUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV62taskGUID=Value},v2c:function(){gx.fn.setComboBoxValue("vTASKGUID",gx.O.AV62taskGUID);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV62taskGUID=this.val()},val:function(){return gx.fn.getControlValue("vTASKGUID")},nac:gx.falseFn,evt:"e14162_client"};
   this.declareDomainHdlr( 20 , function() {
   });
   GXValidFnc[23]={ id: 23, fld:"TXBROLE", format:0,grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"int",len:6,dec:0,sign:true,pic:"ZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vROLEID",gxz:"ZV45roleId",gxold:"OV45roleId",gxvar:"AV45roleId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV45roleId=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV45roleId=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vROLEID",gx.O.AV45roleId);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV45roleId=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator)},nac:gx.falseFn,evt:"e15162_client"};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[28]={ id: 28, fld:"TEXTBLOCK7", format:0,grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"date",len:8,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_From,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFROM",gxz:"ZV28from",gxold:"OV28from",gxvar:"AV28from",dp:{f:0,st:false,wn:false,mf:false,pic:"99/99/99",dec:0},ucs:[],op:[30],ip:[30],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV28from=gx.fn.toDatetimeValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV28from=gx.fn.toDatetimeValue(Value)},v2c:function(){gx.fn.setControlValue("vFROM",gx.O.AV28from,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV28from=gx.fn.toDatetimeValue(this.val())},val:function(){return gx.fn.getControlValue("vFROM")},nac:gx.falseFn};
   GXValidFnc[33]={ id: 33, fld:"BUTTON1",grid:0,evt:"e16162_client",std:"ENTER"};
   GXValidFnc[38]={ id: 38, fld:"TABLE2",grid:0};
   GXValidFnc[41]={ id: 41, fld:"TEXTBLOCK3", format:0,grid:0};
   GXValidFnc[44]={ id: 44, fld:"TEXTBLOCK4", format:0,grid:0};
   GXValidFnc[53]={ id: 53, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[56]={ id: 56, fld:"TEXTBLOCK2", format:0,grid:0};
   this.AV61processGUID = "" ;
   this.ZV61processGUID = "" ;
   this.OV61processGUID = "" ;
   this.AV62taskGUID = "" ;
   this.ZV62taskGUID = "" ;
   this.OV62taskGUID = "" ;
   this.AV45roleId = 0 ;
   this.ZV45roleId = 0 ;
   this.OV45roleId = 0 ;
   this.AV28from = gx.date.nullDate() ;
   this.ZV28from = gx.date.nullDate() ;
   this.OV28from = gx.date.nullDate() ;
   this.AV61processGUID = "" ;
   this.AV62taskGUID = "" ;
   this.AV45roleId = 0 ;
   this.AV28from = gx.date.nullDate() ;
   this.AV32gxuiToolbar = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.AV59MyPerformanceAxes = [ ] ;
   this.AV60MyPerformanceTrendAxes = [ ] ;
   this.Events = {"e13162_client": ["VPROCESSGUID.CLICK", true] ,"e14162_client": ["VTASKGUID.CLICK", true] ,"e15162_client": ["VROLEID.CLICK", true] ,"e16162_client": ["ENTER", true] ,"e18162_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV56UsrCod',fld:'vUSRCOD',pic:'@!'},{ctrl:'vPROCESSGUID'},{av:'AV61processGUID',fld:'vPROCESSGUID',pic:''},{ctrl:'vTASKGUID'},{av:'AV62taskGUID',fld:'vTASKGUID',pic:''},{av:'AV28from',fld:'vFROM',pic:''},{av:'Gx_date',fld:'vTODAY',pic:''},{av:'AV59MyPerformanceAxes',fld:'vMYPERFORMANCEAXES',pic:''},{av:'AV60MyPerformanceTrendAxes',fld:'vMYPERFORMANCETRENDAXES',pic:''},{av:'AV26filter',fld:'vFILTER',pic:''},{av:'AV57UsrSH',fld:'vUSRSH',pic:''},{av:'AV37order',fld:'vORDER',pic:''}],[{av:'AV39Parameters',fld:'vPARAMETERS',pic:''},{av:'AV59MyPerformanceAxes',fld:'vMYPERFORMANCEAXES',pic:''},{av:'AV60MyPerformanceTrendAxes',fld:'vMYPERFORMANCETRENDAXES',pic:''},{av:'AV26filter',fld:'vFILTER',pic:''},{ctrl:'vPROCESSGUID'},{av:'AV61processGUID',fld:'vPROCESSGUID',pic:''},{ctrl:'vTASKGUID'},{av:'AV62taskGUID',fld:'vTASKGUID',pic:''}]];
   this.EvtParms["START"] = [[{av:'Gx_date',fld:'vTODAY',pic:''}],[{av:'AV57UsrSH',fld:'vUSRSH',pic:''},{av:'AV56UsrCod',fld:'vUSRCOD',pic:'@!'},{av:'gx.fn.getCtrlProperty("TXBROLE","Visible")',ctrl:'TXBROLE',prop:'Visible'},{ctrl:'vROLEID'},{av:'AV28from',fld:'vFROM',pic:''},{av:'this.MYPERFORMANCETRENDContainer.XAxisTitle',ctrl:'MYPERFORMANCETREND',prop:'XAxisTitle'},{av:'this.MYPERFORMANCETRENDContainer.YAxisTitle',ctrl:'MYPERFORMANCETREND',prop:'YAxisTitle'}]];
   this.EvtParms["VPROCESSGUID.CLICK"] = [[],[]];
   this.EvtParms["VTASKGUID.CLICK"] = [[],[]];
   this.EvtParms["VROLEID.CLICK"] = [[],[]];
   this.EvtParms["ENTER"] = [[],[]];
   this.EvtParms["VALIDV_FROM"] = [[],[]];
   this.EnterCtrl = ["BUTTON1"];
   this.Initialize( );
});
