/*!   GeneXus Java 16_0_10-142546 on July 4, 2020 15:59:26.99
*/
gx.evt.autoSkip = false;
gx.define('wflicenses', true, function (CmpContext) {
   this.ServerClass =  "wflicenses" ;
   this.PackageName =  "com.gxflow" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.s212_client=function()
   {
      this.AV40refreshNow =  true  ;
      gx.fn.setCtrlProperty("vREFRESHGRID","Visible", 0 );
   };
   this.s122_client=function()
   {
      if ( ( this.AV39refreshGrid == true ) && ( this.AV40refreshNow == true ) )
      {
         this.s222_client();
         this.AV39refreshGrid =  false  ;
      }
   };
   this.s222_client=function()
   {
      this.GRIDLICENSESContainer.Refresh() ;
   };
   this.e124n2_client=function()
   {
      return this.executeServerEvent("GRIDLICENSES.LOADEXCEPTION", false, null, true, true);
   };
   this.e114n2_client=function()
   {
      return this.executeServerEvent("GRIDLICENSES.BUTTONPRESSED", false, null, true, true);
   };
   this.e164n2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e174n2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[4,6];
   this.GXLastCtrlId =6;
   this.GRIDLICENSESContainer = gx.uc.getNew(this, 3, 0, "gxui.Grid", this.CmpContext + "GRIDLICENSESContainer", "Gridlicenses", "GRIDLICENSES");
   var GRIDLICENSESContainer = this.GRIDLICENSESContainer;
   GRIDLICENSESContainer.setProp("Class", "Class", "", "char");
   GRIDLICENSESContainer.setProp("Enabled", "Enabled", true, "boolean");
   GRIDLICENSESContainer.setProp("Width", "Width", 100, "num");
   GRIDLICENSESContainer.setProp("Height", "Height", 100, "num");
   GRIDLICENSESContainer.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GRIDLICENSESContainer.setProp("LoadExceptionError", "Loadexceptionerror", "", "char");
   GRIDLICENSESContainer.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GRIDLICENSESContainer.setProp("AutoWidth", "Autowidth", "false", "str");
   GRIDLICENSESContainer.setProp("AutoHeight", "Autoheight", "false", "str");
   GRIDLICENSESContainer.setProp("ForceFit", "Forcefit", "true", "str");
   GRIDLICENSESContainer.setProp("AutoExpandColumn", "Autoexpandcolumn", "", "str");
   GRIDLICENSESContainer.setProp("Title", "Title", "", "str");
   GRIDLICENSESContainer.setProp("IconCls", "Iconcls", "", "str");
   GRIDLICENSESContainer.setProp("Cls", "Cls", "", "str");
   GRIDLICENSESContainer.setProp("Frame", "Frame", "false", "str");
   GRIDLICENSESContainer.setProp("StripeRows", "Striperows", "true", "str");
   GRIDLICENSESContainer.setProp("UseToolbar", "Usetoolbar", "true", "str");
   GRIDLICENSESContainer.addV2CFunction('AV67toolbarLicenses', "vTOOLBARLICENSES", 'SetToolbarData');
   GRIDLICENSESContainer.addC2VFunction(function(UC) { UC.ParentObject.AV67toolbarLicenses=UC.GetToolbarData();gx.fn.setControlValue("vTOOLBARLICENSES",UC.ParentObject.AV67toolbarLicenses); });
   GRIDLICENSESContainer.setProp("AddSearchField", "Addsearchfield", "true", "str");
   GRIDLICENSESContainer.setProp("SearchFieldWidth", "Searchfieldwidth", 200, "num");
   GRIDLICENSESContainer.setProp("SearchFieldAutoRefresh", "Searchfieldautorefresh", true, "bool");
   GRIDLICENSESContainer.setProp("SearchFieldAutoRefreshTimeout", "Searchfieldautorefreshtimeout", 350, "num");
   GRIDLICENSESContainer.setProp("UseFilters", "Usefilters", "true", "str");
   GRIDLICENSESContainer.setProp("FiltersMode", "Filtersmode", "menu", "str");
   GRIDLICENSESContainer.setProp("LocalFilters", "Localfilters", "false", "str");
   GRIDLICENSESContainer.setProp("AutoReloadFilters", "Autoreloadfilters", "true", "str");
   GRIDLICENSESContainer.setProp("FiltersStateId", "Filtersstateid", "", "str");
   GRIDLICENSESContainer.setProp("FiltersCls", "Filterscls", "", "str");
   GRIDLICENSESContainer.setProp("ShowFiltersMenu", "Showfiltersmenu", "true", "str");
   GRIDLICENSESContainer.setDynProp("FiltersText", "Filterstext", "Filters", "str");
   GRIDLICENSESContainer.setDynProp("YesText", "Yestext", "Yes", "str");
   GRIDLICENSESContainer.setDynProp("NoText", "Notext", "No", "str");
   GRIDLICENSESContainer.setDynProp("BeforeText", "Beforetext", "Before", "str");
   GRIDLICENSESContainer.setDynProp("AfterText", "Aftertext", "After", "str");
   GRIDLICENSESContainer.setDynProp("OnText", "Ontext", "On", "str");
   GRIDLICENSESContainer.setProp("TreeMode", "Treemode", "false", "str");
   GRIDLICENSESContainer.setProp("TreeParentField", "Treeparentfield", "_parent", "str");
   GRIDLICENSESContainer.setProp("TreeIsLeafField", "Treeisleaffield", "_is_leaf", "str");
   GRIDLICENSESContainer.setProp("TreeMasterColumn", "Treemastercolumn", "", "str");
   GRIDLICENSESContainer.setProp("TreeRootTitle", "Treeroottitle", "", "str");
   GRIDLICENSESContainer.setProp("Resizable", "Resizable", "false", "str");
   GRIDLICENSESContainer.setProp("MinWidth", "Minwidth", 100, "num");
   GRIDLICENSESContainer.setProp("MaxWidth", "Maxwidth", 800, "num");
   GRIDLICENSESContainer.setProp("MinHeight", "Minheight", 100, "num");
   GRIDLICENSESContainer.setProp("MaxHeigt", "Maxheight", 600, "num");
   GRIDLICENSESContainer.setProp("Wrap", "Wrap", "true", "str");
   GRIDLICENSESContainer.setProp("Pinned", "Pinned", "true", "str");
   GRIDLICENSESContainer.setProp("Handles", "Handles", "s e se", "str");
   GRIDLICENSESContainer.setProp("Collapsible", "Collapsible", "false", "str");
   GRIDLICENSESContainer.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GRIDLICENSESContainer.setProp("TrackMouseOver", "Trackmouseover", "true", "str");
   GRIDLICENSESContainer.setProp("SelectionModel", "Selectionmodel", "RowSelectionModel", "str");
   GRIDLICENSESContainer.setProp("SingleSelect", "Singleselect", "false", "str");
   GRIDLICENSESContainer.setProp("LockSelections", "Lockselections", "false", "str");
   GRIDLICENSESContainer.addV2CFunction('AV54selectedLicenses', "vSELECTEDLICENSES", 'SetSelectedRowData');
   GRIDLICENSESContainer.addC2VFunction(function(UC) { UC.ParentObject.AV54selectedLicenses=UC.GetSelectedRowData();gx.fn.setControlValue("vSELECTEDLICENSES",UC.ParentObject.AV54selectedLicenses); });
   GRIDLICENSESContainer.setProp("Grouping", "Grouping", "false", "str");
   GRIDLICENSESContainer.setProp("GroupField", "Groupfield", "", "str");
   GRIDLICENSESContainer.setProp("HideGroupedField", "Hidegroupedfield", "false", "str");
   GRIDLICENSESContainer.setProp("GroupTemplate", "Grouptemplate", "{text}", "str");
   GRIDLICENSESContainer.setProp("EnableDragDrop", "Enabledragdrop", "false", "str");
   GRIDLICENSESContainer.setProp("AutoSizeColumns", "Autosizecolumns", "true", "str");
   GRIDLICENSESContainer.setProp("MinColumnWidth", "Mincolumnwidth", 25, "num");
   GRIDLICENSESContainer.setProp("EnableColumnHide", "Enablecolumnhide", "true", "str");
   GRIDLICENSESContainer.setProp("EnableColumnMove", "Enablecolumnmove", "true", "str");
   GRIDLICENSESContainer.setProp("DefaultSortable", "Defaultsortable", "true", "str");
   GRIDLICENSESContainer.setProp("DefaultResizable", "Defaultresizable", "true", "str");
   GRIDLICENSESContainer.setProp("LoadingIndicator", "Loadingindicator", "true", "str");
   GRIDLICENSESContainer.setDynProp("LoadingMsg", "Loadingmsg", "Loading...", "str");
   GRIDLICENSESContainer.setDynProp("AutoRefresh", "Autorefresh", false, "bool");
   GRIDLICENSESContainer.setDynProp("RefreshTimeout", "Refreshtimeout", 300, "num");
   GRIDLICENSESContainer.setProp("Paging", "Paging", "true", "str");
   GRIDLICENSESContainer.setDynProp("PageSize", "Pagesize", 10, "num");
   GRIDLICENSESContainer.setProp("DisplayInfo", "Displayinfo", "false", "str");
   GRIDLICENSESContainer.setDynProp("DisplayMsg", "Displaymsg", "Displaying results {0} - {1} of {2}", "str");
   GRIDLICENSESContainer.setDynProp("EmptyMsg", "Emptymsg", "No results to display", "str");
   GRIDLICENSESContainer.setDynProp("AfterPageText", "Afterpagetext", "of {0}", "str");
   GRIDLICENSESContainer.setDynProp("BeforePageText", "Beforepagetext", "Page", "str");
   GRIDLICENSESContainer.setDynProp("FirstText", "Firsttext", "First Page", "str");
   GRIDLICENSESContainer.setDynProp("LastText", "Lasttext", "Last Page", "str");
   GRIDLICENSESContainer.setDynProp("NextText", "Nexttext", "Next Page", "str");
   GRIDLICENSESContainer.setDynProp("PreviousText", "Previoustext", "Previous Page", "str");
   GRIDLICENSESContainer.setDynProp("RefreshText", "Refreshtext", "Refresh", "str");
   GRIDLICENSESContainer.setProp("RemoteSort", "Remotesort", "true", "str");
   GRIDLICENSESContainer.setProp("DefaultSortField", "Defaultsortfield", "", "str");
   GRIDLICENSESContainer.setProp("DefaultSortDir", "Defaultsortdirection", "", "str");
   GRIDLICENSESContainer.addV2CFunction('AV7columnModelLicenses', "vCOLUMNMODELLICENSES", 'SetColumnModel');
   GRIDLICENSESContainer.addC2VFunction(function(UC) { UC.ParentObject.AV7columnModelLicenses=UC.GetColumnModel();gx.fn.setControlValue("vCOLUMNMODELLICENSES",UC.ParentObject.AV7columnModelLicenses); });
   GRIDLICENSESContainer.setProp("Data", "Data", '', "str");
   GRIDLICENSESContainer.setProp("Root", "Root", "Items", "str");
   GRIDLICENSESContainer.setDynProp("DataStoreURL", "Datastoreurl", "", "str");
   GRIDLICENSESContainer.setProp("DataStoreParms", "Datastoreparms", '', "str");
   GRIDLICENSESContainer.setProp("Record", "Record", "Item", "str");
   GRIDLICENSESContainer.setProp("Identifier", "Identifier", "Id", "str");
   GRIDLICENSESContainer.setProp("Total", "Total", "Total", "str");
   GRIDLICENSESContainer.setProp("Stateful", "Stateful", "true", "str");
   GRIDLICENSESContainer.setProp("StateId", "Stateid", "gxui-WFLicenses-Grid", "str");
   GRIDLICENSESContainer.setProp("Visible", "Visible", true, "bool");
   GRIDLICENSESContainer.setC2ShowFunction(function(UC) { UC.show(); });
   GRIDLICENSESContainer.addEventHandler("ButtonPressed", this.e114n2_client);
   GRIDLICENSESContainer.addEventHandler("LoadException", this.e124n2_client);
   this.setUserControl(GRIDLICENSESContainer);
   GXValidFnc[4]={ id:4 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREFRESHGRID",gxz:"ZV39refreshGrid",gxold:"OV39refreshGrid",gxvar:"AV39refreshGrid",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV39refreshGrid=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV39refreshGrid=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setControlValue("vREFRESHGRID",gx.O.AV39refreshGrid,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV39refreshGrid=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREFRESHGRID")},nac:gx.falseFn};
   GXValidFnc[6]={ id: 6, fld:"TXBJS", format:1,grid:0};
   this.AV39refreshGrid = false ;
   this.ZV39refreshGrid = false ;
   this.OV39refreshGrid = false ;
   this.AV67toolbarLicenses = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.AV39refreshGrid = false ;
   this.AV40refreshNow = false ;
   this.Events = {"e124n2_client": ["GRIDLICENSES.LOADEXCEPTION", true] ,"e114n2_client": ["GRIDLICENSES.BUTTONPRESSED", true] ,"e164n2_client": ["ENTER", true] ,"e174n2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV39refreshGrid',fld:'vREFRESHGRID',pic:''},{av:'AV40refreshNow',fld:'vREFRESHNOW',pic:''}],[{av:'AV39refreshGrid',fld:'vREFRESHGRID',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV67toolbarLicenses',fld:'vTOOLBARLICENSES',pic:''},{av:'AV74UsrCod',fld:'vUSRCOD',pic:'@!'}],[{av:'AV74UsrCod',fld:'vUSRCOD',pic:'@!'},{av:'gx.fn.getCtrlProperty("TXBJS","Visible")',ctrl:'TXBJS',prop:'Visible'},{av:'AV7columnModelLicenses',fld:'vCOLUMNMODELLICENSES',pic:''},{av:'this.GRIDLICENSESContainer.DataStoreURL',ctrl:'GRIDLICENSES',prop:'DataStoreURL'},{av:'AV67toolbarLicenses',fld:'vTOOLBARLICENSES',pic:''},{av:'this.GRIDLICENSESContainer.AfterPageText',ctrl:'GRIDLICENSES',prop:'AfterPageText'},{av:'this.GRIDLICENSESContainer.BeforePageText',ctrl:'GRIDLICENSES',prop:'BeforePageText'},{av:'this.GRIDLICENSESContainer.DisplayMsg',ctrl:'GRIDLICENSES',prop:'DisplayMsg'},{av:'this.GRIDLICENSESContainer.EmptyMsg',ctrl:'GRIDLICENSES',prop:'EmptyMsg'},{av:'this.GRIDLICENSESContainer.FirstText',ctrl:'GRIDLICENSES',prop:'FirstText'},{av:'this.GRIDLICENSESContainer.LastText',ctrl:'GRIDLICENSES',prop:'LastText'},{av:'this.GRIDLICENSESContainer.LoadingMsg',ctrl:'GRIDLICENSES',prop:'LoadingMsg'},{av:'this.GRIDLICENSESContainer.NextText',ctrl:'GRIDLICENSES',prop:'NextText'},{av:'this.GRIDLICENSESContainer.PreviousText',ctrl:'GRIDLICENSES',prop:'PreviousText'},{av:'this.GRIDLICENSESContainer.RefreshText',ctrl:'GRIDLICENSES',prop:'RefreshText'},{av:'this.GRIDLICENSESContainer.AfterText',ctrl:'GRIDLICENSES',prop:'AfterText'},{av:'this.GRIDLICENSESContainer.BeforeText',ctrl:'GRIDLICENSES',prop:'BeforeText'},{av:'this.GRIDLICENSESContainer.FiltersText',ctrl:'GRIDLICENSES',prop:'FiltersText'},{av:'this.GRIDLICENSESContainer.NoText',ctrl:'GRIDLICENSES',prop:'NoText'},{av:'this.GRIDLICENSESContainer.OnText',ctrl:'GRIDLICENSES',prop:'OnText'},{av:'this.GRIDLICENSESContainer.YesText',ctrl:'GRIDLICENSES',prop:'YesText'},{av:'this.GRIDLICENSESContainer.PageSize',ctrl:'GRIDLICENSES',prop:'PageSize'},{av:'this.GRIDLICENSESContainer.AutoRefresh',ctrl:'GRIDLICENSES',prop:'AutoRefresh'},{av:'this.GRIDLICENSESContainer.RefreshTimeout',ctrl:'GRIDLICENSES',prop:'RefreshTimeout'},{av:'gx.fn.getCtrlProperty("vREFRESHGRID","Visible")',ctrl:'vREFRESHGRID',prop:'Visible'},{av:'AV40refreshNow',fld:'vREFRESHNOW',pic:''}]];
   this.EvtParms["GRIDLICENSES.LOADEXCEPTION"] = [[{av:'this.GRIDLICENSESContainer.LoadExceptionError',ctrl:'GRIDLICENSES',prop:'LoadExceptionError'},{av:'AV15error',fld:'vERROR',pic:'ZZZ9'}],[{av:'AV15error',fld:'vERROR',pic:'ZZZ9'}]];
   this.EvtParms["GRIDLICENSES.BUTTONPRESSED"] = [[{av:'AV54selectedLicenses',fld:'vSELECTEDLICENSES',pic:''},{av:'this.GRIDLICENSESContainer.ButtonPressedId',ctrl:'GRIDLICENSES',prop:'ButtonPressedId'},{av:'AV11currentProduct',fld:'vCURRENTPRODUCT',pic:'ZZZZZZZ9'},{av:'AV12currentVersion',fld:'vCURRENTVERSION',pic:'ZZZZZZZ9'},{av:'AV88Protectionmethod',fld:'vPROTECTIONMETHOD',pic:''},{av:'AV82offline',fld:'vOFFLINE',pic:''},{av:'AV15error',fld:'vERROR',pic:'ZZZ9'},{av:'AV78XMLText',fld:'vXMLTEXT',pic:''}],[{av:'AV11currentProduct',fld:'vCURRENTPRODUCT',pic:'ZZZZZZZ9'},{av:'AV12currentVersion',fld:'vCURRENTVERSION',pic:'ZZZZZZZ9'},{av:'AV15error',fld:'vERROR',pic:'ZZZ9'},{av:'AV78XMLText',fld:'vXMLTEXT',pic:''},{av:'AV82offline',fld:'vOFFLINE',pic:''},{av:'AV39refreshGrid',fld:'vREFRESHGRID',pic:''},{av:'AV40refreshNow',fld:'vREFRESHNOW',pic:''}]];
   this.Initialize( );
});
