/*!   GeneXus Java 16_0_10-142546 on July 4, 2020 15:59:24.72
*/
gx.evt.autoSkip = false;
gx.define('wfnominatedusers', true, function (CmpContext) {
   this.ServerClass =  "wfnominatedusers" ;
   this.PackageName =  "com.gxflow" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.s152_client=function()
   {
      this.AV71window.Url =  gx.http.formatLink("com.gxflow.wfimportnominatedusers",[121, 25])  ;
      this.AV71window.ReturnParms =  []  ;
      this.popupOpen(this.AV71window) ;
   };
   this.s162_client=function()
   {
      gx.fn.setCtrlProperty("TXBJS","Caption", "<script language=\"JavaScript\" type=\"text/javascript\">window.open(\""+gx.http.formatLink("com.gxflow.awfexportlicensenominatedusers",[121, 25])+gx.getMessage( "\");</script>") );
   };
   this.e124o2_client=function()
   {
      return this.executeServerEvent("GRID.LOADEXCEPTION", false, null, true, true);
   };
   this.e114o2_client=function()
   {
      return this.executeServerEvent("GRID.BUTTONPRESSED", false, null, true, true);
   };
   this.e154o2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e164o2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[6];
   this.GXLastCtrlId =6;
   this.GRIDContainer = gx.uc.getNew(this, 3, 0, "gxui.Grid", this.CmpContext + "GRIDContainer", "Grid", "GRID");
   var GRIDContainer = this.GRIDContainer;
   GRIDContainer.setProp("Class", "Class", "", "char");
   GRIDContainer.setProp("Enabled", "Enabled", true, "boolean");
   GRIDContainer.setProp("Width", "Width", 100, "num");
   GRIDContainer.setProp("Height", "Height", 100, "num");
   GRIDContainer.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   GRIDContainer.setProp("LoadExceptionError", "Loadexceptionerror", "", "char");
   GRIDContainer.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   GRIDContainer.setProp("AutoWidth", "Autowidth", "false", "str");
   GRIDContainer.setProp("AutoHeight", "Autoheight", "false", "str");
   GRIDContainer.setProp("ForceFit", "Forcefit", "true", "str");
   GRIDContainer.setProp("AutoExpandColumn", "Autoexpandcolumn", "", "str");
   GRIDContainer.setProp("Title", "Title", "", "str");
   GRIDContainer.setProp("IconCls", "Iconcls", "", "str");
   GRIDContainer.setProp("Cls", "Cls", "", "str");
   GRIDContainer.setProp("Frame", "Frame", "false", "str");
   GRIDContainer.setProp("StripeRows", "Striperows", "true", "str");
   GRIDContainer.setProp("UseToolbar", "Usetoolbar", "true", "str");
   GRIDContainer.addV2CFunction('AV61toolbarUsers', "vTOOLBARUSERS", 'SetToolbarData');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV61toolbarUsers=UC.GetToolbarData();gx.fn.setControlValue("vTOOLBARUSERS",UC.ParentObject.AV61toolbarUsers); });
   GRIDContainer.setProp("AddSearchField", "Addsearchfield", "true", "str");
   GRIDContainer.setProp("SearchFieldWidth", "Searchfieldwidth", 200, "num");
   GRIDContainer.setProp("SearchFieldAutoRefresh", "Searchfieldautorefresh", true, "bool");
   GRIDContainer.setProp("SearchFieldAutoRefreshTimeout", "Searchfieldautorefreshtimeout", 350, "num");
   GRIDContainer.setProp("UseFilters", "Usefilters", "true", "str");
   GRIDContainer.setProp("FiltersMode", "Filtersmode", "menu", "str");
   GRIDContainer.setProp("LocalFilters", "Localfilters", "false", "str");
   GRIDContainer.setProp("AutoReloadFilters", "Autoreloadfilters", "true", "str");
   GRIDContainer.setProp("FiltersStateId", "Filtersstateid", "", "str");
   GRIDContainer.setProp("FiltersCls", "Filterscls", "", "str");
   GRIDContainer.setProp("ShowFiltersMenu", "Showfiltersmenu", "true", "str");
   GRIDContainer.setDynProp("FiltersText", "Filterstext", "Filters", "str");
   GRIDContainer.setDynProp("YesText", "Yestext", "Yes", "str");
   GRIDContainer.setDynProp("NoText", "Notext", "No", "str");
   GRIDContainer.setDynProp("BeforeText", "Beforetext", "Before", "str");
   GRIDContainer.setDynProp("AfterText", "Aftertext", "After", "str");
   GRIDContainer.setDynProp("OnText", "Ontext", "On", "str");
   GRIDContainer.setProp("TreeMode", "Treemode", "false", "str");
   GRIDContainer.setProp("TreeParentField", "Treeparentfield", "_parent", "str");
   GRIDContainer.setProp("TreeIsLeafField", "Treeisleaffield", "_is_leaf", "str");
   GRIDContainer.setProp("TreeMasterColumn", "Treemastercolumn", "", "str");
   GRIDContainer.setProp("TreeRootTitle", "Treeroottitle", "", "str");
   GRIDContainer.setProp("Resizable", "Resizable", "false", "str");
   GRIDContainer.setProp("MinWidth", "Minwidth", 100, "num");
   GRIDContainer.setProp("MaxWidth", "Maxwidth", 800, "num");
   GRIDContainer.setProp("MinHeight", "Minheight", 100, "num");
   GRIDContainer.setProp("MaxHeigt", "Maxheight", 600, "num");
   GRIDContainer.setProp("Wrap", "Wrap", "true", "str");
   GRIDContainer.setProp("Pinned", "Pinned", "true", "str");
   GRIDContainer.setProp("Handles", "Handles", "s e se", "str");
   GRIDContainer.setProp("Collapsible", "Collapsible", "false", "str");
   GRIDContainer.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   GRIDContainer.setProp("TrackMouseOver", "Trackmouseover", "true", "str");
   GRIDContainer.setProp("SelectionModel", "Selectionmodel", "RowSelectionModel", "str");
   GRIDContainer.setProp("SingleSelect", "Singleselect", "false", "str");
   GRIDContainer.setProp("LockSelections", "Lockselections", "false", "str");
   GRIDContainer.addV2CFunction('AV49selectedUsers', "vSELECTEDUSERS", 'SetSelectedRowData');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV49selectedUsers=UC.GetSelectedRowData();gx.fn.setControlValue("vSELECTEDUSERS",UC.ParentObject.AV49selectedUsers); });
   GRIDContainer.setProp("Grouping", "Grouping", "false", "str");
   GRIDContainer.setProp("GroupField", "Groupfield", "", "str");
   GRIDContainer.setProp("HideGroupedField", "Hidegroupedfield", "false", "str");
   GRIDContainer.setProp("GroupTemplate", "Grouptemplate", "{text}", "str");
   GRIDContainer.setProp("EnableDragDrop", "Enabledragdrop", "false", "str");
   GRIDContainer.setProp("AutoSizeColumns", "Autosizecolumns", "true", "str");
   GRIDContainer.setProp("MinColumnWidth", "Mincolumnwidth", 25, "num");
   GRIDContainer.setProp("EnableColumnHide", "Enablecolumnhide", "true", "str");
   GRIDContainer.setProp("EnableColumnMove", "Enablecolumnmove", "true", "str");
   GRIDContainer.setProp("DefaultSortable", "Defaultsortable", "true", "str");
   GRIDContainer.setProp("DefaultResizable", "Defaultresizable", "true", "str");
   GRIDContainer.setProp("LoadingIndicator", "Loadingindicator", "true", "str");
   GRIDContainer.setDynProp("LoadingMsg", "Loadingmsg", "Loading...", "str");
   GRIDContainer.setDynProp("AutoRefresh", "Autorefresh", false, "bool");
   GRIDContainer.setDynProp("RefreshTimeout", "Refreshtimeout", 300, "num");
   GRIDContainer.setProp("Paging", "Paging", "true", "str");
   GRIDContainer.setDynProp("PageSize", "Pagesize", 10, "num");
   GRIDContainer.setProp("DisplayInfo", "Displayinfo", "false", "str");
   GRIDContainer.setDynProp("DisplayMsg", "Displaymsg", "Displaying results {0} - {1} of {2}", "str");
   GRIDContainer.setDynProp("EmptyMsg", "Emptymsg", "No results to display", "str");
   GRIDContainer.setDynProp("AfterPageText", "Afterpagetext", "of {0}", "str");
   GRIDContainer.setDynProp("BeforePageText", "Beforepagetext", "Page", "str");
   GRIDContainer.setDynProp("FirstText", "Firsttext", "First Page", "str");
   GRIDContainer.setDynProp("LastText", "Lasttext", "Last Page", "str");
   GRIDContainer.setDynProp("NextText", "Nexttext", "Next Page", "str");
   GRIDContainer.setDynProp("PreviousText", "Previoustext", "Previous Page", "str");
   GRIDContainer.setDynProp("RefreshText", "Refreshtext", "Refresh", "str");
   GRIDContainer.setProp("RemoteSort", "Remotesort", "true", "str");
   GRIDContainer.setProp("DefaultSortField", "Defaultsortfield", "", "str");
   GRIDContainer.setProp("DefaultSortDir", "Defaultsortdirection", "", "str");
   GRIDContainer.addV2CFunction('AV8columnModelUsers', "vCOLUMNMODELUSERS", 'SetColumnModel');
   GRIDContainer.addC2VFunction(function(UC) { UC.ParentObject.AV8columnModelUsers=UC.GetColumnModel();gx.fn.setControlValue("vCOLUMNMODELUSERS",UC.ParentObject.AV8columnModelUsers); });
   GRIDContainer.setProp("Data", "Data", '', "str");
   GRIDContainer.setProp("Root", "Root", "Items", "str");
   GRIDContainer.setDynProp("DataStoreURL", "Datastoreurl", "", "str");
   GRIDContainer.setProp("DataStoreParms", "Datastoreparms", '', "str");
   GRIDContainer.setProp("Record", "Record", "Item", "str");
   GRIDContainer.setProp("Identifier", "Identifier", "Id", "str");
   GRIDContainer.setProp("Total", "Total", "Total", "str");
   GRIDContainer.setProp("Stateful", "Stateful", "true", "str");
   GRIDContainer.setProp("StateId", "Stateid", "gxui-WFNominatedUsers-Grid", "str");
   GRIDContainer.setProp("Visible", "Visible", true, "bool");
   GRIDContainer.setC2ShowFunction(function(UC) { UC.show(); });
   GRIDContainer.addEventHandler("ButtonPressed", this.e114o2_client);
   GRIDContainer.addEventHandler("LoadException", this.e124o2_client);
   this.setUserControl(GRIDContainer);
   GXValidFnc[6]={ id: 6, fld:"TXBJS", format:1,grid:0};
   this.AV61toolbarUsers = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.AV71window = {} ;
   this.Events = {"e124o2_client": ["GRID.LOADEXCEPTION", true] ,"e114o2_client": ["GRID.BUTTONPRESSED", true] ,"e154o2_client": ["ENTER", true] ,"e164o2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["START"] = [[{av:'AV67UsrCod',fld:'vUSRCOD',pic:'@!'},{av:'AV61toolbarUsers',fld:'vTOOLBARUSERS',pic:''}],[{av:'AV67UsrCod',fld:'vUSRCOD',pic:'@!'},{av:'gx.fn.getCtrlProperty("TXBJS","Visible")',ctrl:'TXBJS',prop:'Visible'},{av:'AV8columnModelUsers',fld:'vCOLUMNMODELUSERS',pic:''},{av:'this.GRIDContainer.DataStoreURL',ctrl:'GRID',prop:'DataStoreURL'},{av:'this.GRIDContainer.AfterPageText',ctrl:'GRID',prop:'AfterPageText'},{av:'this.GRIDContainer.BeforePageText',ctrl:'GRID',prop:'BeforePageText'},{av:'this.GRIDContainer.DisplayMsg',ctrl:'GRID',prop:'DisplayMsg'},{av:'this.GRIDContainer.EmptyMsg',ctrl:'GRID',prop:'EmptyMsg'},{av:'this.GRIDContainer.FirstText',ctrl:'GRID',prop:'FirstText'},{av:'this.GRIDContainer.LastText',ctrl:'GRID',prop:'LastText'},{av:'this.GRIDContainer.LoadingMsg',ctrl:'GRID',prop:'LoadingMsg'},{av:'this.GRIDContainer.NextText',ctrl:'GRID',prop:'NextText'},{av:'this.GRIDContainer.PreviousText',ctrl:'GRID',prop:'PreviousText'},{av:'this.GRIDContainer.RefreshText',ctrl:'GRID',prop:'RefreshText'},{av:'this.GRIDContainer.AfterText',ctrl:'GRID',prop:'AfterText'},{av:'this.GRIDContainer.BeforeText',ctrl:'GRID',prop:'BeforeText'},{av:'this.GRIDContainer.FiltersText',ctrl:'GRID',prop:'FiltersText'},{av:'this.GRIDContainer.NoText',ctrl:'GRID',prop:'NoText'},{av:'this.GRIDContainer.OnText',ctrl:'GRID',prop:'OnText'},{av:'this.GRIDContainer.YesText',ctrl:'GRID',prop:'YesText'},{av:'this.GRIDContainer.PageSize',ctrl:'GRID',prop:'PageSize'},{av:'this.GRIDContainer.AutoRefresh',ctrl:'GRID',prop:'AutoRefresh'},{av:'this.GRIDContainer.RefreshTimeout',ctrl:'GRID',prop:'RefreshTimeout'},{av:'AV61toolbarUsers',fld:'vTOOLBARUSERS',pic:''}]];
   this.EvtParms["GRID.LOADEXCEPTION"] = [[{av:'this.GRIDContainer.LoadExceptionError',ctrl:'GRID',prop:'LoadExceptionError'},{av:'AV14error',fld:'vERROR',pic:'ZZZ9'}],[{av:'AV14error',fld:'vERROR',pic:'ZZZ9'}]];
   this.EvtParms["GRID.BUTTONPRESSED"] = [[{av:'AV49selectedUsers',fld:'vSELECTEDUSERS',pic:''},{av:'this.GRIDContainer.ButtonPressedId',ctrl:'GRID',prop:'ButtonPressedId'},{av:'AV31nominatedUser',fld:'vNOMINATEDUSER',pic:''},{av:'AV61toolbarUsers',fld:'vTOOLBARUSERS',pic:''},{av:'AV14error',fld:'vERROR',pic:'ZZZ9'}],[{av:'AV31nominatedUser',fld:'vNOMINATEDUSER',pic:''},{av:'AV14error',fld:'vERROR',pic:'ZZZ9'},{av:'AV61toolbarUsers',fld:'vTOOLBARUSERS',pic:''},{av:'gx.fn.getCtrlProperty("TXBJS","Caption")',ctrl:'TXBJS',prop:'Caption'}]];
   this.Initialize( );
});
