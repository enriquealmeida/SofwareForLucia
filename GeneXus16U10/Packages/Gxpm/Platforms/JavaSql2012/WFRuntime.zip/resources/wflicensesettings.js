/*!   GeneXus Java 16_0_10-142546 on July 4, 2020 15:59:22.92
*/
gx.evt.autoSkip = false;
gx.define('wflicensesettings', true, function (CmpContext) {
   this.ServerClass =  "wflicensesettings" ;
   this.PackageName =  "com.gxflow" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.Validv_Protectionmethod=function()
   {
      return this.validCliEvt("Validv_Protectionmethod", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vPROTECTIONMETHOD");
         this.AnyError  = 0;
         if ( ! ( ( this.AV87protectionMethod == 1 ) || ( this.AV87protectionMethod == 0 ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "protection Method"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e134p2_client=function()
   {
      return this.executeServerEvent("VPROTECTIONMETHOD.CLICK", true, null, false, true);
   };
   this.e144p2_client=function()
   {
      return this.executeServerEvent("'SAVE'", false, null, false, false);
   };
   this.e164p2_client=function()
   {
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e174p2_client=function()
   {
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[5,8,11,13,16,19,21,24,26,29,31,34,37,39,42,45,47,50];
   this.GXLastCtrlId =50;
   this.PANELContainer = gx.uc.getNew(this, 3, 0, "gxui.Panel", this.CmpContext + "PANELContainer", "Panel", "PANEL");
   var PANELContainer = this.PANELContainer;
   PANELContainer.setProp("Class", "Class", "", "char");
   PANELContainer.setProp("Enabled", "Enabled", true, "boolean");
   PANELContainer.setProp("Width", "Width", 100, "num");
   PANELContainer.setProp("Height", "Height", 100, "num");
   PANELContainer.setProp("Draggable", "Draggable", "false", "str");
   PANELContainer.setProp("ShowAsWindow", "Showaswindow", false, "bool");
   PANELContainer.setProp("Layout", "Layout", "default", "str");
   PANELContainer.setProp("AddToParentGxUIControl", "Addtoparentgxuicontrol", true, "bool");
   PANELContainer.setProp("ButtonPressedId", "Buttonpressedid", "", "char");
   PANELContainer.setProp("EditFieldValue", "Editfieldvalue", "", "char");
   PANELContainer.setProp("Visible", "Visible", true, "boolean");
   PANELContainer.setProp("Refresh", "Refresh", false, "boolean");
   PANELContainer.setProp("AutoWidth", "Autowidth", "false", "str");
   PANELContainer.setProp("AutoHeight", "Autoheight", "false", "str");
   PANELContainer.setProp("Title", "Title", gx.getMessage( "GXWF_SETTINGS"), "str");
   PANELContainer.setProp("IconCls", "Iconcls", "", "str");
   PANELContainer.setProp("Cls", "Cls", "", "str");
   PANELContainer.setProp("Frame", "Frame", "true", "str");
   PANELContainer.setProp("Border", "Border", true, "bool");
   PANELContainer.setProp("Modal", "Modal", false, "bool");
   PANELContainer.setProp("UseToolbar", "Usetoolbar", "false", "str");
   PANELContainer.addV2CFunction('AV17gxuiToolbar', "vGXUITOOLBAR", 'SetToolbarData');
   PANELContainer.addC2VFunction(function(UC) { UC.ParentObject.AV17gxuiToolbar=UC.GetToolbarData();gx.fn.setControlValue("vGXUITOOLBAR",UC.ParentObject.AV17gxuiToolbar); });
   PANELContainer.setProp("Resizable", "Resizable", "false", "str");
   PANELContainer.setProp("MinWidth", "Minwidth", 100, "num");
   PANELContainer.setProp("MaxWidth", "Maxwidth", 800, "num");
   PANELContainer.setProp("MinHeight", "Minheight", 100, "num");
   PANELContainer.setProp("MaxHeight", "Maxheight", 600, "num");
   PANELContainer.setProp("Pinned", "Pinned", "true", "str");
   PANELContainer.setProp("Handles", "Handles", "s e se", "str");
   PANELContainer.setProp("Collapsible", "Collapsible", "false", "str");
   PANELContainer.setProp("Collapsed", "Collapsed", "false", "str");
   PANELContainer.setProp("AnimateCollapse", "Animatecollapse", "false", "str");
   PANELContainer.setProp("Stateful", "Stateful", "true", "str");
   PANELContainer.setProp("StateId", "Stateid", "", "str");
   PANELContainer.setC2ShowFunction(function(UC) { UC.show(); });
   this.setUserControl(PANELContainer);
   GXValidFnc[5]={ id: 5, fld:"TABLE9",grid:0};
   GXValidFnc[8]={ id: 8, fld:"TABLE3",grid:0};
   GXValidFnc[11]={ id: 11, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[13]={ id:13 ,lvl:0,type:"int",len:1,dec:0,sign:false,pic:"9",ro:0,grid:0,gxgrid:null,fnc:this.Validv_Protectionmethod,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPROTECTIONMETHOD",gxz:"ZV87protectionMethod",gxold:"OV87protectionMethod",gxvar:"AV87protectionMethod",ucs:[],op:[13],ip:[13],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV87protectionMethod=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV87protectionMethod=gx.num.intval(Value)},v2c:function(){gx.fn.setComboBoxValue("vPROTECTIONMETHOD",gx.O.AV87protectionMethod);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV87protectionMethod=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vPROTECTIONMETHOD",gx.thousandSeparator)},nac:gx.falseFn,evt:"e134p2_client"};
   this.declareDomainHdlr( 13 , function() {
   });
   GXValidFnc[16]={ id: 16, fld:"TABLEREMOTE",grid:0};
   GXValidFnc[19]={ id: 19, fld:"TEXTBLOCK4", format:0,grid:0};
   GXValidFnc[21]={ id:21 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vHOST",gxz:"ZV18host",gxold:"OV18host",gxvar:"AV18host",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV18host=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18host=Value},v2c:function(){gx.fn.setControlValue("vHOST",gx.O.AV18host,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV18host=this.val()},val:function(){return gx.fn.getControlValue("vHOST")},nac:gx.falseFn};
   GXValidFnc[24]={ id: 24, fld:"TEXTBLOCK8", format:0,grid:0};
   GXValidFnc[26]={ id:26 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSER",gxz:"ZV74user",gxold:"OV74user",gxvar:"AV74user",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV74user=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV74user=Value},v2c:function(){gx.fn.setControlValue("vUSER",gx.O.AV74user,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV74user=this.val()},val:function(){return gx.fn.getControlValue("vUSER")},nac:gx.falseFn};
   GXValidFnc[29]={ id: 29, fld:"TEXTBLOCK9", format:0,grid:0};
   GXValidFnc[31]={ id:31 ,lvl:0,type:"char",len:40,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPASSWORD",gxz:"ZV35password",gxold:"OV35password",gxvar:"AV35password",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV35password=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV35password=Value},v2c:function(){gx.fn.setControlValue("vPASSWORD",gx.O.AV35password,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV35password=this.val()},val:function(){return gx.fn.getControlValue("vPASSWORD")},nac:gx.falseFn};
   GXValidFnc[34]={ id: 34, fld:"TABLEOFFLINE",grid:0};
   GXValidFnc[37]={ id:37 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vOFFLINE",gxz:"ZV86offline",gxold:"OV86offline",gxvar:"AV86offline",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV86offline=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV86offline=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vOFFLINE",gx.O.AV86offline,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV86offline=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vOFFLINE")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[39]={ id: 39, fld:"TEXTBLOCK3", format:0,grid:0};
   GXValidFnc[42]={ id: 42, fld:"TABLELOG",grid:0};
   GXValidFnc[45]={ id:45 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGENERATELOG",gxz:"ZV83generateLog",gxold:"OV83generateLog",gxvar:"AV83generateLog",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV83generateLog=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV83generateLog=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vGENERATELOG",gx.O.AV83generateLog,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV83generateLog=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vGENERATELOG")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[47]={ id: 47, fld:"TEXTBLOCK2", format:0,grid:0};
   GXValidFnc[50]={ id: 50, fld:"BTNSAVEREMOTE",grid:0,evt:"e144p2_client"};
   this.AV87protectionMethod = 0 ;
   this.ZV87protectionMethod = 0 ;
   this.OV87protectionMethod = 0 ;
   this.AV18host = "" ;
   this.ZV18host = "" ;
   this.OV18host = "" ;
   this.AV74user = "" ;
   this.ZV74user = "" ;
   this.OV74user = "" ;
   this.AV35password = "" ;
   this.ZV35password = "" ;
   this.OV35password = "" ;
   this.AV86offline = false ;
   this.ZV86offline = false ;
   this.OV86offline = false ;
   this.AV83generateLog = false ;
   this.ZV83generateLog = false ;
   this.OV83generateLog = false ;
   this.AV87protectionMethod = 0 ;
   this.AV18host = "" ;
   this.AV74user = "" ;
   this.AV35password = "" ;
   this.AV86offline = false ;
   this.AV83generateLog = false ;
   this.AV17gxuiToolbar = {Buttons:[],SeparateAll:false,MaxButtons:0} ;
   this.Events = {"e134p2_client": ["VPROTECTIONMETHOD.CLICK", true] ,"e144p2_client": ["'SAVE'", true] ,"e164p2_client": ["ENTER", true] ,"e174p2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{ctrl:'vPROTECTIONMETHOD'},{av:'AV87protectionMethod',fld:'vPROTECTIONMETHOD',pic:'9'},{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}],[{av:'gx.fn.getCtrlProperty("TABLEREMOTE","Visible")',ctrl:'TABLEREMOTE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TABLELOG","Visible")',ctrl:'TABLELOG',prop:'Visible'},{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}],[{av:'AV60settings',fld:'vSETTINGS',pic:''},{av:'AV18host',fld:'vHOST',pic:''},{av:'AV74user',fld:'vUSER',pic:''},{av:'AV35password',fld:'vPASSWORD',pic:''},{ctrl:'vPROTECTIONMETHOD'},{av:'AV87protectionMethod',fld:'vPROTECTIONMETHOD',pic:'9'},{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]];
   this.EvtParms["VPROTECTIONMETHOD.CLICK"] = [[{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}],[{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]];
   this.EvtParms["'SAVE'"] = [[{ctrl:'vPROTECTIONMETHOD'},{av:'AV87protectionMethod',fld:'vPROTECTIONMETHOD',pic:'9'},{av:'AV18host',fld:'vHOST',pic:''},{av:'AV74user',fld:'vUSER',pic:''},{av:'AV35password',fld:'vPASSWORD',pic:''},{av:'AV84serverOk',fld:'vSERVEROK',pic:''},{av:'AV15error',fld:'vERROR',pic:'ZZZ9'},{av:'AV60settings',fld:'vSETTINGS',pic:''},{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}],[{av:'AV15error',fld:'vERROR',pic:'ZZZ9'},{av:'AV84serverOk',fld:'vSERVEROK',pic:''},{av:'AV60settings',fld:'vSETTINGS',pic:''},{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]];
   this.EvtParms["VALIDV_PROTECTIONMETHOD"] = [[{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}],[{av:'AV86offline',fld:'vOFFLINE',pic:''},{av:'AV83generateLog',fld:'vGENERATELOG',pic:''}]];
   this.Initialize( );
   this.setComponent({id: "WCINFO" ,GXClass: "wfinfo" , Prefix: "W0052" , lvl: 1 });
});
