/*
               File: GAM_AppPermissionEntry
        Description: Application permission
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:20:26.64
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_apppermissionentry', false, function () {
   this.ServerClass =  "gam_apppermissionentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV8ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV6isOK=gx.fn.getControlValue("vISOK") ;
      this.AV8ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
   };
   this.Validv_Accesstype=function()
   {
      return this.validCliEvt("Validv_Accesstype", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vACCESSTYPE");
         this.AnyError  = 0;
         if ( ! ( ( this.AV20AccessType == "A" ) || ( this.AV20AccessType == "R" ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Access Type"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

         this.refreshOutputs([{av:'AV15IsParent',fld:'vISPARENT',pic:''}]);
      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e131d1_client=function()
   {
      /* 'DeletePermission' Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["DLT", this.AV8ApplicationId, this.AV14GUID]);
      this.refreshOutputs([{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]);
      return gx.$.Deferred().resolve();
   };
   this.e111d1_client=function()
   {
      /* 'ShowHide' Routine */
      this.clearMessages();
      if ( gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class") == "ActionsContainer" )
      {
         gx.fn.setCtrlProperty("ACTIONSCONTAINER","Class", "ActionsContainerVisible" );
      }
      else
      {
         gx.fn.setCtrlProperty("ACTIONSCONTAINER","Class", "ActionsContainer" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]);
      return gx.$.Deferred().resolve();
   };
   this.e121d1_client=function()
   {
      /* 'Edit' Routine */
      this.clearMessages();
      this.call("gam_apppermissionentry.aspx", ["UPD", this.AV8ApplicationId, this.AV14GUID]);
      this.refreshOutputs([{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]);
      return gx.$.Deferred().resolve();
   };
   this.e151d2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e161d2_client=function()
   {
      /* 'Children' Routine */
      return this.executeServerEvent("'CHILDREN'", true, null, false, false);
   };
   this.e181d1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80];
   this.GXLastCtrlId =80;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"SHOWHIDE",grid:0,evt:"e111d1_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"ACTIONSCONTAINER",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TABLEEDIT",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"IMAGE3",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"TEXTBLOCK2", format:0,grid:0,evt:"e121d1_client"};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"TABLE4",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"IMAGE1",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"CHILDREN", format:0,grid:0,evt:"e161d2_client"};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"TABLE5",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"IMAGE2",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"DELETEPERMISSION", format:0,grid:0,evt:"e131d1_client"};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"TABLE2",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id:48 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",gxz:"ZV27GXV1",gxold:"OV27GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV27GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id:53 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",gxz:"ZV14GUID",gxold:"OV14GUID",gxvar:"AV14GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV14GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 53 , function() {
   });
   GXValidFnc[54]={ id: 54, fld:"",grid:0};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"",grid:0};
   GXValidFnc[58]={ id:58 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV16Name",gxold:"OV16Name",gxvar:"AV16Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV16Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV16Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 58 , function() {
   });
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"",grid:0};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"",grid:0};
   GXValidFnc[63]={ id:63 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",gxz:"ZV10Dsc",gxold:"OV10Dsc",gxvar:"AV10Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV10Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 63 , function() {
   });
   GXValidFnc[64]={ id: 64, fld:"",grid:0};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"",grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id:68 ,lvl:0,type:"char",len:1,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:this.Validv_Accesstype,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vACCESSTYPE",gxz:"ZV20AccessType",gxold:"OV20AccessType",gxvar:"AV20AccessType",ucs:[],op:[68],ip:[68],
						nacdep:[],ctrltype:"combo",v2v:function(Value){if(Value!==undefined)gx.O.AV20AccessType=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV20AccessType=Value},v2c:function(){gx.fn.setComboBoxValue("vACCESSTYPE",gx.O.AV20AccessType);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV20AccessType=this.val()},val:function(){return gx.fn.getControlValue("vACCESSTYPE")},nac:gx.falseFn};
   this.declareDomainHdlr( 68 , function() {
   });
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id: 72, fld:"",grid:0};
   GXValidFnc[73]={ id:73 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vISPARENT",gxz:"ZV15IsParent",gxold:"OV15IsParent",gxvar:"AV15IsParent",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV15IsParent=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15IsParent=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vISPARENT",gx.O.AV15IsParent,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV15IsParent=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vISPARENT")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[74]={ id: 74, fld:"",grid:0};
   GXValidFnc[75]={ id: 75, fld:"",grid:0};
   GXValidFnc[76]={ id: 76, fld:"",grid:0};
   GXValidFnc[77]={ id: 77, fld:"",grid:0};
   GXValidFnc[78]={ id: 78, fld:"BTNCANCEL",grid:0,evt:"e181d1_client"};
   GXValidFnc[79]={ id: 79, fld:"",grid:0};
   GXValidFnc[80]={ id: 80, fld:"BTNCONFIRM",grid:0,evt:"e151d2_client",std:"ENTER"};
   this.GXV1 = "" ;
   this.ZV27GXV1 = "" ;
   this.OV27GXV1 = "" ;
   this.AV14GUID = "" ;
   this.ZV14GUID = "" ;
   this.OV14GUID = "" ;
   this.AV16Name = "" ;
   this.ZV16Name = "" ;
   this.OV16Name = "" ;
   this.AV10Dsc = "" ;
   this.ZV10Dsc = "" ;
   this.OV10Dsc = "" ;
   this.AV20AccessType = "" ;
   this.ZV20AccessType = "" ;
   this.OV20AccessType = "" ;
   this.AV15IsParent = false ;
   this.ZV15IsParent = false ;
   this.OV15IsParent = false ;
   this.GXV1 = "" ;
   this.AV14GUID = "" ;
   this.AV16Name = "" ;
   this.AV10Dsc = "" ;
   this.AV20AccessType = "" ;
   this.AV15IsParent = false ;
   this.AV8ApplicationId = 0 ;
   this.Gx_mode = "" ;
   this.AV6isOK = false ;
   this.Events = {"e151d2_client": ["ENTER", true] ,"e161d2_client": ["'CHILDREN'", true] ,"e181d1_client": ["CANCEL", true] ,"e131d1_client": ["'DELETEPERMISSION'", false] ,"e111d1_client": ["'SHOWHIDE'", false] ,"e121d1_client": ["'EDIT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'gx.fn.getCtrlProperty("vISPARENT","Enabled")',ctrl:'vISPARENT',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TABLEEDIT","Visible")',ctrl:'TABLEEDIT',prop:'Visible'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV16Name',fld:'vNAME',pic:''},{av:'AV10Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV20AccessType',fld:'vACCESSTYPE',pic:''},{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Visible")',ctrl:'ACTIONSCONTAINER',prop:'Visible'},{ctrl:'BTNCONFIRM',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vNAME","Enabled")',ctrl:'vNAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vDSC","Enabled")',ctrl:'vDSC',prop:'Enabled'},{ctrl:'BTNCONFIRM',prop:'Caption'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV16Name',fld:'vNAME',pic:''},{av:'AV10Dsc',fld:'vDSC',pic:''},{ctrl:'vACCESSTYPE'},{av:'AV20AccessType',fld:'vACCESSTYPE',pic:''},{av:'AV6isOK',fld:'vISOK',pic:''},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV6isOK',fld:'vISOK',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["'DELETEPERMISSION'"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["'CHILDREN'"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["'SHOWHIDE'"] = [[{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'gx.fn.getCtrlProperty("ACTIONSCONTAINER","Class")',ctrl:'ACTIONSCONTAINER',prop:'Class'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["'EDIT'"] = [[{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV14GUID',fld:'vGUID',pic:''},{av:'AV8ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9'},{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EvtParms["VALIDV_ACCESSTYPE"] = [[{av:'AV15IsParent',fld:'vISPARENT',pic:''}],[{av:'AV15IsParent',fld:'vISPARENT',pic:''}]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV6isOK", "vISOK", 0, "boolean", 4, 0);
   this.setVCMap("AV8ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.addBCProperty("Gamapplication", ["Name"], this.GXValidFnc[48], "AV5GAMApplication");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_apppermissionentry);});
