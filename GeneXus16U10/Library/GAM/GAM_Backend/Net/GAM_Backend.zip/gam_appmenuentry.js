/*
               File: GAM_AppMenuEntry
        Description: GAMExample App Menu Entry
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:20:52.60
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_appmenuentry', false, function () {
   this.ServerClass =  "gam_appmenuentry" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV7ApplicationId=gx.fn.getIntegerValue("vAPPLICATIONID",gx.thousandSeparator) ;
      this.Gx_mode=gx.fn.getControlValue("vMODE") ;
      this.AV6isOK=gx.fn.getControlValue("vISOK") ;
   };
   this.e122h2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e142h1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47];
   this.GXLastCtrlId =47;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TABLE2",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",gxz:"ZV18GXV1",gxold:"OV18GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",gxz:"ZV12GUID",gxold:"OV12GUID",gxvar:"AV12GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV12GUID,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV12GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV13Id",gxold:"OV13Id",gxvar:"AV13Id",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV13Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV13Id=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vID",gx.O.AV13Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV13Id=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vID",gx.thousandSeparator)},nac:gx.falseFn};
   this.declareDomainHdlr( 30 , function() {
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id:35 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV14Name",gxold:"OV14Name",gxvar:"AV14Name",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV14Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV14Name=Value},v2c:function(){gx.fn.setControlValue("vNAME",gx.O.AV14Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV14Name=this.val()},val:function(){return gx.fn.getControlValue("vNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 35 , function() {
   });
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id:40 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vDSC",gxz:"ZV9Dsc",gxold:"OV9Dsc",gxvar:"AV9Dsc",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV9Dsc=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV9Dsc=Value},v2c:function(){gx.fn.setControlValue("vDSC",gx.O.AV9Dsc,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV9Dsc=this.val()},val:function(){return gx.fn.getControlValue("vDSC")},nac:gx.falseFn};
   this.declareDomainHdlr( 40 , function() {
   });
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"BTNCANCEL",grid:0,evt:"e142h1_client"};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[47]={ id: 47, fld:"BTNCONFIRM",grid:0,evt:"e122h2_client",std:"ENTER"};
   this.GXV1 = "" ;
   this.ZV18GXV1 = "" ;
   this.OV18GXV1 = "" ;
   this.AV12GUID = "" ;
   this.ZV12GUID = "" ;
   this.OV12GUID = "" ;
   this.AV13Id = 0 ;
   this.ZV13Id = 0 ;
   this.OV13Id = 0 ;
   this.AV14Name = "" ;
   this.ZV14Name = "" ;
   this.OV14Name = "" ;
   this.AV9Dsc = "" ;
   this.ZV9Dsc = "" ;
   this.OV9Dsc = "" ;
   this.GXV1 = "" ;
   this.AV12GUID = "" ;
   this.AV13Id = 0 ;
   this.AV14Name = "" ;
   this.AV9Dsc = "" ;
   this.AV7ApplicationId = 0 ;
   this.Gx_mode = "" ;
   this.AV6isOK = false ;
   this.Events = {"e122h2_client": ["ENTER", true] ,"e142h1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[]];
   this.EvtParms["START"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV13Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true}],[{av:'gx.fn.getCtrlProperty("vID","Enabled")',ctrl:'vID',prop:'Enabled'},{av:'AV13Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV14Name',fld:'vNAME',pic:''},{av:'AV9Dsc',fld:'vDSC',pic:''},{av:'AV12GUID',fld:'vGUID',pic:''},{av:'gx.fn.getCtrlProperty("vGUID","Enabled")',ctrl:'vGUID',prop:'Enabled'},{ctrl:'BTNCONFIRM',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vNAME","Enabled")',ctrl:'vNAME',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vDSC","Enabled")',ctrl:'vDSC',prop:'Enabled'},{ctrl:'BTNCONFIRM',prop:'Caption'}]];
   this.EvtParms["ENTER"] = [[{av:'AV7ApplicationId',fld:'vAPPLICATIONID',pic:'ZZZZZZZZZZZ9',hsh:true},{av:'AV14Name',fld:'vNAME',pic:''},{av:'Gx_mode',fld:'vMODE',pic:'@!',hsh:true},{av:'AV12GUID',fld:'vGUID',pic:''},{av:'AV9Dsc',fld:'vDSC',pic:''},{av:'AV13Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV6isOK',fld:'vISOK',pic:''}],[{av:'AV6isOK',fld:'vISOK',pic:''}]];
   this.EnterCtrl = ["BTNCONFIRM"];
   this.setVCMap("AV7ApplicationId", "vAPPLICATIONID", 0, "int", 12, 0);
   this.setVCMap("Gx_mode", "vMODE", 0, "char", 3, 0);
   this.setVCMap("AV6isOK", "vISOK", 0, "boolean", 4, 0);
   this.addBCProperty("Gamapplication", ["Name"], this.GXValidFnc[20], "AV5GAMApplication");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_appmenuentry);});
