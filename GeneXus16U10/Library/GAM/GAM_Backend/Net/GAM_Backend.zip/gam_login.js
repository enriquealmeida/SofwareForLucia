/*
               File: GAM_Login
        Description: GAM_Login
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:22:8.91
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_login', false, function () {
   this.ServerClass =  "gam_login" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV23LogOnTo=gx.fn.getControlValue("vLOGONTO") ;
      this.AV10AuxUserName=gx.fn.getControlValue("vAUXUSERNAME") ;
      this.AV33UserRememberMe=gx.fn.getIntegerValue("vUSERREMEMBERME",gx.thousandSeparator) ;
   };
   this.e132v2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e152v2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40];
   this.GXLastCtrlId =40;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TABLELOGIN",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"CURRENTREPOSITORY", format:0,grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id:22 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",gxz:"ZV31UserName",gxold:"OV31UserName",gxvar:"AV31UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV31UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV31UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV31UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV31UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 22 , function() {
   });
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id:26 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",gxz:"ZV32UserPassword",gxold:"OV32UserPassword",gxvar:"AV32UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV32UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV32UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV32UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV32UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 26 , function() {
   });
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id:31 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vKEEPMELOGGEDIN",gxz:"ZV20KeepMeLoggedIn",gxold:"OV20KeepMeLoggedIn",gxvar:"AV20KeepMeLoggedIn",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV20KeepMeLoggedIn=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV20KeepMeLoggedIn=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vKEEPMELOGGEDIN",gx.O.AV20KeepMeLoggedIn,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV20KeepMeLoggedIn=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vKEEPMELOGGEDIN")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id:36 ,lvl:0,type:"boolean",len:4,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vREMEMBERME",gxz:"ZV25RememberMe",gxold:"OV25RememberMe",gxvar:"AV25RememberMe",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"checkbox",v2v:function(Value){if(Value!==undefined)gx.O.AV25RememberMe=gx.lang.booleanValue(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV25RememberMe=gx.lang.booleanValue(Value)},v2c:function(){gx.fn.setCheckBoxValue("vREMEMBERME",gx.O.AV25RememberMe,true)},c2v:function(){if(this.val()!==undefined)gx.O.AV25RememberMe=gx.lang.booleanValue(this.val())},val:function(){return gx.fn.getControlValue("vREMEMBERME")},nac:gx.falseFn,values:['true','false']};
   GXValidFnc[37]={ id: 37, fld:"",grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"LOGIN",grid:0,evt:"e132v2_client",std:"ENTER"};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   this.AV31UserName = "" ;
   this.ZV31UserName = "" ;
   this.OV31UserName = "" ;
   this.AV32UserPassword = "" ;
   this.ZV32UserPassword = "" ;
   this.OV32UserPassword = "" ;
   this.AV20KeepMeLoggedIn = false ;
   this.ZV20KeepMeLoggedIn = false ;
   this.OV20KeepMeLoggedIn = false ;
   this.AV25RememberMe = false ;
   this.ZV25RememberMe = false ;
   this.OV25RememberMe = false ;
   this.AV31UserName = "" ;
   this.AV32UserPassword = "" ;
   this.AV20KeepMeLoggedIn = false ;
   this.AV25RememberMe = false ;
   this.AV23LogOnTo = "" ;
   this.AV10AuxUserName = "" ;
   this.AV33UserRememberMe = 0 ;
   this.Events = {"e132v2_client": ["ENTER", true] ,"e152v2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV23LogOnTo',fld:'vLOGONTO',pic:'',hsh:true},{av:'AV10AuxUserName',fld:'vAUXUSERNAME',pic:'',hsh:true},{av:'AV33UserRememberMe',fld:'vUSERREMEMBERME',pic:'Z9',hsh:true},{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}],[{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV31UserName',fld:'vUSERNAME',pic:''},{av:'gx.fn.getCtrlProperty("vKEEPMELOGGEDIN","Visible")',ctrl:'vKEEPMELOGGEDIN',prop:'Visible'},{av:'gx.fn.getCtrlProperty("vREMEMBERME","Visible")',ctrl:'vREMEMBERME',prop:'Visible'},{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}]];
   this.EvtParms["START"] = [[{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}],[{av:'gx.fn.getCtrlProperty("CURRENTREPOSITORY","Visible")',ctrl:'CURRENTREPOSITORY',prop:'Visible'},{av:'gx.fn.getCtrlProperty("CURRENTREPOSITORY","Caption")',ctrl:'CURRENTREPOSITORY',prop:'Caption'},{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}]];
   this.EvtParms["ENTER"] = [[{av:'AV23LogOnTo',fld:'vLOGONTO',pic:'',hsh:true},{av:'AV31UserName',fld:'vUSERNAME',pic:''},{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}],[{av:'AV32UserPassword',fld:'vUSERPASSWORD',pic:''},{av:'AV20KeepMeLoggedIn',fld:'vKEEPMELOGGEDIN',pic:''},{av:'AV25RememberMe',fld:'vREMEMBERME',pic:''}]];
   this.EnterCtrl = ["LOGIN"];
   this.setVCMap("AV23LogOnTo", "vLOGONTO", 0, "char", 60, 0);
   this.setVCMap("AV10AuxUserName", "vAUXUSERNAME", 0, "svchar", 100, 60);
   this.setVCMap("AV33UserRememberMe", "vUSERREMEMBERME", 0, "int", 2, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_login);});
