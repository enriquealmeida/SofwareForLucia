/*
               File: GAM_Logout
        Description: Logout
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:19:23.44
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_logout', true, function (CmpContext) {
   this.ServerClass =  "gam_logout" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e11041_client=function()
   {
      /* 'UserOptions' Routine */
      this.clearMessages();
      if ( gx.fn.getCtrlProperty("PROFILE","Class") == "Table193x216" )
      {
         gx.fn.setCtrlProperty("PROFILE","Class", "Table193x216Collapsed" );
      }
      else
      {
         gx.fn.setCtrlProperty("PROFILE","Class", "Table193x216" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("PROFILE","Class")',ctrl:'PROFILE',prop:'Class'}]);
      return gx.$.Deferred().resolve();
   };
   this.e12041_client=function()
   {
      /* 'Profile' Routine */
      this.clearMessages();
      this.call("gam_userentry.aspx", ["UPD", this.AV7GUID]);
      this.refreshOutputs([{av:'AV7GUID',fld:'vGUID',pic:''}]);
      return gx.$.Deferred().resolve();
   };
   this.e13041_client=function()
   {
      /* 'ChangePassword' Routine */
      this.clearMessages();
      this.call("gam_changeyourpassword.aspx", []);
      this.refreshOutputs([]);
      return gx.$.Deferred().resolve();
   };
   this.e15042_client=function()
   {
      /* 'Logout' Routine */
      return this.executeServerEvent("'LOGOUT'", true, null, false, false);
   };
   this.e17042_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e18042_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54];
   this.GXLastCtrlId =54;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE3",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"PHOTOCELLTOP",grid:0};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id:13 ,lvl:0,type:"bits",len:1024,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPHOTO",gxz:"ZV10Photo",gxold:"OV10Photo",gxvar:"AV10Photo",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10Photo=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Photo=Value},v2c:function(){gx.fn.setMultimediaValue("vPHOTO",gx.O.AV10Photo,gx.O.AV16Photo_GXI)},c2v:function(){gx.O.AV16Photo_GXI=this.val_GXI();if(this.val()!==undefined)gx.O.AV10Photo=this.val()},val:function(){return gx.fn.getBlobValue("vPHOTO")},val_GXI:function(){return gx.fn.getControlValue("vPHOTO_GXI")}, gxvar_GXI:'AV16Photo_GXI',nac:gx.falseFn,evt:"e11041_client"};
   GXValidFnc[14]={ id: 14, fld:"LETTERCELLTOP",grid:0};
   GXValidFnc[15]={ id: 15, fld:"LETTERTITTLE", format:0,grid:0,evt:"e11041_client"};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLEWELCOME",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"TBWELCOME", format:0,grid:0,evt:"e11041_client"};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"CURRENTREPOSITORY", format:0,grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"PROFILE",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"TABLE2",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"PHOTOCELL",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id:33 ,lvl:0,type:"bits",len:1024,dec:0,sign:false,ro:1,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vPHOTO",gxz:"ZV10Photo",gxold:"OV10Photo",gxvar:"AV10Photo",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10Photo=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10Photo=Value},v2c:function(){gx.fn.setMultimediaValue("vPHOTO",gx.O.AV10Photo,gx.O.AV16Photo_GXI)},c2v:function(){gx.O.AV16Photo_GXI=this.val_GXI();if(this.val()!==undefined)gx.O.AV10Photo=this.val()},val:function(){return gx.fn.getBlobValue("vPHOTO")},val_GXI:function(){return gx.fn.getControlValue("vPHOTO_GXI")}, gxvar_GXI:'AV16Photo_GXI',nac:gx.falseFn};
   GXValidFnc[34]={ id: 34, fld:"LETTERCELL",grid:0};
   GXValidFnc[35]={ id: 35, fld:"LETTER", format:0,grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"NAME", format:0,grid:0};
   GXValidFnc[38]={ id: 38, fld:"",grid:0};
   GXValidFnc[39]={ id: 39, fld:"",grid:0};
   GXValidFnc[40]={ id: 40, fld:"EMAIL", format:0,grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"SETTINGS", format:0,grid:0,evt:"e12041_client"};
   GXValidFnc[44]={ id: 44, fld:"",grid:0};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"CHANGEPASSWORD", format:0,grid:0,evt:"e13041_client"};
   GXValidFnc[47]={ id: 47, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"LOGOUT", format:0,grid:0,evt:"e15042_client"};
   GXValidFnc[50]={ id: 50, fld:"",grid:0};
   GXValidFnc[51]={ id: 51, fld:"",grid:0};
   GXValidFnc[52]={ id: 52, fld:"",grid:0};
   GXValidFnc[53]={ id: 53, fld:"",grid:0};
   GXValidFnc[54]={ id:54 ,lvl:0,type:"char",len:40,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vGUID",gxz:"ZV7GUID",gxold:"OV7GUID",gxvar:"AV7GUID",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV7GUID=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV7GUID=Value},v2c:function(){gx.fn.setControlValue("vGUID",gx.O.AV7GUID,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV7GUID=this.val()},val:function(){return gx.fn.getControlValue("vGUID")},nac:gx.falseFn};
   this.declareDomainHdlr( 54 , function() {
   });
   this.AV16Photo_GXI = "" ;
   this.AV10Photo = "" ;
   this.ZV10Photo = "" ;
   this.OV10Photo = "" ;
   this.AV7GUID = "" ;
   this.ZV7GUID = "" ;
   this.OV7GUID = "" ;
   this.AV10Photo = "" ;
   this.AV7GUID = "" ;
   this.Events = {"e15042_client": ["'LOGOUT'", true] ,"e17042_client": ["ENTER", true] ,"e18042_client": ["CANCEL", true] ,"e11041_client": ["'USEROPTIONS'", false] ,"e12041_client": ["'PROFILE'", false] ,"e13041_client": ["'CHANGEPASSWORD'", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["START"] = [[],[{av:'gx.fn.getCtrlProperty("CURRENTREPOSITORY","Visible")',ctrl:'CURRENTREPOSITORY',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBWELCOME","Caption")',ctrl:'TBWELCOME',prop:'Caption'},{av:'gx.fn.getCtrlProperty("vGUID","Visible")',ctrl:'vGUID',prop:'Visible'},{av:'gx.fn.getCtrlProperty("PROFILE","Class")',ctrl:'PROFILE',prop:'Class'},{av:'gx.fn.getCtrlProperty("NAME","Caption")',ctrl:'NAME',prop:'Caption'},{av:'gx.fn.getCtrlProperty("EMAIL","Caption")',ctrl:'EMAIL',prop:'Caption'},{av:'AV7GUID',fld:'vGUID',pic:''},{av:'AV10Photo',fld:'vPHOTO',pic:''},{av:'gx.fn.getCtrlProperty("LETTER","Caption")',ctrl:'LETTER',prop:'Caption'},{av:'gx.fn.getCtrlProperty("LETTERTITTLE","Caption")',ctrl:'LETTERTITTLE',prop:'Caption'},{av:'gx.fn.getCtrlProperty("PHOTOCELL","Visible")',ctrl:'PHOTOCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("LETTERCELL","Visible")',ctrl:'LETTERCELL',prop:'Visible'},{av:'gx.fn.getCtrlProperty("PHOTOCELLTOP","Visible")',ctrl:'PHOTOCELLTOP',prop:'Visible'},{av:'gx.fn.getCtrlProperty("LETTERCELLTOP","Visible")',ctrl:'LETTERCELLTOP',prop:'Visible'},{av:'gx.fn.getCtrlProperty("CURRENTREPOSITORY","Caption")',ctrl:'CURRENTREPOSITORY',prop:'Caption'},{av:'gx.fn.getCtrlProperty("TABLEWELCOME","Class")',ctrl:'TABLEWELCOME',prop:'Class'}]];
   this.EvtParms["'LOGOUT'"] = [[],[]];
   this.EvtParms["'USEROPTIONS'"] = [[{av:'gx.fn.getCtrlProperty("PROFILE","Class")',ctrl:'PROFILE',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("PROFILE","Class")',ctrl:'PROFILE',prop:'Class'}]];
   this.EvtParms["'PROFILE'"] = [[{av:'AV7GUID',fld:'vGUID',pic:''}],[{av:'AV7GUID',fld:'vGUID',pic:''}]];
   this.EvtParms["'CHANGEPASSWORD'"] = [[],[]];
   this.Initialize( );
});
