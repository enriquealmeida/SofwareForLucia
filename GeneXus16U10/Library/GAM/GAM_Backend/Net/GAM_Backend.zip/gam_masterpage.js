/*
               File: GAM_MasterPage
        Description: GAM_Master Page
             Author: GeneXus C# Generator version 16_0_10-150262
       Generated on: 5/19/2021 5:50:51.3
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_masterpage', false, function () {
   this.ServerClass =  "gam_masterpage" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.IsMasterPage=true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e130t2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER_MPAGE", true, null, false, false);
   };
   this.e140t2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL_MPAGE", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,7,8];
   this.GXLastCtrlId =8;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   this.Events = {"e130t2_client": ["ENTER_MPAGE", true] ,"e140t2_client": ["CANCEL_MPAGE", true]};
   this.EvtParms["REFRESH_MPAGE"] = [[],[]];
   this.EvtParms["START_MPAGE"] = [[],[{ctrl:'HEADER1_MPAGE'}]];
   this.Initialize( );
   this.setComponent({id: "HEADER1" ,GXClass: null , Prefix: "MPW0006" , lvl: 1 });
});
gx.wi( function() { gx.createMasterPage(gam_masterpage);});
