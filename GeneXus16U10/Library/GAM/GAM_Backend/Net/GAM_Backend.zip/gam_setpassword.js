/*
               File: GAM_SetPassword
        Description: Set new password
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:20:1.13
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_setpassword', false, function () {
   this.ServerClass =  "gam_setpassword" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV9UserId=gx.fn.getControlValue("vUSERID") ;
   };
   this.e120r2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e140r1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37];
   this.GXLastCtrlId =37;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TBLMAIN",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TEXTBLOCK2", format:0,grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"TABLE2",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id:20 ,lvl:0,type:"svchar",len:100,dec:60,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",gxz:"ZV10UserName",gxold:"OV10UserName",gxvar:"AV10UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV10UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV10UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV10UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV10UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 20 , function() {
   });
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id:25 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEW",gxz:"ZV11UserPasswordNew",gxold:"OV11UserPasswordNew",gxvar:"AV11UserPasswordNew",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserPasswordNew=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserPasswordNew=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEW",gx.O.AV11UserPasswordNew,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11UserPasswordNew=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEW")},nac:gx.falseFn};
   this.declareDomainHdlr( 25 , function() {
   });
   GXValidFnc[26]={ id: 26, fld:"",grid:0};
   GXValidFnc[27]={ id: 27, fld:"",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id:30 ,lvl:0,type:"char",len:50,dec:0,sign:false,isPwd:true,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORDNEWCONF",gxz:"ZV12UserPasswordNewConf",gxold:"OV12UserPasswordNewConf",gxvar:"AV12UserPasswordNewConf",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12UserPasswordNewConf=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12UserPasswordNewConf=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORDNEWCONF",gx.O.AV12UserPasswordNewConf,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12UserPasswordNewConf=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORDNEWCONF")},nac:gx.falseFn};
   this.declareDomainHdlr( 30 , function() {
   });
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"",grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"BTNBACK",grid:0,evt:"e140r1_client"};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id: 37, fld:"SAVE",grid:0,evt:"e120r2_client",std:"ENTER"};
   this.AV10UserName = "" ;
   this.ZV10UserName = "" ;
   this.OV10UserName = "" ;
   this.AV11UserPasswordNew = "" ;
   this.ZV11UserPasswordNew = "" ;
   this.OV11UserPasswordNew = "" ;
   this.AV12UserPasswordNewConf = "" ;
   this.ZV12UserPasswordNewConf = "" ;
   this.OV12UserPasswordNewConf = "" ;
   this.AV10UserName = "" ;
   this.AV11UserPasswordNew = "" ;
   this.AV12UserPasswordNewConf = "" ;
   this.AV9UserId = "" ;
   this.Events = {"e120r2_client": ["ENTER", true] ,"e140r1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV9UserId',fld:'vUSERID',pic:'',hsh:true}],[]];
   this.EvtParms["START"] = [[{av:'AV9UserId',fld:'vUSERID',pic:'',hsh:true}],[{av:'AV10UserName',fld:'vUSERNAME',pic:''},{av:'AV11UserPasswordNew',fld:'vUSERPASSWORDNEW',pic:''},{av:'AV12UserPasswordNewConf',fld:'vUSERPASSWORDNEWCONF',pic:''},{av:'gx.fn.getCtrlProperty("TBLMAIN","Visible")',ctrl:'TBLMAIN',prop:'Visible'}]];
   this.EvtParms["ENTER"] = [[{av:'AV9UserId',fld:'vUSERID',pic:'',hsh:true},{av:'AV11UserPasswordNew',fld:'vUSERPASSWORDNEW',pic:''},{av:'AV12UserPasswordNewConf',fld:'vUSERPASSWORDNEWCONF',pic:''}],[{av:'gx.fn.getCtrlProperty("vUSERPASSWORDNEW","Enabled")',ctrl:'vUSERPASSWORDNEW',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("vUSERPASSWORDNEWCONF","Enabled")',ctrl:'vUSERPASSWORDNEWCONF',prop:'Enabled'},{ctrl:'SAVE',prop:'Visible'},{ctrl:'BTNBACK',prop:'Caption'}]];
   this.EnterCtrl = ["SAVE"];
   this.setVCMap("AV9UserId", "vUSERID", 0, "char", 40, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_setpassword);});
