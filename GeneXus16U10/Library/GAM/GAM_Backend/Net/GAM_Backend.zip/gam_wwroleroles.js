/*
               File: GAM_WWRoleRoles
        Description: Role's roles
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:20:41.78
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwroleroles', false, function () {
   this.ServerClass =  "gam_wwroleroles" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV21RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV25SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.AV20RoleId=gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator) ;
      this.AV17ListCount=gx.fn.getIntegerValue("vLISTCOUNT",gx.thousandSeparator) ;
      this.AV23RoleList=gx.fn.getControlValue("vROLELIST") ;
      this.AV21RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV25SearchFilter=gx.fn.getControlValue("vSEARCHFILTER") ;
      this.AV21RoleIdAux=gx.fn.getIntegerValue("vROLEIDAUX",gx.thousandSeparator) ;
      this.AV20RoleId=gx.fn.getIntegerValue("vROLEID",gx.thousandSeparator) ;
   };
   this.Validv_Currentpage=function()
   {
      return this.validCliEvt("Validv_Currentpage", 0, function () {
      try {
         var gxballoon = gx.util.balloon.getNew("vCURRENTPAGE");
         this.AnyError  = 0;
         if ( ! ( ( this.AV8CurrentPage == 15 ) ) )
         {
            try {
               gxballoon.setError(gx.text.format( gx.getMessage( "GXSPC_OutOfRange"), gx.getMessage( "Current Page"), "", "", "", "", "", "", "", ""));
               this.AnyError = gx.num.trunc( 1 ,0) ;
            }
            catch(e){}
         }

      }
      catch(e){}
      try {
          if (gxballoon == null) return true; return gxballoon.show();
      }
      catch(e){}
      return true ;
      });
   }
   this.e111m1_client=function()
   {
      /* 'Hide' Routine */
      this.clearMessages();
      if ( gx.fn.getCtrlProperty("FILTERSCONTAINER","Class") == "AdvancedContainer" )
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer"+" "+"AdvancedContainerVisible" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "HIDE FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "HideFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCell" );
      }
      else
      {
         gx.fn.setCtrlProperty("FILTERSCONTAINER","Class", "AdvancedContainer" );
         gx.fn.setCtrlProperty("HIDE","Caption", gx.getMessage( "SHOW FILTERS") );
         gx.fn.setCtrlProperty("HIDE","Class", "ShowFiltersButton" );
         gx.fn.setCtrlProperty("GRIDCELL","Class", "WWGridCellExpanded" );
      }
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]);
      return gx.$.Deferred().resolve();
   };
   this.e201m2_client=function()
   {
      /* Name_Click Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["DSP", this.AV15Id]);
      this.refreshOutputs([{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      return gx.$.Deferred().resolve();
   };
   this.e211m2_client=function()
   {
      /* Btnupd_Click Routine */
      this.clearMessages();
      this.call("gam_roleentry.aspx", ["UPD", this.AV15Id]);
      this.refreshOutputs([{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]);
      return gx.$.Deferred().resolve();
   };
   this.e121m1_client=function()
   {
      /* 'AddNew' Routine */
      this.clearMessages();
      this.call("gam_roleselect.aspx", [this.AV20RoleId, this.AV21RoleIdAux]);
      this.refreshOutputs([{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV20RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9'}]);
      return gx.$.Deferred().resolve();
   };
   this.e131m1_client=function()
   {
      /* 'First' Routine */
      this.clearMessages();
      this.AV8CurrentPage = gx.num.trunc( 1 ,0) ;
      gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
      gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
      gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      return gx.$.Deferred().resolve();
   };
   this.e141m1_client=function()
   {
      /* 'Previous' Routine */
      this.clearMessages();
      if ( this.AV8CurrentPage > 1 )
      {
         this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage - 1 ,0) ;
      }
      if ( this.AV8CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "SelectedPagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", false );
         gx.fn.setCtrlProperty("TBPREV","Enabled", false );
      }
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]);
      return gx.$.Deferred().resolve();
   };
   this.e151m1_client=function()
   {
      /* 'Next' Routine */
      this.clearMessages();
      if ( this.AV8CurrentPage == 1 )
      {
         gx.fn.setCtrlProperty("TBFIRST","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBPREV","Class", "PagingText" );
         gx.fn.setCtrlProperty("TBFIRST","Enabled", true );
         gx.fn.setCtrlProperty("TBPREV","Enabled", true );
      }
      this.AV8CurrentPage = gx.num.trunc( this.AV8CurrentPage + 1 ,0) ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'}]);
      this.refreshGrid('Gridww') ;
      this.refreshOutputs([{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'}]);
      return gx.$.Deferred().resolve();
   };
   this.e181m2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e191m2_client=function()
   {
      /* 'Back' Routine */
      return this.executeServerEvent("'BACK'", true, arguments[0], false, false);
   };
   this.e221m2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e231m1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,48,49,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72];
   this.GXLastCtrlId =72;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",50,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwroleroles",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Name",51,"vNAME",gx.getMessage( "Child name"),"","Name","char",0,"px",254,80,"left","e201m2_client",[],"Name","Name",true,0,false,false,"Attribute TextLikeLink SmallLink",1,"WWColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",52,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e211m2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",53,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e181m2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Id",54,"vID",gx.getMessage( "Key Numeric Long"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",false,0,false,false,"Attribute",1,"");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLETOP",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TABLE3",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"HIDE",grid:0,evt:"e111m1_client"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TEXTBLOCK2", format:0,grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"TABLE5",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"CANCEL1",grid:0,evt:"e231m1_client"};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"BTNADD",grid:0,evt:"e121m1_client"};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILNAME",gxz:"ZV12FilName",gxold:"OV12FilName",gxvar:"AV12FilName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12FilName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12FilName=Value},v2c:function(){gx.fn.setControlValue("vFILNAME",gx.O.AV12FilName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12FilName=this.val()},val:function(){return gx.fn.getControlValue("vFILNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 24 , function() {
   });
   GXValidFnc[25]={ id: 25, fld:"",grid:0};
   GXValidFnc[26]={ id: 26, fld:"CELLFILTERS",grid:0};
   GXValidFnc[27]={ id: 27, fld:"FILTERSCONTAINER",grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"",grid:0};
   GXValidFnc[30]={ id: 30, fld:"TABLE4",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   GXValidFnc[32]={ id: 32, fld:"",grid:0};
   GXValidFnc[33]={ id: 33, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[34]={ id: 34, fld:"",grid:0};
   GXValidFnc[35]={ id: 35, fld:"",grid:0};
   GXValidFnc[36]={ id: 36, fld:"",grid:0};
   GXValidFnc[37]={ id:37 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vFILEXTERNALID",gxz:"ZV11FilExternalId",gxold:"OV11FilExternalId",gxvar:"AV11FilExternalId",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11FilExternalId=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11FilExternalId=Value},v2c:function(){gx.fn.setControlValue("vFILEXTERNALID",gx.O.AV11FilExternalId,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11FilExternalId=this.val()},val:function(){return gx.fn.getControlValue("vFILEXTERNALID")},nac:gx.falseFn};
   this.declareDomainHdlr( 37 , function() {
   });
   GXValidFnc[38]={ id: 38, fld:"GRIDCELL",grid:0};
   GXValidFnc[39]={ id: 39, fld:"GRIDTABLE",grid:0};
   GXValidFnc[40]={ id: 40, fld:"",grid:0};
   GXValidFnc[41]={ id: 41, fld:"",grid:0};
   GXValidFnc[42]={ id: 42, fld:"",grid:0};
   GXValidFnc[43]={ id: 43, fld:"",grid:0};
   GXValidFnc[44]={ id:44 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,multiline:true,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"CTLNAME",gxz:"ZV30GXV1",gxold:"OV30GXV1",gxvar:"GXV1",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.GXV1=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV30GXV1=Value},v2c:function(){gx.fn.setControlValue("CTLNAME",gx.O.GXV1,0)},c2v:function(){if(this.val()!==undefined)gx.O.GXV1=this.val()},val:function(){return gx.fn.getControlValue("CTLNAME")},nac:gx.falseFn};
   GXValidFnc[45]={ id: 45, fld:"",grid:0};
   GXValidFnc[46]={ id: 46, fld:"",grid:0};
   GXValidFnc[48]={ id: 48, fld:"",grid:0};
   GXValidFnc[49]={ id: 49, fld:"",grid:0};
   GXValidFnc[51]={ id:51 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV18Name",gxold:"OV18Name",gxvar:"AV18Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV18Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV18Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(50),gx.O.AV18Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV18Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn,evt:"e201m2_client"};
   GXValidFnc[52]={ id:52 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(50),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn,evt:"e211m2_client"};
   GXValidFnc[53]={ id:53 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",gxz:"ZV5BtnDlt",gxold:"OV5BtnDlt",gxvar:"AV5BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(50),gx.O.AV5BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(50))},nac:gx.falseFn,evt:"e181m2_client"};
   GXValidFnc[54]={ id:54 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:50,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV15Id",gxold:"OV15Id",gxvar:"AV15Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'number',v2v:function(Value){if(Value!==undefined)gx.O.AV15Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV15Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(50),gx.O.AV15Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV15Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(50),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[55]={ id: 55, fld:"",grid:0};
   GXValidFnc[56]={ id: 56, fld:"",grid:0};
   GXValidFnc[57]={ id: 57, fld:"TABLE6",grid:0};
   GXValidFnc[58]={ id: 58, fld:"",grid:0};
   GXValidFnc[59]={ id: 59, fld:"",grid:0};
   GXValidFnc[60]={ id: 60, fld:"TBFIRST", format:0,grid:0,evt:"e131m1_client"};
   GXValidFnc[61]={ id: 61, fld:"",grid:0};
   GXValidFnc[62]={ id: 62, fld:"TB2", format:0,grid:0};
   GXValidFnc[63]={ id: 63, fld:"",grid:0};
   GXValidFnc[64]={ id: 64, fld:"TBPREV", format:0,grid:0,evt:"e141m1_client"};
   GXValidFnc[65]={ id: 65, fld:"",grid:0};
   GXValidFnc[66]={ id: 66, fld:"TB5", format:0,grid:0};
   GXValidFnc[67]={ id: 67, fld:"",grid:0};
   GXValidFnc[68]={ id: 68, fld:"TBNEXT", format:0,grid:0,evt:"e151m1_client"};
   GXValidFnc[69]={ id: 69, fld:"",grid:0};
   GXValidFnc[70]={ id: 70, fld:"",grid:0};
   GXValidFnc[71]={ id: 71, fld:"",grid:0};
   GXValidFnc[72]={ id:72 ,lvl:0,type:"int",len:10,dec:0,sign:false,pic:"ZZZZZZZZZ9",ro:0,grid:0,gxgrid:null,fnc:this.Validv_Currentpage,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vCURRENTPAGE",gxz:"ZV8CurrentPage",gxold:"OV8CurrentPage",gxvar:"AV8CurrentPage",ucs:[],op:[72],ip:[72],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV8CurrentPage=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV8CurrentPage=gx.num.intval(Value)},v2c:function(){gx.fn.setControlValue("vCURRENTPAGE",gx.O.AV8CurrentPage,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV8CurrentPage=gx.num.intval(this.val())},val:function(){return gx.fn.getIntegerValue("vCURRENTPAGE",gx.thousandSeparator)},nac:gx.falseFn};
   this.AV12FilName = "" ;
   this.ZV12FilName = "" ;
   this.OV12FilName = "" ;
   this.AV11FilExternalId = "" ;
   this.ZV11FilExternalId = "" ;
   this.OV11FilExternalId = "" ;
   this.GXV1 = "" ;
   this.ZV30GXV1 = "" ;
   this.OV30GXV1 = "" ;
   this.ZV18Name = "" ;
   this.OV18Name = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV5BtnDlt = "" ;
   this.OV5BtnDlt = "" ;
   this.ZV15Id = 0 ;
   this.OV15Id = 0 ;
   this.AV8CurrentPage = 0 ;
   this.ZV8CurrentPage = 0 ;
   this.OV8CurrentPage = 0 ;
   this.AV12FilName = "" ;
   this.AV11FilExternalId = "" ;
   this.GXV1 = "" ;
   this.AV8CurrentPage = 0 ;
   this.AV20RoleId = 0 ;
   this.AV21RoleIdAux = 0 ;
   this.AV18Name = "" ;
   this.AV6BtnUpd = "" ;
   this.AV5BtnDlt = "" ;
   this.AV15Id = 0 ;
   this.AV25SearchFilter = "" ;
   this.AV17ListCount = 0 ;
   this.AV23RoleList = [ ] ;
   this.Events = {"e181m2_client": ["VBTNDLT.CLICK", true] ,"e191m2_client": ["'BACK'", true] ,"e221m2_client": ["ENTER", true] ,"e231m1_client": ["CANCEL", true] ,"e111m1_client": ["'HIDE'", false] ,"e201m2_client": ["VNAME.CLICK", false] ,"e211m2_client": ["VBTNUPD.CLICK", false] ,"e121m1_client": ["'ADDNEW'", false] ,"e131m1_client": ["'FIRST'", false] ,"e141m1_client": ["'PREVIOUS'", false] ,"e151m1_client": ["'NEXT'", false]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true}],[]];
   this.EvtParms["START"] = [[{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV23RoleList',fld:'vROLELIST',pic:''}],[{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("vCURRENTPAGE","Visible")',ctrl:'vCURRENTPAGE',prop:'Visible'},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true},{av:'AV23RoleList',fld:'vROLELIST',pic:''}]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'}],[{av:'AV6BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV5BtnDlt',fld:'vBTNDLT',pic:''},{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV18Name',fld:'vNAME',pic:''},{av:'gx.fn.getCtrlProperty("TBNEXT","Class")',ctrl:'TBNEXT',prop:'Class'}]];
   this.EvtParms["'HIDE'"] = [[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'}],[{av:'gx.fn.getCtrlProperty("FILTERSCONTAINER","Class")',ctrl:'FILTERSCONTAINER',prop:'Class'},{ctrl:'HIDE',prop:'Caption'},{ctrl:'HIDE',prop:'Class'},{av:'gx.fn.getCtrlProperty("GRIDCELL","Class")',ctrl:'GRIDCELL',prop:'Class'}]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true},{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   this.EvtParms["VNAME.CLICK"] = [[{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV15Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'AV20RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'}],[{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV20RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9'}]];
   this.EvtParms["'BACK'"] = [[{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true},{av:'AV23RoleList',fld:'vROLELIST',pic:''},{av:'AV20RoleId',fld:'vROLEID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV23RoleList',fld:'vROLELIST',pic:''}]];
   this.EvtParms["'FIRST'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true}],[{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'PREVIOUS'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true}],[{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'}]];
   this.EvtParms["'NEXT'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV21RoleIdAux',fld:'vROLEIDAUX',pic:'ZZZZZZZZZZZ9'},{av:'AV12FilName',fld:'vFILNAME',pic:''},{av:'AV25SearchFilter',fld:'vSEARCHFILTER',pic:'',hsh:true},{av:'AV11FilExternalId',fld:'vFILEXTERNALID',pic:''},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'},{av:'AV17ListCount',fld:'vLISTCOUNT',pic:'ZZZZZ9',hsh:true}],[{av:'gx.fn.getCtrlProperty("TBFIRST","Class")',ctrl:'TBFIRST',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBPREV","Class")',ctrl:'TBPREV',prop:'Class'},{av:'gx.fn.getCtrlProperty("TBFIRST","Enabled")',ctrl:'TBFIRST',prop:'Enabled'},{av:'gx.fn.getCtrlProperty("TBPREV","Enabled")',ctrl:'TBPREV',prop:'Enabled'},{av:'AV8CurrentPage',fld:'vCURRENTPAGE',pic:'ZZZZZZZZZ9'}]];
   this.EvtParms["VALIDV_CURRENTPAGE"] = [[],[]];
   this.setVCMap("AV21RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV25SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV20RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV17ListCount", "vLISTCOUNT", 0, "int", 6, 0);
   this.setVCMap("AV23RoleList", "vROLELIST", 0, "Collint", 0, 0);
   this.setVCMap("AV21RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV25SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   this.setVCMap("AV21RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV20RoleId", "vROLEID", 0, "int", 12, 0);
   this.setVCMap("AV21RoleIdAux", "vROLEIDAUX", 0, "int", 12, 0);
   this.setVCMap("AV25SearchFilter", "vSEARCHFILTER", 0, "char", 254, 0);
   GridwwContainer.addRefreshingVar({rfrVar:"AV21RoleIdAux"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV25SearchFilter"});
   GridwwContainer.addRefreshingVar(this.GXValidFnc[37]);
   GridwwContainer.addRefreshingVar(this.GXValidFnc[72]);
   GridwwContainer.addRefreshingVar({rfrVar:"AV17ListCount"});
   GridwwContainer.addRefreshingParm({rfrVar:"AV21RoleIdAux"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[24]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV25SearchFilter"});
   GridwwContainer.addRefreshingParm(this.GXValidFnc[37]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[72]);
   GridwwContainer.addRefreshingParm({rfrVar:"AV17ListCount"});
   this.addBCProperty("Gamrole", ["Name"], this.GXValidFnc[44], "AV14GAMRole");
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_wwroleroles);});
