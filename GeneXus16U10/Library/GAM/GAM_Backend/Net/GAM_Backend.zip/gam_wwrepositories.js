/*
               File: GAM_WWRepositories
        Description: Repositories
             Author: GeneXus C# Generator version 16_0_10-142546
       Generated on: 7/4/2020 15:19:43.10
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_wwrepositories', false, function () {
   this.ServerClass =  "gam_wwrepositories" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
   };
   this.e110c2_client=function()
   {
      /* 'AddNew' Routine */
      return this.executeServerEvent("'ADDNEW'", false, null, false, false);
   };
   this.e130c2_client=function()
   {
      /* Btnupd_Click Routine */
      return this.executeServerEvent("VBTNUPD.CLICK", true, arguments[0], false, false);
   };
   this.e140c2_client=function()
   {
      /* Btndlt_Click Routine */
      return this.executeServerEvent("VBTNDLT.CLICK", true, arguments[0], false, false);
   };
   this.e150c2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, arguments[0], false, false);
   };
   this.e160c2_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, arguments[0], false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,21,22,24,25,26,27];
   this.GXLastCtrlId =27;
   this.GridwwContainer = new gx.grid.grid(this, 2,"WbpLvl2",23,"Gridww","Gridww","GridwwContainer",this.CmpContext,this.IsMasterPage,"gam_wwrepositories",[],false,1,false,true,0,false,false,false,"",0,"px",0,"px",gx.getMessage( "GXM_newrow"),false,false,false,null,null,false,"",false,[1,1,1,1],false,0,true,false);
   var GridwwContainer = this.GridwwContainer;
   GridwwContainer.addSingleLineEdit("Id",24,"vID",gx.getMessage( "Id"),"","Id","int",0,"px",12,12,"right",null,[],"Id","Id",true,0,false,false,"Attribute",1,"WWActionColumn");
   GridwwContainer.addSingleLineEdit("Name",25,"vNAME",gx.getMessage( "Name"),"","Name","char",0,"px",254,80,"left",null,[],"Name","Name",true,0,false,false,"Attribute",1,"WWColumn WWSecondaryColumn");
   GridwwContainer.addSingleLineEdit("Btnupd",26,"vBTNUPD","","","BtnUpd","char",0,"px",20,20,"left","e130c2_client",[],"Btnupd","BtnUpd",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   GridwwContainer.addSingleLineEdit("Btndlt",27,"vBTNDLT","","","BtnDlt","char",0,"px",20,20,"left","e140c2_client",[],"Btndlt","BtnDlt",true,0,false,false,"TextActionAttribute TextLikeLink",1,"WWTextActionColumn");
   this.GridwwContainer.emptyText = gx.getMessage( "");
   this.setGrid(GridwwContainer);
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE2",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK1", format:0,grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"ADDNEW1",grid:0,evt:"e110c2_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id:14 ,lvl:0,type:"char",len:60,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vSEARCH",gxz:"ZV16Search",gxold:"OV16Search",gxvar:"AV16Search",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV16Search=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV16Search=Value},v2c:function(){gx.fn.setControlValue("vSEARCH",gx.O.AV16Search,0)},c2v:function(){if(this.val()!==undefined)gx.O.AV16Search=this.val()},val:function(){return gx.fn.getControlValue("vSEARCH")},nac:gx.falseFn};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TABLE1",grid:0};
   GXValidFnc[18]={ id: 18, fld:"",grid:0};
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id: 22, fld:"",grid:0};
   GXValidFnc[24]={ id:24 ,lvl:2,type:"int",len:12,dec:0,sign:false,pic:"ZZZZZZZZZZZ9",ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vID",gxz:"ZV11Id",gxold:"OV11Id",gxvar:"AV11Id",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'number',v2v:function(Value){if(Value!==undefined)gx.O.AV11Id=gx.num.intval(Value)},v2z:function(Value){if(Value!==undefined)gx.O.ZV11Id=gx.num.intval(Value)},v2c:function(row){gx.fn.setGridControlValue("vID",row || gx.fn.currentGridRowImpl(23),gx.O.AV11Id,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV11Id=gx.num.intval(this.val(row))},val:function(row){return gx.fn.getGridIntegerValue("vID",row || gx.fn.currentGridRowImpl(23),gx.thousandSeparator)},nac:gx.falseFn};
   GXValidFnc[25]={ id:25 ,lvl:2,type:"char",len:254,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vNAME",gxz:"ZV13Name",gxold:"OV13Name",gxvar:"AV13Name",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV13Name=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV13Name=Value},v2c:function(row){gx.fn.setGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23),gx.O.AV13Name,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV13Name=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vNAME",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn};
   GXValidFnc[26]={ id:26 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNUPD",gxz:"ZV6BtnUpd",gxold:"OV6BtnUpd",gxvar:"AV6BtnUpd",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV6BtnUpd=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV6BtnUpd=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23),gx.O.AV6BtnUpd,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV6BtnUpd=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNUPD",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e130c2_client"};
   GXValidFnc[27]={ id:27 ,lvl:2,type:"char",len:20,dec:0,sign:false,ro:0,isacc:0,grid:23,gxgrid:this.GridwwContainer,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vBTNDLT",gxz:"ZV5BtnDlt",gxold:"OV5BtnDlt",gxvar:"AV5BtnDlt",ucs:[],op:[],ip:[],nacdep:[],ctrltype:"edit",inputType:'text',autoCorrect:"1",v2v:function(Value){if(Value!==undefined)gx.O.AV5BtnDlt=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV5BtnDlt=Value},v2c:function(row){gx.fn.setGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(23),gx.O.AV5BtnDlt,0)},c2v:function(row){if(this.val(row)!==undefined)gx.O.AV5BtnDlt=this.val(row)},val:function(row){return gx.fn.getGridControlValue("vBTNDLT",row || gx.fn.currentGridRowImpl(23))},nac:gx.falseFn,evt:"e140c2_client"};
   this.AV16Search = "" ;
   this.ZV16Search = "" ;
   this.OV16Search = "" ;
   this.ZV11Id = 0 ;
   this.OV11Id = 0 ;
   this.ZV13Name = "" ;
   this.OV13Name = "" ;
   this.ZV6BtnUpd = "" ;
   this.OV6BtnUpd = "" ;
   this.ZV5BtnDlt = "" ;
   this.OV5BtnDlt = "" ;
   this.AV16Search = "" ;
   this.AV11Id = 0 ;
   this.AV13Name = "" ;
   this.AV6BtnUpd = "" ;
   this.AV5BtnDlt = "" ;
   this.Events = {"e110c2_client": ["'ADDNEW'", true] ,"e130c2_client": ["VBTNUPD.CLICK", true] ,"e140c2_client": ["VBTNDLT.CLICK", true] ,"e150c2_client": ["ENTER", true] ,"e160c2_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV16Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["GRIDWW.LOAD"] = [[{av:'AV16Search',fld:'vSEARCH',pic:''}],[{av:'AV6BtnUpd',fld:'vBTNUPD',pic:''},{av:'AV5BtnDlt',fld:'vBTNDLT',pic:''},{av:'gx.fn.getCtrlProperty("vBTNDLT","Visible")',ctrl:'vBTNDLT',prop:'Visible'},{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'},{av:'AV13Name',fld:'vNAME',pic:''}]];
   this.EvtParms["'ADDNEW'"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV16Search',fld:'vSEARCH',pic:''}],[]];
   this.EvtParms["VBTNUPD.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[]];
   this.EvtParms["VBTNDLT.CLICK"] = [[{av:'GRIDWW_nFirstRecordOnPage'},{av:'GRIDWW_nEOF'},{av:'AV16Search',fld:'vSEARCH',pic:''},{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}],[{av:'AV11Id',fld:'vID',pic:'ZZZZZZZZZZZ9'}]];
   GridwwContainer.addRefreshingVar(this.GXValidFnc[14]);
   GridwwContainer.addRefreshingParm(this.GXValidFnc[14]);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_wwrepositories);});
