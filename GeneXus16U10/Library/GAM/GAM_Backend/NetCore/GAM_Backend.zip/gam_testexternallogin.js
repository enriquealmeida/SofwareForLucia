/*
               File: GAM_TestExternalLogin
        Description: Test External Login
             Author: GeneXus .NET Core Generator version 16_0_10-150262
       Generated on: 5/19/2021 5:39:35.50
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_testexternallogin', false, function () {
   this.ServerClass =  "gam_testexternallogin" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = true;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV9Name=gx.fn.getControlValue("vNAME") ;
      this.AV10TypeId=gx.fn.getControlValue("vTYPEID") ;
   };
   this.e111s2_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e131s1_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25];
   this.GXLastCtrlId =25;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE3",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"CANCEL",grid:0,evt:"e131s1_client"};
   GXValidFnc[12]={ id: 12, fld:"",grid:0};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"TABLE1",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"",grid:0};
   GXValidFnc[17]={ id: 17, fld:"",grid:0};
   GXValidFnc[18]={ id:18 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERNAME",gxz:"ZV11UserName",gxold:"OV11UserName",gxvar:"AV11UserName",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV11UserName=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV11UserName=Value},v2c:function(){gx.fn.setControlValue("vUSERNAME",gx.O.AV11UserName,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV11UserName=this.val()},val:function(){return gx.fn.getControlValue("vUSERNAME")},nac:gx.falseFn};
   this.declareDomainHdlr( 18 , function() {
   });
   GXValidFnc[19]={ id: 19, fld:"",grid:0};
   GXValidFnc[20]={ id: 20, fld:"",grid:0};
   GXValidFnc[21]={ id: 21, fld:"",grid:0};
   GXValidFnc[22]={ id:22 ,lvl:0,type:"char",len:254,dec:0,sign:false,ro:0,grid:0,gxgrid:null,fnc:null,isvalid:null,evt_cvc:null,evt_cvcing:null,rgrid:[],fld:"vUSERPASSWORD",gxz:"ZV12UserPassword",gxold:"OV12UserPassword",gxvar:"AV12UserPassword",ucs:[],op:[],ip:[],
						nacdep:[],ctrltype:"edit",v2v:function(Value){if(Value!==undefined)gx.O.AV12UserPassword=Value},v2z:function(Value){if(Value!==undefined)gx.O.ZV12UserPassword=Value},v2c:function(){gx.fn.setControlValue("vUSERPASSWORD",gx.O.AV12UserPassword,0);if (typeof(this.dom_hdl) == 'function') this.dom_hdl.call(gx.O);},c2v:function(){if(this.val()!==undefined)gx.O.AV12UserPassword=this.val()},val:function(){return gx.fn.getControlValue("vUSERPASSWORD")},nac:gx.falseFn};
   this.declareDomainHdlr( 22 , function() {
   });
   GXValidFnc[23]={ id: 23, fld:"",grid:0};
   GXValidFnc[24]={ id: 24, fld:"",grid:0};
   GXValidFnc[25]={ id: 25, fld:"ENTER",grid:0,evt:"e111s2_client",std:"ENTER"};
   this.AV11UserName = "" ;
   this.ZV11UserName = "" ;
   this.OV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.ZV12UserPassword = "" ;
   this.OV12UserPassword = "" ;
   this.AV11UserName = "" ;
   this.AV12UserPassword = "" ;
   this.AV9Name = "" ;
   this.AV10TypeId = "" ;
   this.Events = {"e111s2_client": ["ENTER", true] ,"e131s1_client": ["CANCEL", true]};
   this.EvtParms["REFRESH"] = [[{av:'AV9Name',fld:'vNAME',pic:'',hsh:true}],[]];
   this.EvtParms["ENTER"] = [[{av:'AV9Name',fld:'vNAME',pic:'',hsh:true},{av:'AV11UserName',fld:'vUSERNAME',pic:''},{av:'AV12UserPassword',fld:'vUSERPASSWORD',pic:''}],[]];
   this.EnterCtrl = ["ENTER"];
   this.setVCMap("AV9Name", "vNAME", 0, "char", 60, 0);
   this.setVCMap("AV10TypeId", "vTYPEID", 0, "char", 30, 0);
   this.Initialize( );
});
gx.wi( function() { gx.createParentObj(gam_testexternallogin);});
