/*
               File: GAM_Header
        Description: GAM_Header
             Author: GeneXus .NET Core Generator version 16_0_10-150262
       Generated on: 5/19/2021 5:36:50.93
       Program type: Callable routine
          Main DBMS: SQL Server
*/
gx.evt.autoSkip = false;
gx.define('gam_header', true, function (CmpContext) {
   this.ServerClass =  "gam_header" ;
   this.PackageName =  "GeneXus.Security.Backend" ;
   this.setObjectType("web");
   this.setCmpContext(CmpContext);
   this.ReadonlyForm = true;
   this.setAjaxSecurity(false);
   this.setOnAjaxSessionTimeout("Warn");
   this.hasEnterEvent = false;
   this.skipOnEnter = false;
   this.autoRefresh = true;
   this.fullAjax = true;
   this.supportAjaxEvents =  true ;
   this.ajaxSecurityToken =  true ;
   this.SetStandaloneVars=function()
   {
      this.AV5AactualPage=gx.fn.getControlValue("vAACTUALPAGE") ;
   };
   this.e11291_client=function()
   {
      /* 'GoHome' Routine */
      this.clearMessages();
      this.call("gam_dashboard.aspx", []);
      this.refreshOutputs([]);
      return gx.$.Deferred().resolve();
   };
   this.e14292_client=function()
   {
      /* Enter Routine */
      return this.executeServerEvent("ENTER", true, null, false, false);
   };
   this.e15292_client=function()
   {
      /* Cancel Routine */
      return this.executeServerEvent("CANCEL", true, null, false, false);
   };
   this.GXValidFnc = [];
   var GXValidFnc = this.GXValidFnc ;
   this.GXCtrlIds=[2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31];
   this.GXLastCtrlId =31;
   GXValidFnc[2]={ id: 2, fld:"",grid:0};
   GXValidFnc[3]={ id: 3, fld:"MAINTABLE",grid:0};
   GXValidFnc[4]={ id: 4, fld:"",grid:0};
   GXValidFnc[5]={ id: 5, fld:"",grid:0};
   GXValidFnc[6]={ id: 6, fld:"TABLE1",grid:0};
   GXValidFnc[7]={ id: 7, fld:"",grid:0};
   GXValidFnc[8]={ id: 8, fld:"",grid:0};
   GXValidFnc[9]={ id: 9, fld:"TEXTBLOCK3", format:0,grid:0};
   GXValidFnc[10]={ id: 10, fld:"",grid:0};
   GXValidFnc[11]={ id: 11, fld:"",grid:0};
   GXValidFnc[12]={ id: 12, fld:"TEXTBLOCK4", format:0,grid:0,evt:"e11291_client"};
   GXValidFnc[13]={ id: 13, fld:"",grid:0};
   GXValidFnc[14]={ id: 14, fld:"",grid:0};
   GXValidFnc[15]={ id: 15, fld:"",grid:0};
   GXValidFnc[16]={ id: 16, fld:"MENU_INNER",grid:0};
   GXValidFnc[17]={ id: 17, fld:"TBMENUUSERS", format:0,grid:0};
   GXValidFnc[18]={ id: 18, fld:"TBMENUROLES", format:0,grid:0};
   GXValidFnc[19]={ id: 19, fld:"WWSECPOL", format:0,grid:0};
   GXValidFnc[20]={ id: 20, fld:"WWAPPLICATIONS", format:0,grid:0};
   GXValidFnc[21]={ id: 21, fld:"REPCONF", format:0,grid:0};
   GXValidFnc[22]={ id: 22, fld:"REPOSITORYCONNECTIONS", format:0,grid:0};
   GXValidFnc[23]={ id: 23, fld:"AUTHTYPE", format:0,grid:0};
   GXValidFnc[24]={ id: 24, fld:"CHANGEPASSWD", format:0,grid:0};
   GXValidFnc[25]={ id: 25, fld:"CHANGEWORKREPO", format:0,grid:0};
   GXValidFnc[26]={ id: 26, fld:"TBREPOSITORIES", format:0,grid:0};
   GXValidFnc[27]={ id: 27, fld:"TBEVENTS", format:0,grid:0};
   GXValidFnc[28]={ id: 28, fld:"",grid:0};
   GXValidFnc[29]={ id: 29, fld:"TABLE2",grid:0};
   GXValidFnc[30]={ id: 30, fld:"",grid:0};
   GXValidFnc[31]={ id: 31, fld:"",grid:0};
   this.AV5AactualPage = "" ;
   this.Events = {"e14292_client": ["ENTER", true] ,"e15292_client": ["CANCEL", true] ,"e11291_client": ["'GOHOME'", false]};
   this.EvtParms["REFRESH"] = [[],[]];
   this.EvtParms["START"] = [[],[{av:'gx.fn.getCtrlProperty("TBREPOSITORIES","Visible")',ctrl:'TBREPOSITORIES',prop:'Visible'},{av:'gx.fn.getCtrlProperty("AUTHTYPE","Visible")',ctrl:'AUTHTYPE',prop:'Visible'},{av:'gx.fn.getCtrlProperty("TBMENUUSERS","Link")',ctrl:'TBMENUUSERS',prop:'Link'},{av:'gx.fn.getCtrlProperty("TBMENUROLES","Link")',ctrl:'TBMENUROLES',prop:'Link'},{av:'gx.fn.getCtrlProperty("WWSECPOL","Link")',ctrl:'WWSECPOL',prop:'Link'},{av:'gx.fn.getCtrlProperty("WWAPPLICATIONS","Link")',ctrl:'WWAPPLICATIONS',prop:'Link'},{av:'gx.fn.getCtrlProperty("REPCONF","Link")',ctrl:'REPCONF',prop:'Link'},{av:'gx.fn.getCtrlProperty("REPOSITORYCONNECTIONS","Link")',ctrl:'REPOSITORYCONNECTIONS',prop:'Link'},{av:'gx.fn.getCtrlProperty("AUTHTYPE","Link")',ctrl:'AUTHTYPE',prop:'Link'},{av:'gx.fn.getCtrlProperty("CHANGEPASSWD","Link")',ctrl:'CHANGEPASSWD',prop:'Link'},{av:'gx.fn.getCtrlProperty("CHANGEWORKREPO","Link")',ctrl:'CHANGEWORKREPO',prop:'Link'},{av:'gx.fn.getCtrlProperty("TBREPOSITORIES","Link")',ctrl:'TBREPOSITORIES',prop:'Link'},{av:'gx.fn.getCtrlProperty("TBEVENTS","Link")',ctrl:'TBEVENTS',prop:'Link'}]];
   this.EvtParms["'GOHOME'"] = [[],[]];
   this.setVCMap("AV5AactualPage", "vAACTUALPAGE", 0, "char", 50, 0);
   this.Initialize( );
   this.setComponent({id: "COMPONENT2" ,GXClass: "gam_logout" , Prefix: "W0032" , lvl: 1 });
});
